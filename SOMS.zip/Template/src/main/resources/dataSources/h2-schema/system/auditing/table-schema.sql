drop table if exists login_audit;
create table login_audit
(
	id integer not null primary key,
	username varchar_ignorecase(50) not null,
	password varchar_ignorecase(50),
	person_id integer,
	uri varchar(255),
    ip varchar(50),
    os varchar(50),
    browser varchar(50),
    userAgent varchar(255),
	action varchar(10),
	audit_time timestamp default current_timestamp
);
--filePath=com/squaressolutions/template/dataSource/model/system/security/LoginAudit.java

drop table if exists app_audit;
create table app_audit
(
	id integer not null primary key,
	username varchar_ignorecase(50) not null,
	person_id integer,
    ip varchar(50),
	uri varchar(255),
	queryStr varchar(255),
	configPath varchar(255),
	fullUrl varchar(255),
	audit_time timestamp default current_timestamp
);
--filePath=com/squaressolutions/template/dataSource/model/system/security/AppAudit.java

drop table if exists business_audit;
create table business_audit
(
	id integer not null primary key,
	username varchar_ignorecase(50) not null,
	person_id integer,
    ip varchar(50),
	uri varchar(255),
	queryStr varchar(255),
	businessBehaviour varchar(255),
	fullUrl varchar(255),
	audit_time timestamp default current_timestamp
);
--filePath=com/squaressolutions/template/dataSource/model/system/security/BusinessAudit.java
