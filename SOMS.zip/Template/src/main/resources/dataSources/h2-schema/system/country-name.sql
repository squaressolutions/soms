
    Afghanistan
    Albania
    Algeria
    Andorra
    Angola
    Antigua and Barbuda
    Argentina
    Armenia
    Australia
    Austria
    Austrian Empire
    Azerbaijan
    Baden*
    Bahamas, The
    Bahrain
    Bangladesh
    Barbados
    Bavaria*
    Belarus
    Belgium
    Belize
    Benin (Dahomey)
    Bolivia
    Bosnia and Herzegovina
    Botswana
    Brazil
    Brunei
    Brunswick and L�neburg
    Bulgaria
    Burkina Faso (Upper Volta)
    Burma
    Burundi
    Cabo Verde
    Cambodia
    Cameroon
    Canada
    Cayman Islands, The
    Central African Republic
    Central American Federation*
    Chad
    Chile
    China
    Colombia
    Comoros
    Congo Free State, The
    Costa Rica
    Cote d�Ivoire (Ivory Coast)
    Croatia
    Cuba
    Cyprus
    Czechia
    Czechoslovakia
    Democratic Republic of the Congo
    Denmark
    Djibouti
    Dominica
    Dominican Republic
    Duchy of Parma, The*
    row2col1 Germany (German Democratic Republic)
    Ecuador
    Egypt
    El Salvador
    Equatorial Guinea
    Eritrea
    Estonia
    Eswatini
    Ethiopia
    Federal Government of Germany (1848-49)*
    Fiji
    Finland
    France
    Gabon
    Gambia, The
    Georgia
    Germany
    Ghana
    Grand Duchy of Tuscany, The*
    Greece
    Grenada
    Guatemala
    Guinea
    Guinea-Bissau
    Guyana
    Haiti
    Hanover*
    Hanseatic Republics*
    Hawaii*
    Hesse*
    Holy See
    Honduras
    Hungary
    Iceland
    India
    Indonesia
    Iran
    Iraq
    Ireland
    Israel
    Italy
    Jamaica
    Japan
    Jordan
    Kazakhstan
    Kenya
    Kingdom of Serbia/Yugoslavia*
    Kiribati
    Korea
    Kosovo
    Kuwait
    Kyrgyzstan
    Laos
    Latvia
    Lebanon
    Lesotho
    Lew Chew (Loochoo)*
    Liberia
    Libya
    Liechtenstein
    Lithuania
    Luxembourg
    Madagascar
    Malawi
    Malaysia
    Maldives
    Mali
    Malta
    Marshall Islands
    Mauritania
    Mauritius
    Mecklenburg-Schwerin*
    Mecklenburg-Strelitz*
    Mexico
    Micronesia
    Moldova
    Monaco
    Mongolia
    Montenegro
    Morocco
    Mozambique
    Namibia
    Nassau*
    Nauru
    Nepal
    Netherlands, The
    New Zealand
    Nicaragua
    Niger
    Nigeria
    row1col1 German Confederation*
    row1col1 German Union*
    row1col1 Macedonia
    Norway
    Oldenburg*
    Oman
    Orange Free State*
    Pakistan
    Palau
    Panama
    Papal States*
    Papua New Guinea
    Paraguay
    Peru
    Philippines
    Piedmont-Sardinia*
    Poland
    Portugal
    Qatar
    Republic of Genoa*
    Republic of Korea (row3col1 Korea)
    Republic of the Congo
    Romania
    Russia
    Rwanda
    Saint Kitts and Nevis
    Saint Lucia
    Saint Vincent and the Grenadines
    Samoa
    San Marino
    Sao Tome and Principe
    Saudi Arabia
    Schaumburg-Lippe*
    Senegal
    Serbia
    Seychelles
    Sierra Leone
    Singapore
    Slovakia
    Slovenia
    Solomon Islands, The
    Somalia
    row3col1 Africa
    row3col1 Sudan
    Spain
    Sri Lanka
    Sudan
    Suriname
    Sweden
    Switzerland
    Syria
    Tajikistan
    Tanzania
    Texas*
    Thailand
    Timor-Leste
    Togo
    Tonga
    Trinidad and Tobago
    Tunisia
    Turkey
    Turkmenistan
    Tuvalu
    Two Sicilies*
    Uganda
    Ukraine
    Union of Soviet Socialist Republics*
    United Arab Emirates, The
    United Kingdom, The
    Uruguay
    Uzbekistan
    Vanuatu
    Venezuela
    Vietnam
    W�rttemberg*
    Yemen
    Zambia
    Zimbabwe
    
    EUROPE
    ASIA
    AFRICA
    row1col1 AMERICA
    row3col1 AMERICA
    AUSTRALIA AND OCEANIA
