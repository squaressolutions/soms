insert into weekday_name (id, short_name, name) values (1, 'Mon', 'Monday');
insert into weekday_name (id, short_name, name) values (2, 'Tue', 'Tuesday');
insert into weekday_name (id, short_name, name) values (3, 'Wed', 'Wednesday');
insert into weekday_name (id, short_name, name) values (4, 'Thu', 'Thursday');
insert into weekday_name (id, short_name, name) values (5, 'Fri', 'Friday');
insert into weekday_name (id, short_name, name) values (6, 'Sat', 'Saturday');
insert into weekday_name (id, short_name, name) values (7, 'Sun', 'Sunday');

insert into month_name (id, short_name, name) values (1, 'Jan', 'January');
insert into month_name (id, short_name, name) values (2, 'Feb', 'February');
insert into month_name (id, short_name, name) values (3, 'Mar', 'March');
insert into month_name (id, short_name, name) values (4, 'Apr', 'April');
insert into month_name (id, short_name, name) values (5, 'May', 'May');
insert into month_name (id, short_name, name) values (6, 'Jun', 'June');
insert into month_name (id, short_name, name) values (7, 'Jul', 'July');
insert into month_name (id, short_name, name) values (8, 'Aug', 'August');
insert into month_name (id, short_name, name) values (9, 'Sep', 'September');
insert into month_name (id, short_name, name) values (10, 'Oct', 'October');
insert into month_name (id, short_name, name) values (11, 'Nov', 'November');
insert into month_name (id, short_name, name) values (12, 'Dec', 'December');


