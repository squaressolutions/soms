drop index if exists ix_auth_username;
drop view if exists users_v;
drop table if exists identitis;
drop table if exists authorities;
drop table if exists users;

create table users
(
	id integer not null,
	username varchar_ignorecase(50) not null primary key,
	password varchar_ignorecase(500) not null,
    start_date date default current_timestamp,
    end_date date,
   	status_code varchar(1) default 'A',	
	last_login_ip varchar(50),
	last_login_date date,
	last_logout_date date,
	enabled boolean default true
);
--filePath=com/squaressolutions/template/dataSource/model/system/security/Users.java

drop table if exists authorities;
create table authorities
(
	id integer not null,
	username varchar_ignorecase(50) not null,
	authority varchar_ignorecase(50) not null,
	constraint fk_authorities_users foreign key(username) references users(username)
);
--filePath=com/squaressolutions/template/dataSource/model/system/security/Authorities.java

drop table if exists persistent_logins;
create table persistent_logins 
(
    username varchar(64) not null,
	series varchar(64) primary key,
	token varchar(64) not null,
	last_used timestamp not null
);
--filePath=com/squaressolutions/template/dataSource/model/system/security/PersistentLogins.java

drop table if exists identitis;
create table identitis
(
	username varchar_ignorecase(50) not null,
	identity varchar_ignorecase(50) not null,
	platform varchar_ignorecase(50) not null,
	organisation varchar_ignorecase(255) not null,
	constraint fk_identitis_users foreign key(username) references users(username)
);
--filePath=com/squaressolutions/template/dataSource/model/system/security/Identitis.java
create unique index ix_auth_username on authorities (username,authority);
