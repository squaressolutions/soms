insert into system ( id, name , description, copyright, status_code ) values (1, 'Security and Organization Management System','A security and organization interaction management system. No part of this software or its associated components may be copied, reproduced, rented or sold to any person or corporation without prior written approval of Squares Solutions Company.', 'Copyright &copy; @currentYear, Squares Solutions Company All Rights Reserved.','A');

insert into status ( id, name , description , status_code ) values (1, 'Active','Active Status','A');
insert into status ( id, name , description , status_code ) values (2, 'Inactive','Inactive Status','I');
insert into status ( id, name , description , status_code ) values (3, 'Pending','Pending Status','P');
insert into status ( id, name , description , status_code ) values (4, 'Waiting','Waiting Status','W');
insert into status ( id, name , description , status_code ) values (5, 'Delete','Delete Status','D');
insert into setting (id, name, description, setting_value) values (1, 'maximumSessions', 'Maximum number of Sessions allowed','3');
insert into setting (id, name, description, setting_value) values (2, 'maxInactiveInterval', 'Session Maximum Inactive Duration in Seconds','7200');
insert into setting (id, name, description, setting_value) values (3, 'maximumLoginAttempt', 'Login Maximum Attempt','3');
insert into setting (id, name, description, setting_value) values (4, 'loginAttemptTimeElapsed', 'Login AttemptLogin Time Elapsed in seconds','3600');
insert into setting (id, name, description, setting_value) values (5, 'rememberMeInHour', 'Remember Login in hour','2');
insert into setting (id, name, description, setting_value) values (6, 'allowLoginAttempts', 'Allow how many times of login attempt','3');
insert into setting (id, name, description, setting_value) values (7, 'attemptLogins', 'Allow storing password of attempter to login_audit','');
insert into setting (id, name, description, setting_value) values (8, 'loginSessionExpireTime', 'Set login session expire time in seconds (username:60)','');
insert into setting (id, name, description, setting_value) values (9, 'forceLoginDaysBeforeToday', 'Force to login when last login before number of days','30');
