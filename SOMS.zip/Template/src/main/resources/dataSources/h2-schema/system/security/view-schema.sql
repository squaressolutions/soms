drop view if exists users_v;
create view users_v as
select users.*, authorities.id as authorityId, authorities.authority from users,  authorities where users.username = authorities.username;