drop view if exists system_v;
