drop table if exists continent;
create table continent
( 
	id integer not null,
    name varchar(50) not null,
	short_name varchar(3) not null
);
--filePath=com/squaressolutions/template/dataSource/model/location/Continent.java

drop table if exists country;
create table country
( 
	id integer not null,
    name varchar(50) not null,
	short_name varchar(3) not null

);
--filePath=com/squaressolutions/template/dataSource/model/location/Country.java
