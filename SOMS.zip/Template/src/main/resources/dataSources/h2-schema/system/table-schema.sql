drop table if exists system;
create table system
( 
	id integer not null,
	 name varchar(50) not null,
	 description varchar(255),
	 copyright varchar(255),
	 status_code varchar(1)
);
--filePath=com/squaressolutions/template/dataSource/model/system/System.java


drop table if exists setting;
create table setting
( 
	 id integer not null,
	 name varchar(50) not null,
 	 description varchar(255) not null,
	 setting_value varchar(50) default '',
	 start_date date default current_timestamp,
	 end_date date,
	 status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/setting/Setting.java

drop table if exists setting_group;
create table setting_group
( 
	id integer not null,
	name varchar(50) not null,
	description varchar(255) not null,
 start_date date default current_timestamp,
 end_date date,
	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/setting/SettingGroup.java

drop table if exists setting_relationship;
create table setting_relationship
( 
	id integer not null,
	name varchar(50) not null,
	description varchar(255) not null,
	setting_group_id integer not null,
	setting_id integer not null,
        start_date date default current_timestamp,
        end_date date,
	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/setting/SettingRelationship.java

drop table if exists status;
create table status
( 
	id integer not null,
 name varchar(50) not null,
 description varchar(255),
	status_code varchar(1)
);
--filePath=com/squaressolutions/template/dataSource/model/system/Status.java

drop table if exists status_event;
create table status_event
( 
	id integer not null,
	linked_id integer not null,
	linked_table varchar(50) not null,
 start_date date default current_timestamp,
 end_date date,
	status_code varchar(1)
);
--filePath=com/squaressolutions/template/dataSource/model/system/StatusEvent.java
