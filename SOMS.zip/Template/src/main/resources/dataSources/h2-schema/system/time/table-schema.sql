drop table if exists month_name;
create table month_name
( 
	id integer not null,
	name varchar(10) not null,
	short_name varchar(3) not null
);
--filePath=com/squaressolutions/template/dataSource/model/system/MonthName.java

drop table if exists weekday_name;
create table weekday_name
( 
	id integer not null,
	name varchar(10) not null,
	short_name varchar(3) not null
);
--filePath=com/squaressolutions/template/dataSource/model/system/WeekdayName.java
