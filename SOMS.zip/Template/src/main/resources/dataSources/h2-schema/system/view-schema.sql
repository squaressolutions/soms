drop view if exists system_v;
create view system_v as
select system.*, status.name as status_name, status.description as status_description
from system as system, status as status
where system.status_code = status.status_code;