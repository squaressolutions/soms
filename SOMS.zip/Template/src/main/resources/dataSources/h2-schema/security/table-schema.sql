
drop table if exists status_event;
create table status_event
(    
	id integer not null,
	linked_id integer not null,
	linked_table varchar(50) not null,
    start_date date default current_timestamp,
    end_date date,
   	status_code varchar(1)
);