create dbadmin general_user password 'ItisNoGood';
create dbtester general_user password 'ItisNoGood';