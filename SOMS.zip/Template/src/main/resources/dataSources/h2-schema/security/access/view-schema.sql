drop view if exists permission_v;
drop table if exists status;
create linked table status('org.h2.Driver', 'jdbc:h2:file:C:/data/system', 'Admin32166765', '1tIsExcellent!', 'status');

drop view if exists permission_v;
create view permission_v as
select permission_right.*, status.name as status_name, status.description as status_description, status.status_code as status
from permission_right, status
where permission_right.status_code = status.status_code;
