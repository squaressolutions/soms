drop table if exists permission;
create table permission
(    
	id integer not null,
    name varchar(50) not null,
    description varchar(255),
    purpose varchar(225),
    organisation_id integer,
    start_date date default current_timestamp,
    end_date date,
   	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/access/Permission.java

drop table if exists permission_right;
create table permission_right
(    
	id integer not null,
    name varchar(50) not null,
    description varchar(255),
    access_right varchar(4),
    start_date date default current_timestamp,
    end_date date,
   	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/access/PermissionRight.java

drop table if exists identity;
create table identity
(    
	id integer not null,
        name varchar(50) not null,
        description varchar(255),
        organisation_id integer,
        start_date date default current_timestamp,
        end_date date,
   	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/access/Identity.java
