drop table if exists base_record;
create table base_record
(    
	id integer not null,
    category varchar(50) not null,
    item varchar(255),
    start_date date default current_timestamp,
    end_date date,
   	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/template/BaseRecord.java
drop table if exists tree_self;
create table tree_self
(    
	id integer not null,
    name varchar(50) not null,
    description varchar(255),
    parent_id integer,
    start_date date default current_timestamp,
    end_date date,
   	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/template/TreeSelf.java
drop table if exists tree_branch;
create table tree_branch
(    
	id integer not null,
    name varchar(50) not null,
    description varchar(255),
    start_date date default current_timestamp,
    end_date date,
   	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/template/TreeBranch.java
drop table if exists tree_leaf;
create table tree_leaf
(    
	id integer not null,
    name varchar(50) not null,
    description varchar(255),
    start_date date default current_timestamp,
    end_date date,
   	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/template/TreeLeaf.java
drop table if exists tree_branch_relationship;
create table tree_branch_relationship
(    
	id integer not null,
	first_branch_id integer,
	second_branch_id integer,
	relationship_group_id integer,
    start_date date default current_timestamp,
    end_date date,
   	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/template/TreeBranchRelationship.java
drop table if exists tree_leaf_relationship;
create table tree_leaf_relationship
(    
	id integer not null,
	first_branch_id integer,
	second_branch_id integer,
	relationship_group_id integer,
    start_date date default current_timestamp,
    end_date date,
   	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/template/TreeLeafRelationship.java
drop table if exists table_group;
create table table_group
(    
	id integer not null,
	name varchar(50) not null,
	description varchar(255) not null,
    start_date date default current_timestamp,
    end_date date,
   	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/template/TableGroup.java
drop table if exists table_item;
create table table_item
(    
	id integer not null,
	col_id integer not null,
	row_id integer not null,
	name varchar(50) not null,
	description varchar(255) not null,
    start_date date default current_timestamp,
    end_date date,
   	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/template/TableItem.java
drop table if exists table_relationship;
create table table_relationship
(    
	id integer not null,
	table_group_id integer,
	table_item_id integer,
	relationship_group_id integer,
    start_date date default current_timestamp,
    end_date date,
   	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/template/TableRelationship.java
drop table if exists status;
create table status
(    
	id integer not null,
    name varchar(50) not null,
    description varchar(255),
   	status_code varchar(1)
);
