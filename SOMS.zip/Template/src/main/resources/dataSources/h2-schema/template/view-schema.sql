select table_group.* from table_group,table_item, table_relationship, status 
where table_group.id = table_relationship.table_group_id
and table_relationship.table_item_id = table_item.id
and table_group.status_code = status.status_code;