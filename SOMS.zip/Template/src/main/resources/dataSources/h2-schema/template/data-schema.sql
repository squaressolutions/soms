insert into status ( id, name , description , status_code ) values (1, 'Active','Active Status','A');
insert into status ( id, name , description , status_code ) values (2, 'Inactive','Inactive Status','I');
