drop view if exists briefing_v;

