drop view if exists briefing_v;
create view briefing_v as
select briefing.*, status.name as status_name, status.description as status_description, status.status_code as status
from briefing ,status
where briefing.status_code = status.status_code;
