drop table if exists employment_group;
create table employment_group
(    
    id integer not null,
    name varchar(50) not null,
    description varchar(255),
    start_date date default current_timestamp,
    end_date date,
    status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/employment/EmploymentGroup.java

drop table if exists emp_grp_relationship;
create table emp_grp_relationship
(    
    id integer not null,
    first_employment_group_id integer,
    second_employment_group_id integer,
    relationship_group_id integer,
    start_date date default current_timestamp,
    end_date date,
    status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/employment/EmploymentGroupRelationship.java

drop table if exists employment;
create table employment
(    
    id integer not null,
    name varchar(50) not null,
    description varchar(255),
    start_date date default current_timestamp,
    end_date date,
    status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/employment/Employment.java

drop table if exists employment_attribute;
create table employment_attribute
(    
    id integer not null,
    name varchar(50) not null,
    description varchar(255),
    start_date date default current_timestamp,
    end_date date,
    status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/employment/EmploymentAttribute.java

drop table if exists emp_grp_emp_relationship;
create table emp_grp_emp_relationship
(    
    id integer not null,
    employment_group_id integer,
    employment_id integer,
    relationship_group_id integer,
    start_date date default current_timestamp,
    end_date date,
    status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/employment/EmploymentGroupEmploymentRelationship.java

drop table if exists staff;
create table staff
(    
    id integer not null,
    name varchar(50) not null,
    description varchar(255),
    start_date date default current_timestamp,
    end_date date,
    status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/employment/Staff.java

