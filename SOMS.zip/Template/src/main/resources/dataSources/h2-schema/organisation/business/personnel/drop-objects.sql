drop view if exists employment_v;

