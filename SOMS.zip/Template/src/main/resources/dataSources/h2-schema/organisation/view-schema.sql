drop view if exists org_res_v;
drop table if exists status;
create linked table status('org.h2.Driver', 'jdbc:h2:file:C:/data/system', 'Admin32166765', '1tIsExcellent!', 'status');

drop view if exists org_res_v;
create view org_res_v as
select org_res.id, organisation.id as organisation_id, organisation.name as organisation_name, status.name as status_name, status.description as status_description, status.status_code as status
from org_res, organisation, status
where org_res.id = organisation.id
and org_res.status_code = status.status_code;
