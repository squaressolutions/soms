drop view if exists person_v;
