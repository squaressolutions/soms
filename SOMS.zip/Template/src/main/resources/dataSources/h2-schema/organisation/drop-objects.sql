drop view if exists org_res_v CASCADE ;
drop view if exists resource_v CASCADE ;
drop view if exists scheduling_v CASCADE ;
drop view if exists briefing_v CASCADE ;
drop view if exists behaviour_v CASCADE ;
drop view if exists person_v CASCADE;
drop view if exists employment_v CASCADE;
