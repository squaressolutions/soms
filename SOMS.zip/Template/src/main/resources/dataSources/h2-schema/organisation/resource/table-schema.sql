//create linked table system('org.h2.Driver', 'jdbc:h2:file:C:/data/system', 'sa', '', 'system');
    
drop table if exists resource_group;
create table resource_group
(    
    id integer not null,
    name varchar(50) not null,
    description varchar(255),
    start_date date default current_timestamp,
    end_date date,
    status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/resource/ResourceGroup.java

drop table if exists res_grp_relationship;
create table res_grp_relationship
(    
    id integer not null,
    first_resource_group_id integer,
    second_resource_group_id integer,
    relationship_group_id integer,
    start_date date default current_timestamp,
    end_date date,
    status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/resource/ResourceGroupRelationship.java

drop table if exists resource;
create table resource
(    
    id integer not null,
    name varchar(50) not null,
    description varchar(255),
    start_date date default current_timestamp,
    end_date date,
    status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/resource/Resource.java

drop table if exists resource_attribute;
create table resource_attribute
(    
    id integer not null,
    name varchar(50) not null,
    description varchar(255),
    start_date date default current_timestamp,
    end_date date,
    status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/resource/ResourceAttribute.java

drop table if exists res_grp_res_relationship;
create table res_grp_res_relationship
(    
    id integer not null,
    resource_group_id integer,
    resource_id integer,
    relationship_group_id integer,
    start_date date default current_timestamp,
    end_date date,
    status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/resource/ResourceGroupResourceRelationship.java

