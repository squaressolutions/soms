drop view if exists behaviour_v;
create view behaviour_v as
select behaviour.*, behaviour_group.id as behaviour_group_id, behaviour_relationship.behaviour_group_id as rel_behaviour_group_id, behaviour_relationship.behaviour_id as rel_behaviour_id, status.status_code as status
from behaviour_group, behaviour, behaviour_relationship, status
where behaviour_group.id = behaviour_relationship.behaviour_group_id
and behaviour.id = behaviour_relationship.behaviour_id
and behaviour.status_code = status.status_code;