insert into brief_type (id, name, description) values (1, 'Security', 'Security Related Briefing');
insert into brief_type (id, name, description) values (2, 'Organisational', 'Organisation Related Briefing');
insert into brief_type (id, name, description) values (3, 'Operational', 'Operation Related Briefing');
insert into brief (id, name, description) values (1, 'Security Briefing', '');
insert into brief (id, name, description) values (2, 'Operation Briefing', '');
