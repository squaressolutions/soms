drop view if exists person_v;
drop view if exists person_name_v;
drop view if exists place_of_birth_v;
drop view if exists person_user_v;
drop view if exists user_no_person_v;


drop table if exists country;
create linked table country('org.h2.Driver', 'jdbc:h2:file:C:/data/system', 'Admin32166765', '1tIsExcellent!', 'country');
drop table if exists users;
create linked table users('org.h2.Driver', 'jdbc:h2:file:C:/data/system', 'Admin32166765', '1tIsExcellent!', 'users');

drop view if exists place_of_birth_v;
create view place_of_birth_v as
select place_of_birth.id as id, country.id as country_id, country.name as name, country.short_name, from place_of_birth, country
where country.id = place_of_birth.country_id;

drop view if exists person_name_v;
create view person_name_v as
select person.id as person_id,person_name.id as person_name_id, person_name_relationship.id as person_name_relationship_id, person_name.*
from person, person_name_relationship, person_name
where person.id = person_name_relationship.person_id
and person_name_relationship.id = person_name.id;

drop view if exists person_gender_v;
create view person_gender_v as
select person.id as person_id,gender.id as gender_id, person_gender_relationship.id as person_gender_relationship_id, gender.*
from person, person_gender_relationship, gender
where person.id = person_gender_relationship.person_id
and person_gender_relationship.gender_id = gender.id;

drop view if exists person_nationality_v;
create view person_nationality_v as
select person.id as person_id, person_nationality_relationship.id as person_nationality_relationship_id, nationality.*
from person, person_nationality_relationship, nationality
where person.id = person_nationality_relationship.person_id
and person_nationality_relationship.nationality_id = nationality.id;

drop view if exists person_user_v;
create view person_user_v as
select person.id as person_id, person_user_relationship.id as person_user_relationship_id, users.*
from person, person_user_relationship, users
where person.id = person_user_relationship.person_id
and person_user_relationship.user_id = users.id;

drop view if exists user_no_person_v;
create view user_no_person_v as
select person.id as person_id, person_user_relationship.id as person_user_relationship_id, users.*
from person, person_user_relationship, users
where person.id = person_user_relationship.person_id
and person_user_relationship.user_id = users.id
and users.id not in (select users.id from person_user_v);

drop view if exists person_v;
create view person_v as
select person.id, surname, given_name, person_name_relationship_id, gender_id, date_of_birth, person.start_date, person.end_date, place_of_birth_v.id as place_of_birth_id, place_of_birth_v.name as place_of_birth,
person_gender_relationship_id,person_gender_v.name as gender_name,person_gender_v.short_name as gender_short_name, person_nationality_relationship_id, person_nationality_v.name as nationality_name,
status.name as status_name, status.description as status_description, status.status_code
from person,person_name_v, place_of_birth_v, person_gender_v, person_nationality_v, status 
where person.place_of_birth_id = place_of_birth_v.id
and person.id = person_name_v.person_id
and person.id = person_gender_v.person_id
and person.id = person_nationality_v.person_id 
and person.status_code = status.status_code;


