insert into scheduler values (1, 5, '09:30', 'Security Briefing');
insert into scheduler values (2, 4, '08:30', 'Operation Briefing');
