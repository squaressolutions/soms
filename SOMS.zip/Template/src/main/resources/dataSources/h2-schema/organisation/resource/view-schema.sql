drop view if exists resource_v;
create view resource_v as
select resource.*, resource_group.id as resource_group_id, resource_group.name as resource_group_name,
res_grp_res_relationship.resource_group_id as rel_resource_group_id, res_grp_res_relationship.resource_id as rel_resource_id, status.status_code as status, status.name as status_name, status.description as status_description
from resource_group, resource, res_grp_res_relationship, status
where resource_group.id = res_grp_res_relationship.resource_group_id
and resource.id = res_grp_res_relationship.resource_id
and resource.status_code = status.status_code;
