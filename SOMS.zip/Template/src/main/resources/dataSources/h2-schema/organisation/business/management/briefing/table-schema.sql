drop table if exists brief_type;
create table brief_type
(    
	id integer not null,
        name varchar(50) not null,
        description varchar(255),
        purpose varchar(225),
        start_date date default current_timestamp,
        end_date date,
   	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/briefing/BriefType.java

drop table if exists brief;
create table brief
(    
	id integer not null,
        name varchar(50) not null,
        description varchar(255),
        purpose varchar(225),
        brief_type_id integer,
        organisation_id integer,
        start_date date default current_timestamp,
        end_date date,
   	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/briefing/Brief.java

drop table if exists briefing;
create table briefing
(    
	id integer not null,
	brief_id integer,
	briefer_person_id integer,
	briefing_location_id integer,
        description varchar(255),
        purpose varchar(225),
        start_date date default current_timestamp,
        end_date date,
   	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/briefing/Briefing.java

drop table if exists briefing_attendee;
create table briefing_attendee
(    
	id integer not null,
	briefer_id integer,
	attendee_person_id integer,
        start_date date default current_timestamp,
        end_date date,
   	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/briefing/BriefingAttendee.java