drop view if exists resource_v;
