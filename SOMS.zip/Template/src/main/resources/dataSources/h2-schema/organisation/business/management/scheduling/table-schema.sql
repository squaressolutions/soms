drop table if exists schedule_type;
create table schedule_type
(    
	id integer not null,
        name varchar(50) not null,
        description varchar(255),
        purpose varchar(225),
        start_date date default current_timestamp,
        end_date date,
   	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/scheduling/scheduleType.java

drop table if exists schedule;
create table schedule
(    
	id integer not null,
        name varchar(50) not null,
        description varchar(255),
        purpose varchar(225),
        schedule_type_id integer,
        organisation_id integer,
        start_date date default current_timestamp,
        end_date date,
   	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/scheduling/schedule.java

drop table if exists scheduling;
create table scheduling
(    
	id integer not null,
	schedule_id integer,
	scheduling_location_id integer,
    description varchar(255),
    purpose varchar(225),
    start_date date default current_timestamp,
    end_date date,
   	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/scheduling/scheduling.java