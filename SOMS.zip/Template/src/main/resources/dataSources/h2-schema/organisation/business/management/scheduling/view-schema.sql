drop view if exists scheduling_v;
create view scheduling_v as
select scheduling.*, status.name as status_name, status.description as status_description, status.status_code as status
from scheduling ,status
where scheduling.status_code = status.status_code;
