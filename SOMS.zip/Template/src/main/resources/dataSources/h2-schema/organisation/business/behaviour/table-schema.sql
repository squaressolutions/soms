drop table if exists behaviour_type;
create table behaviour_type
( 
	id integer not null,
	name varchar(50) not null,
	description varchar(255) not null,
 start_date date default current_timestamp,
 end_date date,
	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/behaviour/BehaviourType.java

drop table if exists behaviour;
create table behaviour
( 
	id integer not null,
	name varchar(50) not null,
	description varchar(255) not null,
 start_date date default current_timestamp,
 end_date date,
	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/behaviour/Behaviour.java

drop table if exists behaviour_group;
create table behaviour_group
( 
	id integer not null,
	name varchar(50) not null,
	description varchar(255) not null,
 start_date date default current_timestamp,
 end_date date,
	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/behaviour/BehaviourGroup.java

drop table if exists behaviour_relationship;
create table behaviour_relationship
( 
	id integer not null,
	name varchar(50) not null,
	description varchar(255) not null,
	behaviour_group_id integer not null,
	behaviour_id integer not null,
        start_date date default current_timestamp,
        end_date date,
	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/behaviour/BehaviourRelationship.java
