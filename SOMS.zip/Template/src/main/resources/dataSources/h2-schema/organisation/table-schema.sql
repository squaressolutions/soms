drop table if exists organisation;
create table organisation
(    
	id integer not null,
    name varchar(50) not null,
    description varchar(255),
    start_date date default current_timestamp,
    end_date date,
   	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/organisation/Organisation.java

drop table if exists organisation_relationship;
create table organisation_relationship
(    
	id integer not null,
	first_organisation_id integer,
	second_organisation_id integer,
	relationship_group_id integer,
    start_date date default current_timestamp,
    end_date date,
   	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/organisation/OrganisationRelationship.java

drop table if exists org_res;
create table org_res
(    
	id integer not null,
    name varchar(50) not null,
    description varchar(255),
    start_date date default current_timestamp,
    end_date date,
   	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/organisation/OrganisationResource.java

drop table if exists org_res_attribute;
create table org_res_attribute
(    
	id integer not null,
    name varchar(50) not null,
    description varchar(255),
    start_date date default current_timestamp,
    end_date date,
   	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/organisation/OrgResAttribute.java

drop table if exists status_event;
create table status_event
(    
	id integer not null,
	linked_id integer not null,
	linked_table varchar(50) not null,
    start_date date default current_timestamp,
    end_date date,
   	status_code varchar(1)
);