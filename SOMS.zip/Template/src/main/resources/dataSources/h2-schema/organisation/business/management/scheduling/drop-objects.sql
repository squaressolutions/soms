drop view if exists scheduling_v CASCADE ;
