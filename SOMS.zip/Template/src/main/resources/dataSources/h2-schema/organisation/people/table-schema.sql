drop view if exists person_v;
drop view if exists person_name_v;
drop view if exists place_of_birth_v;
drop view if exists person_gender_v;
drop view if exists person_nationality_v;
drop view if exists person_user_v;
drop view if exists user_no_person_v;

drop table if exists person;
create table person
(    
    id integer,
    date_of_birth date not null,
    place_of_birth_id integer not null,
    start_date date default current_timestamp,
    end_date date,
   	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/people/Person.java
drop table if exists person_name;
create table person_name
(    
    id integer,
    surname varchar(100) not null,
    given_name varchar(100) not null,
    start_date date default current_timestamp,
    end_date date,
    status_code varchar(1)
);
--filePath=com/squaressolutions/template/dataSource/model/people/PersonName.java
drop table if exists person_name_relationship;
create table person_name_relationship
(    
	id integer not null,
	person_id integer not null,
	person_name_id integer not null,
    start_date date default current_timestamp,
    end_date date,
   	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/people/PersonNameRelationship.java
drop table if exists place_of_birth;
create table place_of_birth
(    
    id integer,
    country_id integer not null,
    state_id integer default -1,
    region_id integer default -1
    
);
--filePath=com/squaressolutions/template/dataSource/model/people/PlaceOfBirth.java
drop table if exists gender;
create table gender
(    
    id integer,
    name varchar(50) not null,
    short_name varchar(3) not null,
    description varchar(255),
    start_date date default current_timestamp,
    end_date date,
    status_code varchar(1)
);
--filePath=com/squaressolutions/template/dataSource/model/people/Gender.java

drop table if exists person_gender_relationship;
create table person_gender_relationship
(    
	id integer not null,
	person_id integer not null,
	gender_id integer not null,
    start_date date default current_timestamp,
    end_date date,
   	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/people/PersonGenderRelationship.java
drop table if exists nationality;
create table nationality
(    
    id integer,
    name varchar(50) not null,
    short_name varchar(3) not null,
    country_id integer not null,
    start_date date default current_timestamp,
    end_date date,
    status_code varchar(1)
);
--filePath=com/squaressolutions/template/dataSource/model/people/Nationality.java
drop table if exists person_nationality_relationship;
create table person_nationality_relationship
(    
	id integer not null,
	person_id integer not null,
	nationality_id integer not null,
    start_date date default current_timestamp,
    end_date date,
   	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/people/PersonNationalityRelationship.java
drop table if exists person_user_relationship;
create table person_user_relationship
(    
	id integer not null,
	person_id integer not null,
	user_id integer not null,
    start_date date default current_timestamp,
    end_date date,
   	status_code varchar(1) default 'A'
);
--filePath=com/squaressolutions/template/dataSource/model/people/PersonUserRelationship.java

