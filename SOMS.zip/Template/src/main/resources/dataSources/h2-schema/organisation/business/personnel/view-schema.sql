drop view if exists employment_v;
create view employment_v as
select employment.*, employment_group.id as employment_group_id, employment_group.name as employment_group_name,
emp_grp_emp_relationship.employment_group_id as rel_employment_group_id, emp_grp_emp_relationship.employment_id as rel_employment_id, status.status_code as status, status.name as status_name, status.description as status_description
from employment_group, employment, emp_grp_emp_relationship, status
where employment_group.id = emp_grp_emp_relationship.employment_group_id
and employment.id = emp_grp_emp_relationship.employment_id
and employment.status_code = status.status_code;
