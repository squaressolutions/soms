package com.squaressolutions.common.view.model;

import java.io.Serializable;

import lombok.Data;
@Data
public class PageValidator implements Serializable {
	private String value;
	private String validator;
	private String checker;
	private String checkedValue;
	private String message;
}
