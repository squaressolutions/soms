package com.squaressolutions.common.view.model;

import java.io.Serializable;
import java.util.List;

import jakarta.annotation.Resource;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

@Data
public class PageWorkflow extends BaseElement implements Serializable{
	private List commands;
	private List serviceClassPaths;
	public PageWorkflow() {
		super();
	}	
	public PageWorkflow(String jsonStr) {
			super();
		ObjectMapper mapper = new ObjectMapper();
		try {
			PageWorkflow workflow = mapper.readValue(jsonStr, PageWorkflow.class);
			this.setCommands(workflow.getCommands());
			this.setServiceClassPaths(workflow.getServiceClassPaths());
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
