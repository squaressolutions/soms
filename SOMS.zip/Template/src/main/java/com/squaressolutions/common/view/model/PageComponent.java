package com.squaressolutions.common.view.model;

import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import lombok.Data;
@Data
public class PageComponent extends PageElement implements BeanNameAware, Serializable{
	private String beanName;
	private PageWorkflow workflow;
	private PageMessager messager;
	private PageDataSource dataSource;
}
