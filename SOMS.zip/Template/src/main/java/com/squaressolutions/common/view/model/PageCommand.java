package com.squaressolutions.common.view.model;

import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.BeanNameAware;

import com.squaressolutions.template.service.ServiceConstants;

import lombok.Data;

@Data
public class PageCommand extends BaseElement implements Serializable{
	private BaseElement instruction;
	private String script;
	private String permissions;
	public PageCommand() {
		super();
	}
	public PageCommand(String script) {
		super();
		this.script = script;
		this.instruction.setText(ServiceConstants.EMPTY);
	}
	public String toString() {
		return this.script;
	}
}
