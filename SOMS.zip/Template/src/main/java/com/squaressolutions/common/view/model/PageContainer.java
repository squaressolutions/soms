package com.squaressolutions.common.view.model;

import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import lombok.*;

@Data
public class PageContainer extends PageElement  implements BeanNameAware, Serializable{
	String beanName;
	private List<PageContainer> subContainers;
	private List<PageComponent> components;
	private PageWorkflow workflow;
	private PageMessager messager;
	private PageDataSource dataSource;
}
