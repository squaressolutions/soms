package com.squaressolutions.common.view.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import jakarta.persistence.Entity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
public class Page extends PageElement implements Serializable{
	private String uiPath;
	private List<?> defaults;
	private List<?> containers;
	private PageWorkflow workflow;
}
