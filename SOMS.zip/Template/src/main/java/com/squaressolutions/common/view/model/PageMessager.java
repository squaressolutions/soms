package com.squaressolutions.common.view.model;

import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.BeanNameAware;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.Data;

@Data
public class PageMessager extends PageElement implements BeanNameAware, Serializable{
	String beanName;
	private List messages;
	private List shownMessages;
	public PageMessager() {
		super();
	}
	public PageMessager(String jsonStr) {
		super();
		ObjectMapper mapper = new ObjectMapper();
		try {
			PageMessager messager = mapper.readValue(jsonStr, PageMessager.class);
			this.setName(messager.getName());
			this.setMessages(messager.getMessages());
			//this.setMessages(messager.getShownMessages());
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}	
}
