package com.squaressolutions.common.view.model;

import java.io.Serializable;
import java.util.List;

import org.springframework.stereotype.Component;

import lombok.Data;

@Data
public class PageElement implements Serializable{
	private String name;
	private String type;
	private BaseElement label;
	private BaseElement description;
	private BaseElement prompt;
	private List formats;
	private List icons;
	private List behaviours;
	private List associations;
	private List validators;
	public PageElement() {
		super();
	}
	public PageElement(String label) {
		super();
		this.label.setText(label);
	}
	public String toString() {
		return this.label.getText();
	}
}
