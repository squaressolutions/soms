package com.squaressolutions.common.view.model;

import java.io.Serializable;
import java.util.List;

import org.springframework.stereotype.Component;

import lombok.Data;


@Data
public class PageDataSource implements Serializable{
	private String dataSourceConfigPath;
	private String id;
	private String parentId;
	private List<?> queries;
	private List<?> data;
	private String format;
	public List getQueries() {
		return queries;
	}
	public List getData() {
		return data;
	}
}
