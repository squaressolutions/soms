package com.squaressolutions.template.service.setup;

import java.io.BufferedReader;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import com.squaressolutions.template.service.ServiceBase;
import com.squaressolutions.template.service.ServiceConstants;
import com.squaressolutions.template.service.util.ResourceFileService;


@Profile("setup")
public class ConfigViewFileService  extends ResourceFileService implements ServiceBase{
	
	public static final String JAVA_SOURCE_PATH = "/src/main/java/";
	public static final String FILE_PATH_SCHEMA = "--filePath=";
	public static final String INTERFACE = "--interface=";
	public static final String EXTENDS = "--extends=";
	public static final String PACKAGE_PATH_SEGMENT = "package ";
	
	@Autowired
	PojoService service;
	@Override
	protected boolean processLines(BufferedReader br) throws IOException {
		//create domain object
		String out = ServiceConstants.EMPTY;
		service.preProcess();
		String line;
		service.preProcess();
		while ((line = br.readLine()) != null) {
			int i = line.indexOf(FILE_PATH_SCHEMA);
			if (i == 0) {
				out = (String) service.postProcess(out);
				String filePath = line.substring(i + FILE_PATH_SCHEMA.length());
				out = service.setEntity(filePath, out);
				String packagePath = filePath.substring(0, filePath.lastIndexOf(ServiceConstants.BACK_SLASH));
				
				
				packagePath = packagePath.replace(ServiceConstants.BACK_SLASH, ServiceConstants.DOT);
				out = PACKAGE_PATH_SEGMENT + packagePath + ServiceConstants.SEMICOLON + ServiceConstants.NEW_LINE + ServiceConstants.NEW_LINE + out;
				writeFile(filePath, out);
				out = ServiceConstants.EMPTY;
				// break;
			} else {
				out += service.process(line);
			}
		}
		return true;
	}
	@Override
	protected void writeFile(String javaPath, String text) throws IOException {
		String fileSeparator = System.getProperty(ServiceConstants.FILE_SEPARATOR_SYSTEM_PROPERTY_NAME);
		String userDir = System.getProperty(ServiceConstants.USER_DIR_SYSTEM_PROPERTY_NAME);
		javaPath = userDir + JAVA_SOURCE_PATH + javaPath;
		javaPath = javaPath.replace(ServiceConstants.BACK_SLASH, fileSeparator);
		super.writeFile(javaPath, text);	
	}
}
