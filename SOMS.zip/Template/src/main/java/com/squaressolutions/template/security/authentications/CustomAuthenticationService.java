package com.squaressolutions.template.security.authentications;

import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

public interface CustomAuthenticationService {
	public DaoAuthenticationProvider authenticationProvider(PasswordEncoder passwordEncoder);
	public UserDetailsService getUserDetailsService(PasswordEncoder passwordEncoder);
}
