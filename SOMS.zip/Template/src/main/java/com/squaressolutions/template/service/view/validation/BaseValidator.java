package com.squaressolutions.template.service.view.validation;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.squaressolutions.template.service.ServiceBase;
import com.squaressolutions.template.service.ServiceConstants;

public interface BaseValidator extends Validator, ServiceBase {
	static final String EQUAL = "=";
	static final String GREATER_EQUAL = ">=";
	static final String EQUAL_GREATER = "=>";
	static final String LESS_EQUAL = "<=";
	static final String EQUAL_LESS = "=<";
	static final String GREATER = ">";
	static final String LESS = "<";
	boolean supports(Class<?> clazz);
	void validate(Object target, Errors errors);
}
