package com.squaressolutions.template.service.view.validation.genernal;

import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;

import com.squaressolutions.common.view.model.PageComponent;
import com.squaressolutions.common.view.model.PageContainer;
import com.squaressolutions.template.controller.BaseController;
import com.squaressolutions.template.service.ServiceBase;
import com.squaressolutions.template.service.ServiceConstants;
import com.squaressolutions.template.service.business.BusinessService;
import com.squaressolutions.template.service.util.ClassService;
import com.squaressolutions.template.service.util.LoggerService;
import com.squaressolutions.template.service.util.StringService;

@Service
public class ContainerValidator implements ServiceBase {

	private static final String VALIDATOR_LABEL_NAME = "@name";
	private static final String VALIDATOR_LABEL_LABEL = "@label";
	private static final String VALIDATOR_LABEL_VALUE = "@value";
	private static final String VALIDATOR_LABEL_CHECKER = "@checker"; 
	private static final String VALIDATOR_LABEL_CHECKED_VALUE = "@checkedValue"; 
	private static final String VALIDATION_PROCESS_ERROR = "Validation process error!"; 
	
	public BindingResult validateContainer(PageContainer container, BindingResult result, int dataIndex, BusinessService businessService) {
		List validators = container.getValidators();
		if (validators != null) {
			String jsonStr = validators.toString();	
			jsonStr = jsonStr.replaceAll(VALIDATOR_LABEL_NAME, container.getName());
			jsonStr = setCompnentVaule(container, dataIndex, jsonStr);
			String message = validate(jsonStr, ServiceConstants.EMPTY, businessService);
			if (StringUtils.hasLength(message)) {
				container.getMessager().getShownMessages().add(message);
				result.reject(message);
			}
		}
		return result;
	}
	public BindingResult validateComponents(PageContainer container, BindingResult result, int dataIndex, BusinessService businessService) {
		for (int i=0; i<container.getComponents().size(); i++) {
			PageComponent component = container.getComponents().get(i);
			if (StringUtils.hasLength(component.getName()) && component.getFormats() != null) {
				
				if (component.getValidators() != null && component.getValidators().size() > 0) {
					String value = String.valueOf(component.getDataSource().getData().get(dataIndex));
					if (!value.startsWith("{bcrypt}")) {
						String jsonStr = component.getValidators().toString();
						jsonStr = StringService.formatATString(jsonStr, (String) VALIDATOR_LABEL_NAME + component.getName());
						jsonStr = jsonStr.replaceAll(VALIDATOR_LABEL_NAME, component.getName());
						jsonStr = jsonStr.replaceAll(VALIDATOR_LABEL_LABEL, component.getLabel().getText());
						jsonStr = jsonStr.replaceAll(VALIDATOR_LABEL_VALUE, value);
						String message = validate(jsonStr, value, businessService);
						if (StringUtils.hasLength(message)) {
							result.rejectValue(BaseController.componentKey(i),message, message); 
						}
					}
				}
			}
		};		
		return result;
	}
	private String validate(String validatorStr, String value, BusinessService businessService) {
		JSONArray jsonArray = StringService.stringToJsonArray(validatorStr);
		for (int i=0; i<jsonArray.size(); i++) {
			JSONObject json = (JSONObject) jsonArray.get(i);
			String checker = (String) json.get("checker");
			String checkedValue = (String) json.get("checkedValue");
			String validator = (String) json.get("validator");
			if (value.isEmpty()) {
				value = (String) json.get("value");
			}
			
			String message = (String) json.get("message");
			message = message.replaceAll(VALIDATOR_LABEL_CHECKER, checker);
			message = message.replaceAll(VALIDATOR_LABEL_CHECKED_VALUE, checkedValue);
			value = businessService.getValue(populateDataSourcePath(value));			
			checkedValue = businessService.getValue(populateDataSourcePath(checkedValue));
			
			String classMethodParts[] = validator.split(ServiceConstants.COLUMN);
			try {
				boolean isValid = (boolean) ClassService.callClassMethod(classMethodParts, new String[]{checker, value, checkedValue});	
				if (!isValid) {
					return message;
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return VALIDATION_PROCESS_ERROR;
			}

		};
 		return ServiceConstants.EMPTY;
	}
	private String populateDataSourcePath(String text) {
		if (text != null && text.contains(ServiceConstants.AT)) {
			ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("config/ui/dataSourceConfig.xml");
			String atStr = StringService.extractATString(text, String.valueOf(ServiceConstants.COLUMN));
			String path = context.getBean(atStr.substring(1), String.class);
			text = text.replaceAll(atStr, path);
		}		
		return text;
	}
	private String setCompnentVaule(PageContainer container, int dataIndex, String text) {
		for (int i=0; i<container.getComponents().size(); i++) {
			if (((PageComponent) container.getComponents().get(i)).getDataSource() != null) {
				String value= ((PageComponent) container.getComponents().get(i)).getDataSource().getData().get(dataIndex).toString();
				text = text.replace(ServiceConstants.AT + BaseController.componentKey(i), value);
			}
		}
		return text;
	}

}
