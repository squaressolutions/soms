package com.squaressolutions.template.dataSource.model.system.security;

import jakarta.persistence.Entity;
import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import org.hibernate.annotations.GenericGenerator;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;
import java.util.Date;

import org.springframework.stereotype.Component;
import lombok.Data;

@Component
@Entity(name="persistent_logins")
@Data
public class PersistentLogins {
	@Id
	@GeneratedValue(generator = "increment")
	@GenericGenerator(name="increment", strategy = "increment")
	@NotNull
	@Size(min=1, max = 64)
	@Column(name = "username")
	private String username;
	@Size(min=1, max = 64)
	@Column(name = "series")
	private String series;
	@NotNull
	@Size(min=1, max = 64)
	@Column(name = "token")
	private String token;
	@NotNull
	@Column(name = "last_used")
	private Date lastUsed;

}