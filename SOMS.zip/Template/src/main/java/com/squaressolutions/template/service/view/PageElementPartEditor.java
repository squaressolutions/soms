package com.squaressolutions.template.service.view;

import java.beans.PropertyEditorSupport;
import java.util.List;

import org.springframework.beans.PropertyEditorRegistrar;
import org.springframework.beans.PropertyEditorRegistry;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.squaressolutions.common.view.model.BaseElement;
import com.squaressolutions.common.view.model.PageValidator;
import com.squaressolutions.template.service.ServiceConstants;

@Service
public class PageElementPartEditor  extends PropertyEditorSupport implements PropertyEditorRegistrar {
	 
    @Override
    public String getAsText() {
		BaseElement part = (BaseElement) getValue();
        return part == null ? ServiceConstants.EMPTY : part.getText();
    }
    
    @Override
    public void setAsText(String text) throws IllegalArgumentException {
		BaseElement part = new BaseElement(ServiceConstants.EMPTY);
		part.setText(text);
    }

	@Override
	public void registerCustomEditors(PropertyEditorRegistry registry) {
        registry.registerCustomEditor(BaseElement.class,this);		
	}
}
