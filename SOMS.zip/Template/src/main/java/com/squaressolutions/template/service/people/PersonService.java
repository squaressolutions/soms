package com.squaressolutions.template.service.people;

import org.springframework.stereotype.Service;

import com.squaressolutions.common.view.model.PageComponent;
import com.squaressolutions.common.view.model.PageContainer;
import com.squaressolutions.template.dataSource.model.people.PersonGenderRelationship;
import com.squaressolutions.template.dataSource.model.people.PersonNameRelationship;
import com.squaressolutions.template.dataSource.model.people.PersonNationalityRelationship;
import com.squaressolutions.template.dataSource.model.people.PersonUserRelationship;
import com.squaressolutions.template.service.ServiceBase;
import com.squaressolutions.template.service.ServiceConstants;
import com.squaressolutions.template.service.view.PageHelper;


@Service
public class PersonService implements ServiceBase{
	public Object setObject(Object[] objects) {
		PageContainer container = (PageContainer) objects[1];
		PageComponent component = null;
		String value = PageHelper.getComponentValueByName(container, "personId", component);
		
		if (objects[0].getClass().getName().equals(PersonNameRelationship.class.getName())) {
			PersonNameRelationship relationship = (PersonNameRelationship) objects[0];
			relationship.setPersonId(Long.valueOf(value));
			value = PageHelper.getComponentValueByName(container, "PersonNameRelationshipId", component);
			if (!value.isEmpty()) {
				relationship.setId(Long.valueOf(value));
			}
			value = PageHelper.getComponentValueByName(container, "PersonNameid", component);
			if (!value.isEmpty()) {
				relationship.setPersonNameId(Long.valueOf(value));
			}
		}

		if (objects[0].getClass().getName().equals(PersonGenderRelationship.class.getName())) {
			PersonGenderRelationship relationship = (PersonGenderRelationship) objects[0];
			relationship.setPersonId(Long.valueOf(value));
			value = PageHelper.getComponentValueByName(container, "PersonGenderRelationshipId", component);
			if (!value.isEmpty()) {
				relationship.setId(Long.valueOf(value));
			}
			value = PageHelper.getComponentValueByName(container, "Genderid", component);
			if (!value.isEmpty()) {
				relationship.setGenderId(Long.valueOf(value));
			}
		}
		if (objects[0].getClass().getName().equals(PersonNationalityRelationship.class.getName())) {
			PersonNationalityRelationship relationship = (PersonNationalityRelationship) objects[0];
			relationship.setPersonId(Long.valueOf(value));
			value = PageHelper.getComponentValueByName(container, "PersonNationalityRelationshipId", component);
			if (!value.isEmpty()) {
				relationship.setId(Long.valueOf(value));
			}
			value = PageHelper.getComponentValueByName(container, "NationalityId", component);
			if (!value.isEmpty()) {
				relationship.setNationalityId(Long.valueOf(value));
			}
		}
		if (objects[0].getClass().getName().equals(PersonUserRelationship.class.getName())) {
			PersonUserRelationship relationship = (PersonUserRelationship) objects[0];
			relationship.setPersonId(Long.valueOf(value));
			value = PageHelper.getComponentValueByName(container, "PersonUserRelationshipId", component);
			if (!value.isEmpty()) {
				relationship.setId(Long.valueOf(value));
			}
			value = PageHelper.getComponentValueByName(container, "UserId", component);
			if (!value.isEmpty() && Long.valueOf(value) != ServiceConstants.INVALID) {
				relationship.setUserId(Long.valueOf(value));
			} else {
				return null;
			}
		}
    	return objects[0];    	
    }
	
}
