package com.squaressolutions.template.service.util;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.util.StringUtils;

import com.squaressolutions.template.service.ServiceConstants;

public class StringService {

	public StringService() {
	}
	public static int count(String line, char myChar) {	
		int count = 0;
		for (int i = 0; i < line.length(); i++) {
		    if (line.charAt(i) == myChar) {
		        count++;
		    }
		}
		return count;
	}
	public static String setDoubleQuotes(String value) {
		return value;
	}
  	public static String replaceFirstQustionMark(String line, String value) {
		if (StringUtils.hasLength(line) && StringUtils.hasLength(value)) {
			line = line.replaceFirst(ServiceConstants.QUESTION_MARK_SCAPE, value);
		}
		return line;
	}	
  	public static  JSONArray stringToJsonArray(String jsonString) {
		JSONParser parser = new JSONParser();
		JSONArray jsonArray = new JSONArray(); 
		try {
			jsonString = jsonString.replaceAll(ServiceConstants.LEFT_SQUARE_BLACKET, ServiceConstants.EMPTY).replaceAll(ServiceConstants.RIGHT_SQUARE_BLACKET,ServiceConstants.EMPTY);
			String[] jsonStrArray = jsonString.split("}"+ServiceConstants.COMMA);
			for (int i=0; i<jsonStrArray.length; i++) {
				if (!jsonStrArray[i].isBlank()) {
					if (!jsonStrArray[i].endsWith("}")) {
						jsonStrArray[i] = jsonStrArray[i]+"}";
					}
					JSONObject json = (JSONObject) parser.parse(jsonStrArray[i]);
					jsonArray.add(json);
				}
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return jsonArray;
	}
  	public static boolean processPurge(String orgDataString, String dataString) {
		//todo set the model status to inactive
		System.out.println("*****old******"+ orgDataString);
		JSONArray jsonArray = stringToJsonArray(orgDataString); 
		if (!StringUtils.hasLength(dataString)) {
			System.out.println("**"+jsonArray.size());
		}
		return true;
	}
  	public static String formatATString(String message, String replacement) {
		if (StringUtils.hasLength(replacement)) {
			String[] keyValuePair = replacement.split(ServiceConstants.COLUMN);
			if (keyValuePair.length < 2) {
				message = message.replaceAll(ServiceConstants.AT + keyValuePair[0], ServiceConstants.EMPTY);				
			} else {
				message = message.replaceAll(ServiceConstants.AT + keyValuePair[0], keyValuePair[1]);
			}
		}
		return message;
	}
  	public static String extractATString(String text, String end) {
  		return extractString(text, String.valueOf(ServiceConstants.AT), end);
  	}
    public static boolean startsWith(String obj, String elements) {
    	//accept string of elements with comma separation
    	String[] array = elements.split(ServiceConstants.COMMA);
    	return startsWith(obj, array);
    }
    public static boolean startsWith(String obj, String[] array) {
        for (String element : array) {
            if (obj.startsWith(element)) {
                return true;
            }
        }
        return false;
    }

  	public static String extractString(String text, String from, String end) {
  		if (!text.endsWith(end)) {
  			text = text + end;
  		}
  		return text.substring(text.indexOf(from), text.indexOf(end, text.indexOf(from)));
  	}
  	
}
