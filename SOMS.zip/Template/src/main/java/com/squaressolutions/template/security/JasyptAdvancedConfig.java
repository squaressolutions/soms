package com.squaressolutions.template.security;

import org.jasypt.encryption.StringEncryptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JasyptAdvancedConfig {
	   @Bean("jasyptStringEncryptor")
	    public StringEncryptor stringEncryptor() {
		   return JasyptAdvancedService.stringEncryptor();
	}
}