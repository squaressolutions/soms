package com.squaressolutions.template.service.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.squaressolutions.template.service.ServiceBase;
import com.squaressolutions.template.service.ServiceConstants;


@Service
public class FileService implements ServiceBase {
	protected File getFileFromResources(String filePath) {
	    ClassLoader classLoader = getClass().getClassLoader();
	    URL resource = classLoader.getResource(filePath);
	    if (resource ==  null) {
	        return new File(ServiceConstants.EMPTY);
	    } else {
	        return new File(resource.getFile());
	    }
	}
	public boolean process(String filePath) {
		File file = getFileFromResources(filePath);
		if (file.exists()) {		
			try (FileReader reader = new FileReader(file);
				BufferedReader br = new BufferedReader(reader)) {
				return processLines(br);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}
	public void writeFile(String filePath, String text) throws IOException 
	{  
		File file = new File(filePath);
		file.getParentFile().mkdirs();
	    BufferedWriter writer = new BufferedWriter(new FileWriter(filePath));
	    writer.write(text);
	    writer.close();
	}
	public void writeFile(String filePath, ArrayList dataList) throws IOException 
	{  
		if (dataList.size() > 0) {
			File file = new File(filePath);
			file.getParentFile().mkdirs();
		    BufferedWriter writer = new BufferedWriter(new FileWriter(filePath));
		    dataList.forEach(text -> {
				try {
					writer.write(String.valueOf(text));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});	    			
		    writer.close();
		}
	}
	public void deleteFile(String filePath) {
		File file = new File(filePath);
		file.delete();
		
	}
	protected boolean processLines(BufferedReader br) throws IOException {
		return true;	
	}
}
