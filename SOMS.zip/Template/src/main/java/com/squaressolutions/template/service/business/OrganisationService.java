package com.squaressolutions.template.service.business;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import com.squaressolutions.common.view.model.Page;
import com.squaressolutions.template.security.authentication.user.AppUser;
import com.squaressolutions.template.service.business.model.PositionProfile;
import com.squaressolutions.template.service.util.LoggerService;

@Service
public class OrganisationService {
	
//	public String getOrgHierarchy (AppUser user) {
//		return getPositionProfile("config/organisation/squaressolutions/division/section/config.xml", -1).getOrgHierarchyPath();		
//	}
//	public String getHomePage () {
//		return getPositionProfile("config/organisation/squaressolutions/division/section/config.xml", -1).getHomePage();		
//	}
//	private PositionProfile getPositionProfile(String path, long userPositionId) {
//		try {
//			ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(path);
//			return (PositionProfile) context.getBean(PositionProfile.class.getName());	
//		} catch (Exception e) {
//			LoggerService.error("Specified path " + path + " in organisationqqq folder doesn't exist");
//			e.printStackTrace();
//			return null;
//		}	
//
//	}
	public PositionProfile loadPositionProfile(String path) {
		path = "config/organisation/squaressolutions/division/section/config.xml";
		try {
			ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(path);
			PositionProfile positionProfile = (PositionProfile) context.getBean(PositionProfile.class.getSimpleName());	
			LoggerService.debug("********"+ positionProfile);
			return positionProfile;
		} catch (Exception e) {
			LoggerService.error("Specified path " + path + " doesn't exist");
			e.printStackTrace();
			return new PositionProfile();
		}	
	}
}
