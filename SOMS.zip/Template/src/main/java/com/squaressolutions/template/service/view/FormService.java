package com.squaressolutions.template.service.view;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.squaressolutions.common.view.model.PageContainer;
import com.squaressolutions.template.controller.BaseController;
import com.squaressolutions.template.service.ServiceBase;
import com.squaressolutions.template.service.ServiceConstants;
import com.squaressolutions.template.service.util.ClassService;
import com.squaressolutions.template.service.util.DateService;
import com.squaressolutions.template.service.util.LoggerService;

@Service
public class FormService implements ServiceBase{
	public Object processForm(Object[] paraObjects) {
		PageContainer container = (PageContainer) paraObjects[0];
		String modelPackagePath = (String) paraObjects[1];
		logger.debug("Form Service processes form");
		try {
			Class<?>[] classes = ClassService.findAllConfigurationClassesInPackage(modelPackagePath,container.getName());
			if (classes.length > 0 && container.getComponents() != null) {
				Class<?> theClass = classes[0];
				Object classObj = theClass.getDeclaredConstructor().newInstance();
			    Method[] allMethods = theClass.getDeclaredMethods();
			    
				container.getComponents().forEach(component -> {
					String fieldName = component.getName();
					if (fieldName != null && !fieldName.isEmpty())  {
						String myMethod = "set" + StringUtils.capitalize(fieldName);
						String theType = ServiceConstants.EMPTY;
						Method method = null;
				        for (Method m : allMethods) {
				            if (m.getName().toLowerCase().equals(myMethod.toLowerCase())) {
				                theType = m.getParameterTypes()[0].toString().split(" ")[1];	
				                method = m;
				            }
				        }  
						try {
							String value = (String) component.getDataSource().getData().get(1);
							
							if (theType.equals(Date.class.getTypeName()) && StringUtils.hasLength(value)) {
								method.invoke(classObj, DateService.format(value));
							} else if (theType.equals(String.class.getTypeName())) {
								method.invoke(classObj, value);
							} else if (!theType.isEmpty()){
								Class<?> paraC = Class.forName(theType);
								if (value != null && !value.isEmpty()) {
									Object o = castObject(paraC, value);	
									method.invoke(classObj, o);
								} else {
									logger.debug(theType + " value is " + value);
								}
							}
						} catch (IllegalArgumentException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (NoSuchMethodException e) {
							logger.debug("Component " + fieldName +" cannot find "+ myMethod);
							e.printStackTrace();
						} catch (SecurityException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IllegalAccessException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (InvocationTargetException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (ClassNotFoundException e) {
							logger.debug("Component " + fieldName +" cannot find "+ myMethod);
							e.printStackTrace();
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
				logger.debug("Process Form returns");
				return (classObj);
			} else {
				logger.debug("Annotation is not set for " + container.getName());
				return null;
			}	
		} catch (IllegalArgumentException | SecurityException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (InstantiationException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IllegalAccessException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (InvocationTargetException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (NoSuchMethodException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return new Object();
	}
	public <T> T castObject(Class<T> clazz, Object object) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		  Method method = clazz.getMethod("valueOf", String.class);
		  return (T) method.invoke(clazz, object);
		}
}
