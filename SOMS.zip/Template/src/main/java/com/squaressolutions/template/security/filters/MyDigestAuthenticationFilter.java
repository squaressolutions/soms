package com.squaressolutions.template.security.filters;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.www.DigestAuthenticationEntryPoint;
import org.springframework.security.web.authentication.www.DigestAuthenticationFilter;

public class MyDigestAuthenticationFilter extends DigestAuthenticationFilter {
	//sample codes only, they may have not been implemented probably and they certainly have not been tested.
	@Autowired
	UserDetailsService userDetailsService;

	private DigestAuthenticationEntryPoint entryPoint() {
	    DigestAuthenticationEntryPoint result = new DigestAuthenticationEntryPoint();
	    result.setRealmName("My App Relam");
	    result.setKey("3028472b-da34-4501-bfd8-a355c42bdf92");
	    return result;
	}

	private DigestAuthenticationFilter digestFilter() {
	    DigestAuthenticationFilter result = new DigestAuthenticationFilter();
	    result.setUserDetailsService(userDetailsService);
	    result.setAuthenticationEntryPoint(entryPoint());
	    return result;
	}

}
