package com.squaressolutions.template.security.aspectj;

import java.util.Date;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import com.squaressolutions.template.security.authentication.user.AppUser;
import com.squaressolutions.template.service.util.LoggerService;


@Aspect
@Component
public class UserAccessAspect extends AccessAspect {
	
	@After(value = "execution(* com.squaressolutions.template.controller.*.*(..))")
	public void afterReturning(JoinPoint joinPoint) {
		process(joinPoint);
	}
	@Override
	public AppUser setOrCheck(AppUser user) {
		if (Math.random()*40 == 2) {
			LoggerService.showCaller();
			user.setKey();
		}
		return user;
	};
}
