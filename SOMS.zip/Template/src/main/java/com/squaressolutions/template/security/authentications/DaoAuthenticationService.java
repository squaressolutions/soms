package com.squaressolutions.template.security.authentications;

import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

public interface DaoAuthenticationService {
	public DaoAuthenticationProvider authenticationProvider(PasswordEncoder passwordEncoder);
}
