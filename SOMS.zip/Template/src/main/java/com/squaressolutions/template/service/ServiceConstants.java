package com.squaressolutions.template.service;

public class ServiceConstants {
	public static String FILE_SEPARATOR_SYSTEM_PROPERTY_NAME = "file.separator";
	public static String USER_DIR_SYSTEM_PROPERTY_NAME = "user.dir";
	public static final CharSequence AT = "@";
	public static final String UNDERSCORE = "_";
	public static final String DASH = "-";
	public static final String SPACE1 = " ";
	public static final String EMPTY = "";
	public static final String DOT = ".";
	public static final String COMMA = ",";
	public static final String PIPE = "|";
	public static final String BACK_SLASH = "/";
	public static final String FORWARD_SLASH = "\\";
	public static final String LEFT_BRACKET = "(";
	public static final String RIGHT_BRACKET = ")";
	public static final String NEW_LINE = "\n";
	public static final String SEMICOLON = ";";
	public static final String QUOTATION_MARK = "\"";
	public static final String SINGLE_QUOTE = "\'";
	public static final String QUESTION_MARK = "?";
	public static final String QUESTION_MARK_SCAPE = "\\?";
	public static final String EQUAL = "=";
	public static final String COLUMN = ":";
	public static final String AMPERSEND = "&";
	public static final String 	LEFT_SQUARE_BLACKET = "\\[";
	public static final String 	RIGHT_SQUARE_BLACKET = "\\]";
	public static final String EXCLAMATION = "!";
	public static final String SQL_PREFIX = "SQL:";
	public static final long INVALID = -1;
	public static final String TEXT_FILE_EXT = ".txt";
	public static final String ERROR_FILE_EXT = ".err";
}
