package com.squaressolutions.template.controller;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.ConstraintViolationException;

import java.io.IOException;
import java.nio.file.AccessDeniedException;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.NoHandlerFoundException;

import com.squaressolutions.template.service.Exception.RecordNotFoundException;
import com.squaressolutions.template.service.util.LoggerService;

@Profile("!dev")
@ControllerAdvice
public class ExceptionHandlingController {
	@Value("${spring.profiles.active}")
	private String activeProfile;
	
	// Total control - setup a model and return the view name yourself. Or
	// consider subclassing ExceptionHandlerExceptionResolver (see below).
	@ExceptionHandler(Exception.class)
	public ModelAndView handleError(HttpServletRequest req, Exception ex) {
	LoggerService.debug("Request: " + req.getRequestURL() + " raised " + ex.fillInStackTrace().toString());        
	ModelAndView mav = new ModelAndView();
	mav.addObject("exception", ex);
	mav.addObject("url", req.getRequestURL());
	if(!(activeProfile.isEmpty() || activeProfile.equalsIgnoreCase("prod"))) 
	{
		mav.addObject("errorMessage", ex.getMessage());
	}
	mav.setViewName(GenericWebController.MAPPING_ERROR);
	return mav;
	 }
	@ExceptionHandler(RecordNotFoundException.class)
	public ResponseEntity<ErrorResponse> customHandleNotFound(Exception ex, WebRequest request) {
	
	    ErrorResponse errors = new ErrorResponse();
	    errors.setTimestamp(LocalDateTime.now());
	    errors.setError(ex.getMessage());
	    errors.setStatus(HttpStatus.NOT_FOUND.value());
	
	    return new ResponseEntity<>(errors, HttpStatus.NOT_FOUND);
	 
	}
	
	// @Validate For Validating Path Variables and Request Parameters
	@ExceptionHandler(ConstraintViolationException.class)
	public void constraintViolationException(HttpServletResponse response) throws IOException {
	    response.sendError(HttpStatus.BAD_REQUEST.value());
	}
	@ExceptionHandler({ AccessDeniedException.class })
	public ResponseEntity<Object> handleAccessDeniedException(
	  Exception ex, WebRequest request) {
	    return new ResponseEntity<Object>(
	      "Access denied message here", new HttpHeaders(), HttpStatus.FORBIDDEN);
	  }
	  
	  // Specify name of a specific view that will be used to display the error:
	  @ExceptionHandler({DataAccessException.class})
	  public String databaseError() {
	    // Nothing to do.  Returns the logical view name of an error page, passed
	    // to the view-resolver(s) in usual way.
	    // Note that the exception is NOT available to this view (it is not added
	    // to the model) but see "Extending ExceptionHandlerExceptionResolver"
	    // below.
	    return "databaseError";
	  }

	// error handle for @Valid
	   // @Override
	protected ResponseEntity<Object>
	handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
	                             HttpHeaders headers,
	                             HttpStatus status, WebRequest request) {
	    Map<String, Object> body = new LinkedHashMap<>();
	    body.put("timestamp", new Date());
	body.put("status", status.value());
	
	        BindingResult result = ex.getBindingResult();
	        FieldError fieldError = result.getFieldError();
	        String code = fieldError.getCode();
	        String field = fieldError.getField();
	        String message = fieldError.getDefaultMessage();
	   
	        //Get all fields errors
	List<String> errors = ex.getBindingResult()
	        .getFieldErrors()
	        .stream()
	        .map(x -> x.getDefaultMessage())
	        .collect(Collectors.toList());
	
	body.put("errors", errors);
	
	        return new ResponseEntity<>(body, headers, status);
	
	  }
}
