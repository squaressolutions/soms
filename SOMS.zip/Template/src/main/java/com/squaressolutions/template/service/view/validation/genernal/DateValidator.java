package com.squaressolutions.template.service.view.validation.genernal;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;

import org.springframework.validation.Errors;

import com.squaressolutions.template.service.ServiceBase;
import com.squaressolutions.template.service.ServiceConstants;
import com.squaressolutions.template.service.util.DateService;
import com.squaressolutions.template.service.view.validation.BaseValidator;

public class DateValidator implements BaseValidator{
	public boolean validate(Object[] parasIn) throws Exception {
		String[] paras = (String[]) parasIn;
		return validate(paras[0], paras[1]);
	}
	private boolean validate(String dateFormat, String dateStr) throws Exception {
		try {
			LocalDate localDate = DateService.formatToLocalDate(dateStr,dateFormat);
			return !localDate.toString().isEmpty();
		} catch (Exception e) {
			logger.debug(dateStr +" date or " + dateFormat + " date format could be invalid.");
			e.printStackTrace();
		}
		return false;
	}
	public boolean compare(Object[] parasIn) {
		String[] paras = (String[]) parasIn;
		String dateFormat = DateService.getGlobalFormat();
		try {
			LocalDate localDate1 = DateService.formatToLocalDate(paras[1],dateFormat);
			LocalDate localDate2 = DateService.formatToLocalDate(paras[2],dateFormat);
			logger.debug(localDate1 + "   "+ paras[0] + "   "+localDate2);			
			switch (paras[0]) {
			case EQUAL:
				return localDate1.isEqual(localDate2);
			case LESS:
				return localDate1.isBefore(localDate2);
			case GREATER:
				return localDate1.isAfter(localDate2);
			case EQUAL_LESS:
			case LESS_EQUAL:
				return localDate1.isEqual(localDate2) || localDate1.isBefore(localDate2);
			case EQUAL_GREATER:
			case GREATER_EQUAL:
				return localDate1.isEqual(localDate2) || localDate1.isAfter(localDate2);
			}
		} catch (Exception e) {
			logger.debug(paras[1] +" date or " + paras[1] +" checher or " + dateFormat + " date format could be invalid.");
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean supports(Class<?> clazz) {
		return Date.class.equals(clazz);
	}
	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
		
	}
}
