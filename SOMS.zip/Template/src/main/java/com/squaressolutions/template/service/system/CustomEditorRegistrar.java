package com.squaressolutions.template.service.system;

import org.springframework.beans.PropertyEditorRegistrar;
import org.springframework.beans.PropertyEditorRegistry;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;

import com.squaressolutions.common.view.model.BaseElement;
import com.squaressolutions.template.service.view.PageElementPartEditor;

public class CustomEditorRegistrar implements PropertyEditorRegistrar 
{
    public void registerCustomEditors(PropertyEditorRegistry registry) 
    {
        registry.registerCustomEditor(BaseElement.class, 
                new PageElementPartEditor());
    }
}