/*
 * Copyright 2020-2024 the original author or authors.
 *
 * Licensed under the Non-Profit Open Software License version 3.0 (the "NPOSL-3.0");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://opensource.org/licenses/NPOSL-3.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.squaressolutions.template.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.squaressolutions.common.view.model.Page;
import com.squaressolutions.common.view.model.PageCommand;
import com.squaressolutions.common.view.model.PageComponent;
import com.squaressolutions.common.view.model.PageContainer;
import com.squaressolutions.common.view.model.PageDataSource;
import com.squaressolutions.common.view.model.PageMessager;
import com.squaressolutions.common.view.model.PageValidator;
import com.squaressolutions.template.security.LoginAttemptService;
import com.squaressolutions.template.security.auditing.AuditAppService;
import com.squaressolutions.template.service.ServiceConstants;
import com.squaressolutions.template.service.business.BusinessService;
import com.squaressolutions.template.service.business.OrganisationService;
import com.squaressolutions.template.service.business.model.PositionProfile;
import com.squaressolutions.template.service.util.ClassService;
import com.squaressolutions.template.service.util.DateService;
import com.squaressolutions.template.service.util.FileService;
import com.squaressolutions.template.service.util.HttpRequestHelper;
import com.squaressolutions.template.service.util.LoggerService;
import com.squaressolutions.template.service.util.StringService;
import com.squaressolutions.template.service.view.PageHelper;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


public abstract class BaseController implements Serializable{

	private static final long serialVersionUID = -5883490788491390791L;
	
	public static final String UI_WEB_CONFIG_FOLDER="/config/ui/web";
	public static final String UI_MOBILE_CONFIG_FOLDER="/config/ui/mobile";
	public static final String UI_BUSINESS_CONFIG_FOLDER="/config/ui/business";
	public static final String PARENT_ID = "pid";
	public static final String ID_PARA = "id";
	protected static final String PAGE = "page";
	protected static final String FORM = "form";
	protected static final String CONTAINER = "container";
	protected static final String LOGIN_CONTAINER = "Login";
	protected static final String HTML_TAG_DATA_ATTRIBUTE="dataAttribute";
	
	protected static final int COMMAND_PAGE_REQUEST = 0;
	protected static final int COMMAND_BODY_REQUEST = 1;
	protected static final int COMMAND_MODAL_REQUEST = 2;
	protected static final int COMMAND_ERROR_PAGE = 2;
	protected static final int COMMAND_PATH_SUBMIT_RESULT = 1;
	public static final String HOME_REDIRECT_PAGE = "redirect:/home";
	protected static final String ERROR_REDIRECT_PAGE = "/error";
	private static final String PERSISTENCE_PROCESS_ERROR = "Persistence process error!"; 

	
	public static final int FORM_DATA = 0;
	public static final int FORM_FIELD = 1;
	private static final int MESSAGE_ADD_SUCCESS = 0;
	private static final int MESSAGE_UPDATE_SUCCESS = 1;
	private static final int MESSAGE_DELETE_SUCCESS = 2;
	private static final int MESSAGE_ADD_FAIL = 3;
	private static final int MESSAGE_UPDATE_FAIL = 4;
	private static final int MESSAGE_DELETE_FAIL = 5;
	
	public static final int FORMAT_TYPE_INDEX = 0;
	public static final int FORMAT_CLASS_INDEX = 1;
	public static final int FORMAT_STYLE_INDEX = 2;
	public static final int FORMAT_MASK_INDEX = 3;
	public static final int FORMAT_EXTRA_INDEX = 4;
	
public static final int DATA_QUERY_INDEX_DEFAULT = 0;
	public static final int DATA_QUERY_INDEX_SELECTED = 1;
	
	public static final int FORMAT_DISPLAY_MODE = 0;
	public static final int FORMAT_DATABASE_MODE = 1;
	
	public static final String LOGIN_RETURN_ERROR = "Error";
	public static final String LOGIN_RETURN_FAILED = "Failed";
	public static final String LOGIN_RETURN_BLOCKED = "Blocked";
	public static final String LOGIN_RETURN_EXPIRED = "Expired";
	public static final String LOGIN_RETURN_INVALID = "Invalid";
	public static final String LOGIN_RETURN_LOGOUT = "Logout";

	private ApplicationContext context;
	
	@Value("${model.package.path}")
	private String modelPackagePath;	
	
	@Autowired
	HttpRequestHelper httpRequestHelper;
    @Autowired
    private HttpSession httpSession;
    
	@Autowired
	private BusinessService businessService;
	@Autowired
	LoginAttemptService loginAttemptService;	
	
	@Autowired
	FileService fileService;
	
	@Autowired
	AuditAppService auditAppService;

		
	public String handleLoginRequest(String pa, Model model, HttpServletRequest request, HttpServletResponse response) {
        String url = handleRequest(pa, model);

        Page p = (Page) model.getAttribute(PAGE);        
		PageContainer loginContainer = PageHelper.getContainer(p, LOGIN_CONTAINER);
		if (loginContainer != null) {
			loginContainer = initialShownMessage (loginContainer);
	
			String sessionStatus = (String) request.getSession().getAttribute(LoginAttemptService.REQ_STATUS);		
			if (sessionStatus != null) {
		    	if (sessionStatus.contains(LOGIN_RETURN_ERROR)) {
		    		loginContainer.getMessager().getShownMessages().add(loginContainer.getMessager().getMessages().get(0));
		    	} else if (sessionStatus.contains(LOGIN_RETURN_FAILED)) {
		    		slowReply(loginAttemptService.getAttempted(request));
		    		loginContainer.getMessager().getShownMessages().add(loginContainer.getMessager().getMessages().get(1).toString().replaceFirst(ServiceConstants.QUESTION_MARK_SCAPE, String.valueOf(loginAttemptService.getAttempted(request))));
		    	} else if (sessionStatus.contains(LOGIN_RETURN_BLOCKED)) {
		    		slowReply(loginAttemptService.getAttempted(request));
		    		loginContainer.getMessager().getShownMessages().add(loginContainer.getMessager().getMessages().get(2));	
		    		//loginContainer = disableLoginForm(loginContainer);
		    	} else if (sessionStatus.contains(LOGIN_RETURN_EXPIRED)) {
		    		loginContainer.getMessager().getShownMessages().add(loginContainer.getMessager().getMessages().get(3));	
		    	} else if (sessionStatus.contains(LOGIN_RETURN_INVALID)) {
		    		loginContainer.getMessager().getShownMessages().add(loginContainer.getMessager().getMessages().get(4));	
		    	} else if (sessionStatus.contains(LOGIN_RETURN_LOGOUT)) {
		    		loginContainer.getMessager().getShownMessages().add(loginContainer.getMessager().getMessages().get(5));	
		    	}
		    }
			response.setStatus(HttpServletResponse.SC_ACCEPTED);
		} else {
			LoggerService.error("***Longin c is null");
			url = ERROR_REDIRECT_PAGE;
		}

		if (request.getUserPrincipal() != null) {
			try {
				PositionProfile positionProfile = (new OrganisationService()).loadPositionProfile("");	
				response.sendRedirect(positionProfile.getHomePagePath());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}		
		return url;	
	}

	public String handleRequest(String pa, Model model) {
 		return handleRequest("","", pa, model);
	}
	public byte[] getFavicon() {
	    try {
			return getImageWithMediaType("/static/img/favicon.ico");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    return new byte[0];
	}
	public String handleRequest(String id, String pid, String pa, Model model) {	
		auditAppService.set(getCurrentHttpRequest());
		String url = ERROR_REDIRECT_PAGE;
		if (pa == null || pa.isBlank()) {
			url = HOME_REDIRECT_PAGE;
		}
		Page p = loadPage(new Page(), PAGE);
		p = preparePage(p, id, pid, pa);
		if (p !=null && p.getContainers() != null) {
	    	//prepare the c for the f object matching
			prepareData(p, model);
//			p cache needs to be tested
//	    	try {
//				savePage(p, httpSession.getId());
//				p = loadPage(p, httpSession.getId());
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			} 
//			Properties properties = PropertyService.loadProperty("static/js/ui_web.properties");
//			model.addAttribute(PROPERTIES,properties);
			HttpServletRequest request = getCurrentHttpRequest();
			PageContainer f = (PageContainer) request.getSession().getAttribute(FORM);
			if (f != null) {
				
				p.setContainers(PageHelper.replaceContainer(p.getContainers(), f.getName(), f));				
				request.getSession().removeAttribute(FORM);
			}
			
			model.addAttribute(PAGE,p);
			if (p.getWorkflow() != null) {
				url = (String) p.getWorkflow().getCommands().get(COMMAND_PAGE_REQUEST);			
			}
		} else {
			LoggerService.debug("*** Path is empty " + pa);
		}
		return url;
	}
	
	public String handleInternalRequest(String id, String pid, String pa, String containerName, Model model) {
		String url = handleRequest(id, pid, pa, model);
	   	Page p = (Page) model.getAttribute(PAGE);

		List<PageContainer> containers = (List<PageContainer>) p.getContainers();
		PageContainer c = PageHelper.getContainer(p, containerName);		

		HttpServletRequest request = getCurrentHttpRequest();
		
		PageContainer f = (PageContainer) request.getSession().getAttribute(FORM);
		
		PageContainer theContainer;
		if (f != null) {
			theContainer = PageHelper.findContainer(c.getSubContainers(), f.getName(), null);
			if (theContainer != null) {
				theContainer.setComponents(f.getComponents());
				theContainer.setMessager(f.getMessager());
			}
			request.getSession().removeAttribute(FORM);
		} else {
			theContainer = c;
		}
		
		containers.clear();
		containers.add(theContainer);

		p.setContainers(containers);

		model.addAttribute(PAGE, p);
		url = (String) p.getWorkflow().getCommands().get(COMMAND_BODY_REQUEST);
	   	return url;
	}
	public String handleModalRequest(String id, String pid, String pa, String containerName, Model model) {
		String url = handleRequest(id, pid, pa, model);
		
	   	Page p = (Page) model.getAttribute(PAGE);

		List<PageContainer> containers = (List<PageContainer>) p.getContainers();
		PageContainer c = PageHelper.getContainer(p, containerName);		

		containers.clear();
		containers.add(c);
		p.setContainers(containers);

		model.addAttribute(PAGE, p);
		url = (String) p.getWorkflow().getCommands().get(COMMAND_MODAL_REQUEST);
	   	return url;
	}
	//http://localhost:8080/modal?configPath=config/ui/business/organisation/change_gender_form.xml&containerName=main
	//To have both Hibernate and Spring validator. Remove the @InitBinder
	 /*@InitBinder
	 protected void initBinder(WebDataBinder binder) {
	 	binder.setValidator(new UserFormValidator());
	 }*/
	public String handleSubmit(PageContainer c,  BindingResult result, Model model) {
		HttpServletRequest request = getCurrentHttpRequest();
		auditAppService.set(request);

		String buffer = "buffer/" + httpRequestHelper.getUserName(request) + ServiceConstants.UNDERSCORE + DateService.getTodayDate() + ServiceConstants.UNDERSCORE + httpRequestHelper.getRequestedSessionId(request);
		try {
			fileService.writeFile(buffer + ServiceConstants.TEXT_FILE_EXT, c.toString());
			String url = processContainer(c, result, model);
			if (result.hasErrors()) {
				fileService.writeFile(buffer + ServiceConstants.ERROR_FILE_EXT, result.getAllErrors().toString());			
			} else {	
				fileService.deleteFile(buffer + ServiceConstants.TEXT_FILE_EXT);
				fileService.deleteFile(buffer + ServiceConstants.ERROR_FILE_EXT);
			}
			return url;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}
	public String handleListSubmit(PageContainer c,  BindingResult result, Model model) {
		auditAppService.set(getCurrentHttpRequest());
		String url = (String) c.getWorkflow().getCommands().get(COMMAND_PATH_SUBMIT_RESULT);
		var orgDataString = c.getComponents().get(c.getComponents().size()-1).getDataSource().getData().get(0).toString();
		var dataString = c.getComponents().get(c.getComponents().size()-1).getDataSource().getData().get(1).toString();
		//processPurge(orgDataString, dataString);
		int messageIndex = MESSAGE_UPDATE_SUCCESS;
		c = initialShownMessage (c);
		c.getMessager().getShownMessages().add(c.getMessager().getMessages().get(messageIndex));	  
		url = processDataString(c,  result, model, dataString, url);
		return url;
	}
	public String handleDataRequest(String id, String pid, String comIndex, String containerName, String pa, Model model) {
		auditAppService.set(getCurrentHttpRequest());
		LoggerService.debug("handle data request called"+ pa);
		String url = ERROR_REDIRECT_PAGE;
		Page p = loadPage(new Page(), PAGE);
		
		p = preparePage(p, id, pid, pa);
 
		int dataQueryIndex = DATA_QUERY_INDEX_SELECTED;
		if (comIndex !=null) {
			dataQueryIndex = Integer.valueOf(comIndex);
		}		
		PageDataSource datasource = null;
		if (containerName == null || containerName.equals(ServiceConstants.EMPTY)) {
			PageComponent cp = PageHelper.findComponentByType(p.getContainers(), "Data", null);
	    	if (cp != null && cp.getDataSource().getQueries() != null
	    			&& cp.getDataSource() != null
	    			&& cp.getDataSource().getQueries().size() > dataQueryIndex) {
	    		datasource = cp.getDataSource();
	    	}
			
		} else {
			PageContainer c = PageHelper.findContainer(p.getContainers(), containerName, null);
			if (c != null && c.getDataSource() != null && c.getDataSource().getQueries().size() > dataQueryIndex) {
				datasource = c.getDataSource();
			}
		}
    	if (datasource != null) {
    		String query = datasource.getQueries().get(dataQueryIndex).toString(); 
    		query = setQuery(query, pid);
	    	query = setQuery(query, id);
	    	datasource.getQueries().set(dataQueryIndex,query);
			ArrayList<String[]> dataList = businessService.getData(datasource, dataQueryIndex);
			List<?> data = dataList;
			String dataString = ServiceConstants.EMPTY;
			if (data.size() > 0) {
				if (data.get(0).getClass().getTypeName().equals(String.class.getTypeName())) {
					dataString = (String) data.get(0);
				} else {
					dataString = data.toString();
				}
				return dataString;
			}
			return ServiceConstants.EMPTY;
		} else {
			LoggerService.debug("*** Path is empty " + pa);
		}
		return ServiceConstants.EMPTY;
	}
	public static String componentKey(int index) {
		return "components[" + String.valueOf(index) + "]";
	}
//	private Page prepareOauth2LoginPage(Page p) {
//	    Iterable<ClientRegistration> clientRegistrations = null;
//	    ResolvableType type = ResolvableType.forInstance(clientRegistrationRepository)
//	      .as(Iterable.class);
//	    if (type != ResolvableType.NONE && 
//	      ClientRegistration.class.isAssignableFrom(type.resolveGenerics()[0])) {
//	        clientRegistrations = (Iterable<ClientRegistration>) clientRegistrationRepository;
//	    }
//	 
//	    clientRegistrations.forEach(registration -> {
//	      String client = registration.getClientName(); 
//	      String url = authorizationRequestBaseUri + "/" + registration.getRegistrationId();
//	    });
//	    return p;
//	}
	private PageComponent searchComponent(List containers, String name) {
		for (int i=0; i<containers.size(); i++) {
			List components = ((PageContainer) containers.get(i)).getComponents();
			for (int j=0; j<components.size(); j++) {
				if (((PageComponent)components.get(j)).getName().equals(name)) {
					return (PageComponent) components.get(j);
				}
			}
			searchComponent(((PageContainer)containers.get(i)).getSubContainers(), name);
		}
		return null;
	}
	private PageContainer initialShownMessage(PageContainer c) {
		if (c.getMessager().getShownMessages() == null) {
			c.getMessager().setShownMessages(new ArrayList<String>());			
		}
		return c;
	}
	private String processDataString(PageContainer c,  BindingResult result, Model model, String dataString, String url) {
		if (!dataString.isBlank()) {
			String objects[] = dataString.split(ServiceConstants.SEMICOLON);
			for (int i=0; i<objects.length; i++){
				String data[] = objects[i].split(ServiceConstants.COMMA);
				c.setWorkflow(c.getWorkflow());
				for (int j=0; j<data.length; j++) {
					c.getComponents().get(j).getDataSource().getData().set(FORM_FIELD,data[j]);
				}
				url = processContainer(c, result, model);
			}
		}
		return url;
	}
	private String setQuery(String query, String value) {
		if (value != null) {
			query = query.replace(ServiceConstants.QUESTION_MARK, value);
		}
		return query;
	}
	private String constructPath(String pa) {
	// toDo set default pa properly
	//	FileService.getFileInPath
		if (!pa.contains(ServiceConstants.BACK_SLASH)) {
			pa = UI_WEB_CONFIG_FOLDER + ServiceConstants.BACK_SLASH + pa;
		}
		return pa;
	}
	private Page getPage(String pa) {
		pa = constructPath(pa);		
		try {
			ApplicationContext c = context;
			c = new ClassPathXmlApplicationContext(pa);
			return (Page) c.getBean(PAGE);	
		} catch (Exception e) {
			LoggerService.error("Specified pa " + pa + " in the url parameter doesn't exist");
			e.printStackTrace();
			return null;
		}	
	}
	private Page preparePage(Page p, String id,String pid, String pa) {
		if (StringUtils.hasLength(pa)) {
			p = getPage(pa);
			if (p != null) {
				p.getContainers().forEach(c -> {
					prepareContainers((PageContainer) c, id, pid);
				});
			} else {
				LoggerService.error("Specified pa " + pa + " in the url parameter doesn't exist");
				return null;
			}
		} else {
			LoggerService.error("Path in the url parameter doesn't exist");
			if (p == null) {
				LoggerService.error("ConfigSet is null");
			}
		}
		return p;
	}
	private PageContainer prepareContainers(PageContainer c, String id, String pid) {
		c = prepareContainer((PageContainer) c, id, pid);		
		((PageContainer) c).getSubContainers().forEach(subContainer ->{
			prepareContainers((PageContainer) subContainer, id, pid);						
		});	
		return c;
	}
	private PageContainer prepareContainer(PageContainer c, String id, String pid) {
		if (c != null) {
			c = setName(c);
			c = setData(c, id, pid);
			((PageContainer) c).getComponents().forEach(cp ->{
				cp = prepareComponent(cp);
				if (cp.getDataSource() != null && cp.getDataSource().getQueries() != null) {
					cp = setData(cp, id, pid);
				} else {
					cp = initialComponentDataList(cp);
				}
			});	
		}
		return c;
	}
	private PageContainer disableLoginForm(PageContainer f) {
		if (f != null) {				
			for (int i=0; i<f.getWorkflow().getCommands().size(); i++) {
				PageCommand c = (PageCommand) f.getWorkflow().getCommands().get(i);
			    if (c.getInstruction() != null ) {					    	
			    	c.getInstruction().setText(c.getInstruction().getText().replaceAll ("(?i)submit", "disabled"));
			    }
		    }
	   	}
		return f;
	}
	private PageComponent initialComponentDataList(PageComponent cp) {
		if (cp.getDataSource() == null) {
			cp.setDataSource(new PageDataSource());
		}
		cp.getDataSource().setData(new ArrayList());
		cp.getDataSource().getData().add(ServiceConstants.EMPTY);
		cp.getDataSource().getData().add(ServiceConstants.EMPTY);
		return cp;
	}
	private PageContainer setName(PageContainer c) {
		if (c.getName() == null) {
			c.setName(ServiceConstants.EMPTY);
		}
		c.setName(c.getName().replace("@id", c.getBeanName()));
		return c;
	}
	
//	private PageContainer setHtmlTagDataAttribute(PageContainer c) {
//		if (c.getFormats().size() > FORMAT_EXTRA_INDEX) {
//			String[] dataAttributePart = c.getFormats().get(FORMAT_EXTRA_INDEX).toString().split(ServiceConstants.EQUAL);	
//			if (dataAttributePart.length > 1) {
//				servletContext.setAttribute(HTML_TAG_DATA_ATTRIBUTE, dataAttributePart[0]);
//				c.getFormats().set(FORMAT_EXTRA_INDEX,dataAttributePart[1]);				
//			}
//		}
//		return c;
//	}
	private PageContainer setData(PageContainer c, String id, String pid) {
		if (c.getDataSource().getQueries().size() > 0) {
			c.getDataSource().setId(id);
			c.getDataSource().setParentId(pid);
			c.setDataSource(replaceQueryIds(c.getDataSource()));
			c = getData(c);
		}
		return c;	
	}
	private PageComponent setData(PageComponent cp, String id, String pid) {
		if (cp.getDataSource().getQueries().size() > 0) {
			cp.getDataSource().setId(id);
			cp.getDataSource().setParentId(pid);
			cp.setDataSource(replaceQueryIds(cp.getDataSource()));
			cp = getData(cp);
		}
		return cp;	
	}
	private Page prepareData(Page p, Model model) {
		p.getContainers().forEach(c -> {
			prepareContainerRecord((PageContainer) c, model);
		});		
		return p;
	}
	private PageContainer prepareContainerRecord(PageContainer c, Model model) {
		if (((PageContainer) c) != null && ((PageContainer) c).getFormats().size()>0){
			loadRecord((PageContainer) c);
			c = formatComponents(c, FORMAT_DISPLAY_MODE);
			model.addAttribute(((PageContainer) c).getName(), c);	
		}
		((PageContainer) c).getSubContainers().forEach(subContainer ->{
			prepareContainerRecord(((PageContainer) subContainer), model);
		});
		return c;
	}
	private PageContainer loadRecord(PageContainer c) {	
		if (c.getDataSource() != null && c.getDataSource().getData().size() > 0) {
			c.setComponents(list2Components((List<Object>) c.getDataSource().getData(), c.getComponents()));
		}
		return c;
	}
	private List<PageComponent> list2Components(List<Object> dataList, List<PageComponent> components) {
		if (dataList.get(FORM_DATA).toString() != ServiceConstants.EMPTY) {			
			Map<String, Object> data = (Map<String, Object>) dataList.get(FORM_DATA);
			data.keySet().forEach(key -> key.replaceAll("_", ""));
			
			for (int i=0; i<components.size(); i++) {
				PageComponent cp = components.get(i);
				Object recValue = data.get(cp.getName().toUpperCase());
				if (recValue != null) {
					cp.getDataSource().getData().set(FORM_FIELD, recValue);	
					cp = prepareComponent(cp);
					components.set(i, cp);
				}				
			}		
		}
		return components;
	}
	private PageComponent prepareComponent(PageComponent cp) {
		cp = setName(cp);
		cp = replaceGlobalValue(cp);
//		cp = setToggleValue(cp);
		return cp;
	}
	private PageComponent setName(PageComponent cp) {
		try {
			if (cp.getName() == null) {
				cp.setName(ServiceConstants.EMPTY);
			}
			cp.setName(cp.getName().replace("@id", cp.getBeanName()));
		} catch (Exception e) {
			LoggerService.error("Set cp Id " + cp.getBeanName());
			e.printStackTrace();
		}
		return cp;
	}
	private PageDataSource replaceQueryIds(PageDataSource dataSource) {
		if (dataSource.getQueries() != null) {
			for (int i=0; i<dataSource.getQueries().size(); i++) {
				String query = (String) dataSource.getQueries().get(i);
				String id = dataSource.getId();
				if (query.contains(ServiceConstants.QUESTION_MARK) && id != null) {
					query = StringService.replaceFirstQustionMark(query, id);
				}
				String pid = dataSource.getParentId();
				if (query.contains(ServiceConstants.QUESTION_MARK) && pid != null) {
					query = StringService.replaceFirstQustionMark(query, pid);
				}
				dataSource.getQueries().set(i, query);			
			}
		}
		return dataSource;
	}	
	@Value("${app.title}")
	private String appTitle;
	@Value("${app.logo}")
	private String appLogo;
	@Value("${app.environment}")
	private String appEnvironment;
	@Value("${app.copyright}")
	private String appCopyright;
	
	private PageComponent replaceGlobalValue(PageComponent cp) {
		cp = replaceValue(cp, "@login", businessService.getUserLogin());
		cp = replaceValue(cp, "@appTitle", appTitle);
		cp = replaceValue(cp, "@appLogo", appLogo);
		cp = replaceValue(cp, "@appEnvironment", appEnvironment);
		cp = replaceValue(cp, "@appCopyright", appCopyright);
		cp = replaceValue(cp, "@dateFormat", DateService.getGlobalFormat());
		cp = replaceValue(cp, "@currentYear", DateService.getCurrentYear());
		cp = replaceValue(cp, "@todayDate", DateService.getTodayDate());
		return cp;
	}
	private PageComponent replaceValue(PageComponent cp, String notion, String value) {
		cp.getLabel().setText(cp.getLabel().getText().replace(notion, value));
		cp.getDescription().setText(cp.getDescription().getText().replace(notion, value));
		cp.getPrompt().setText(cp.getPrompt().getText().replace(notion, value));
		for(int i=0; i<cp.getFormats().size(); i++) {
			cp.getFormats().set(i, cp.getFormats().get(i).toString().replace(notion, value));
		}
		for(int i=0; i<cp.getBehaviours().size(); i++) {
			cp.getBehaviours().set(i, cp.getBehaviours().get(i).toString().replace(notion, value));
		}
		for(int i=0; i<cp.getValidators().size(); i++) {
			PageValidator validator = (PageValidator) cp.getValidators().get(i);
			validator.setChecker(validator.getChecker().replace(notion, value));
			validator.setCheckedValue(validator.getCheckedValue().replace(notion, value));
			validator.setMessage(validator.getMessage().replace(notion, value));
			validator.setValue(validator.getValue().replace(notion, value));
			
		}
		if (cp.getDataSource() != null) {
			if (cp.getDataSource().getQueries() != null) {
				for(int i=0; i<cp.getDataSource().getQueries().size(); i++) {
					cp.getDataSource().getQueries().set(i, cp.getDataSource().getQueries().get(i).toString().replace(notion, value));
				}
			}
			for(int i=0; i<cp.getDataSource().getData().size(); i++) {
				cp.getDataSource().getData().set(i, cp.getDataSource().getData().get(i).toString().replace(notion, value));
			}
		}
		return cp;		
	}
	private PageComponent setToggleValue(PageComponent cp) {
		if (cp.getFormats().get(FORMAT_CLASS_INDEX).equals("Toggle")) {
			int x = Integer.valueOf(cp.getAssociations().get(0).toString());
			x = 1 - x;
			cp.getAssociations().set(0, x);
		}
		return cp;
	}	
	private PageContainer getData(PageContainer c) {
		//defautl data list is first one
		ArrayList<String[]> dataList = businessService.getData(c.getDataSource(), DATA_QUERY_INDEX_DEFAULT);
		c.getDataSource().setData(dataList);
		if (c.getDataSource().getData().size() < 1) {
			//add first list for f matching
			c.getDataSource().getData().add(ServiceConstants.EMPTY);
		} 
		if (c.getDataSource().getData().size() < 2) {
			//add second list for f matching
			c.getDataSource().getData().add(ServiceConstants.EMPTY);
		}
		return c;
	}
	private PageComponent getData(PageComponent cp) {
		//defautl data list is first one
		ArrayList<String[]> dataList = businessService.getData(cp.getDataSource(), DATA_QUERY_INDEX_DEFAULT);
		Object defaultValue = ServiceConstants.EMPTY;
		if (cp.getDataSource().getData().size() == 2) {
			defaultValue = cp.getDataSource().getData().get(FORM_FIELD);
		}
		cp.getDataSource().setData(dataList);
		if (cp.getDataSource().getData().size() == FORM_DATA) {
			//add first list for f matching
			cp.getDataSource().getData().add(ServiceConstants.EMPTY);
		} 
		if (cp.getDataSource().getData().size() == FORM_FIELD) {
			//add second list for f matching
			cp.getDataSource().getData().add(ServiceConstants.EMPTY);
		}
		cp.getDataSource().getData().set(FORM_FIELD, defaultValue);
		return cp;
	}
	private PageContainer formatComponents(PageContainer c, int mode) {
		for (int i=0; i<c.getComponents().size(); i++) {
			PageComponent cp = c.getComponents().get(i);
			if (cp.getName() !=null) {
				if (cp.getFormats().size() > 0) {
					String type = cp.getFormats().get(FORMAT_TYPE_INDEX).toString().toLowerCase();
					try {
						if (type.startsWith("date")) {
							String dateStr = cp.getDataSource().getData().get(FORM_FIELD).toString();
							String formatter = cp.getFormats().get(FORMAT_MASK_INDEX).toString();
							if (!dateStr.isEmpty() && !formatter.isEmpty()) {
								switch (mode) {
								case FORMAT_DISPLAY_MODE:
									cp.getDataSource().getData().set(FORM_FIELD, DateService.formatToFormatStr(dateStr, formatter));
									break;
								case FORMAT_DATABASE_MODE:
									cp.getDataSource().getData().set(FORM_FIELD, DateService.formatToDataSourceDate(dateStr, formatter));
									break;
								}
							}
						}
					} catch (Exception e) {
						LoggerService.debug("FormatComponents error in "+ cp.getName());
						e.printStackTrace();
					}		
				} else {
					LoggerService.debug("FormatComponents error in "+ cp.getName());				
				}
			}	
		}
		return c;
	}
	private PageComponent setComponentMessager(PageComponent cp, String message) {
		PageMessager messager = new PageMessager();
		messager.setMessages(new ArrayList());
		messager.getMessages().add(message);
        cp.setMessager(messager);
        return cp;
	}
	private String ObjectToJsonString(Object object) {
		ObjectMapper cp = new ObjectMapper();
		try {
			String jsonStr = cp.writeValueAsString(object);
			return jsonStr;
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ServiceConstants.EMPTY;
	}
	private Object populateModelObject(String[] classMethod, PageContainer c) {
		try {
	        return ClassService.callClassMethod(classMethod, new Object[] {c, modelPackagePath});
	    } catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	private Object processModelObject(String[] classMethod, Object[] objects) {
		try {
	        return ClassService.callClassMethod(classMethod, objects);
	    } catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	private PageContainer populateContainersMessage(PageContainer c, PageContainer f, int messageIndex) {
	   	c.getMessager().setShownMessages(f.getMessager().getShownMessages());
		c = initialShownMessage (c);
		c.getMessager().getShownMessages().add(f.getMessager().getMessages().get(messageIndex));
		return c;
	}
	private PageContainer populateComponentsMessage(PageContainer c, BindingResult result) {
		
		for (int i=0; i<c.getComponents().size(); i++) {
			PageComponent cp = c.getComponents().get(i);
			if (StringUtils.hasLength(cp.getName()) && cp.getMessager() == null) {
				FieldError error = result.getFieldError(componentKey(i));
				if (error != null) {
					cp = setComponentMessager(cp, error.getDefaultMessage());
				} else {
					error = result.getFieldError(cp.getName());
					if (error != null) {
						cp = setComponentMessager(cp, error.getDefaultMessage());
					}
				}
			}
		};
 		return c;
	}
	private String processContainer(PageContainer c, BindingResult result, Model model) {
		String p = GenericWebController.MAPPING_ERROR;
		String containerName = c.getName();
		String[] objectNames = containerName.split(ServiceConstants.UNDERSCORE);
		for (int i=0; i<objectNames.length; i++) {
			c.setName(objectNames[i]);
			
			
			if (i == 0) {
				p = processAContainer(c, result, model, i);
			} else {
				if (prepareSubmittion(c)) {
					processAContainer(c, result, model, i);
				} else {
					result.addError(new ObjectError(c.getName(), "Cannot set id"));
				}
			}
			if(result.hasErrors()) {
				if (p.contains(FORM)) {
					HttpServletRequest request = getCurrentHttpRequest();
					c.setName(containerName);
					request.getSession().setAttribute(FORM, c);
				}
				break;
			}
		}
		return p;
	}
	private String processAContainer(PageContainer c, BindingResult result, Model model, int i) {
		String url = (String) c.getWorkflow().getCommands().get(COMMAND_PATH_SUBMIT_RESULT);
		String classMethod[] = c.getWorkflow().getServiceClassPaths().get(0).toString().split(ServiceConstants.COLUMN);
		Object object = new Object();
		Long savedId = ServiceConstants.INVALID;
		
		if (i == 0) {
			c = initialShownMessage(c);
			c = formatComponents(c, FORMAT_DATABASE_MODE);
			result = businessService.validateComponents(c, result, FORM_FIELD);
			c = populateComponentsMessage(c, result);	
		}
		if (result.hasErrors()) {
			c = populateComponentsMessage(c, result);			
			url = (String) c.getWorkflow().getCommands().get(COMMAND_PAGE_REQUEST);
		} else {
			result = businessService.validateContainer(c, result, FORM_FIELD);			
			if (result.hasErrors()) {
				url = (String) c.getWorkflow().getCommands().get(COMMAND_PAGE_REQUEST);
			} else {
				String dataSourceConfig = c.getDataSource().getDataSourceConfigPath();
				
				object = populateModelObject (classMethod, c);
				
				if (object != null) {
					
					businessService.validate(object, result);	
					if (result.hasErrors()) {
						result.getFieldErrors().forEach(err -> dubgError(err));
						c = populateComponentsMessage(c, result);			
						url = (String) c.getWorkflow().getCommands().get(COMMAND_PAGE_REQUEST);
					} else {
						for (int j=1; j<c.getWorkflow().getServiceClassPaths().size(); j++) {
							classMethod = c.getWorkflow().getServiceClassPaths().get(j).toString().split(ServiceConstants.COLUMN);
							object = processModelObject(classMethod, new Object[] {object, c});
						}
						if (object != null) {
							savedId = getObjectId(c);
							if (savedId == null || savedId.equals(ServiceConstants.INVALID)) {
								savedId = businessService.persist(dataSourceConfig,object);
								if (savedId == ServiceConstants.INVALID) {
									result.reject(PERSISTENCE_PROCESS_ERROR);	
									LoggerService.debug("Error: " + PERSISTENCE_PROCESS_ERROR);
									url = (String) c.getWorkflow().getCommands().get(COMMAND_PAGE_REQUEST);
								}
							} else {
								businessService.setModelId(object, savedId);						
								businessService.merge(dataSourceConfig, object);
							}
							c.setComponents(PageHelper.setComponentValue(c.getComponents(), c.getName() + "id", String.valueOf(savedId)));						
						}
					}
				} else {
				   	c = populateContainersMessage(c, c, 0);					
				}
				url = setUrlPara(url, ID_PARA, savedId);
			}
		}
		return url;
	}

	private void dubgError(FieldError err) {
		LoggerService.debug("**Form Validation: "+ err.getField() + " " +err.isBindingFailure()  +" "+ err.getDefaultMessage());
	}
	private HttpServletRequest getCurrentHttpRequest(){
	    RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
	    if (requestAttributes instanceof ServletRequestAttributes) {
	        HttpServletRequest request = ((ServletRequestAttributes)requestAttributes).getRequest();
	        return request;
	    }
	    return null;
	}
	private String setUrlPara(String url, String name, long value) {
		String para = ServiceConstants.AMPERSEND + name + ServiceConstants.EQUAL + String.valueOf(value);
		if (url.contains(ServiceConstants.QUESTION_MARK)) {
			url = url + para;
		} else {
			url = url + ServiceConstants.QUESTION_MARK + para.substring(1);
		}
		return url;
	}
	private byte[] getImageWithMediaType(String resourceFile) throws IOException {
	    InputStream c = getClass()
	      .getResourceAsStream(resourceFile);
	    return IOUtils.toByteArray(c);
	}
	private Page loadPage(Page p, String fileName) {
        File f = new File(fileName);
        if(f.exists() && !f.isDirectory()) {
            FileInputStream fIn;
			try {
				fIn = new FileInputStream(fileName);
	            ObjectInputStream oIn = new ObjectInputStream (fIn);
	            Object object = oIn.readObject();
	
	            if(object instanceof Page) {
	                p = (Page) object;
	                LoggerService.info("Successfully loaded!");
	            } else {
	            	LoggerService.info("Invalid object in " + fileName);
		            fIn.close();
		            oIn.close();
				}
			} catch (IOException | ClassNotFoundException e) {
				e.printStackTrace();
			}
        }
        return p;
	}
	private long getObjectId(PageContainer c) {
		List containers = new ArrayList();
		containers.add(c);
		
		PageComponent cp = PageHelper.findComponentByName(containers, c.getName()+"id", null);
		if (cp != null && !cp.getDataSource().getData().get(FORM_FIELD).toString().isEmpty()) {			
			return Long.valueOf(cp.getDataSource().getData().get(FORM_FIELD).toString());
		} else {
			cp = PageHelper.findComponentByName(containers, "id", null);
			if (cp != null && !cp.getDataSource().getData().get(FORM_FIELD).toString().isEmpty()) {			
				return Long.valueOf(cp.getDataSource().getData().get(FORM_FIELD).toString());
			}	
		}
		return ServiceConstants.INVALID;
	}
	private boolean prepareSubmittion(PageContainer c) {
		return true;
	}
    private boolean savePage(Page p, String fileName) throws IOException {
        FileOutputStream fOut = new FileOutputStream(fileName);
        ObjectOutputStream oOut = new ObjectOutputStream(fOut);
        oOut.writeObject(p);
        fOut.close();
        oOut.close();
        return true;
    }
	private void slowReply(int i) {
		int upper = 1000 * i;
		int lower = 100 * i;
		try {
			long time = (int) (Math.random() * (upper - lower)) + lower;
			Thread.sleep(time);
		} catch (InterruptedException e) {
			throw new IllegalStateException(e);
		}
	}

}