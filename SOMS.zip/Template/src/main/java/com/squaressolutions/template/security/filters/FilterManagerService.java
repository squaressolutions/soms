package com.squaressolutions.template.security.filters;

import java.util.Arrays;
import java.util.List;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.squaressolutions.template.service.ServiceConstants;

@Configuration
public class FilterManagerService {
	public static String EXCLUDED_URL_PATTERNS = "/login,/logout,/url,/home,/error,/info,/help,/static,/js,/css,/ico,/img,/favicon.ico";
	public static final String MAPPING_WILDCARD = "/*";

    @Bean
	public FilterRegistrationBean<RequestPostFilter> registerRequestResponseLoggingFilter(){
	    FilterRegistrationBean<RequestPostFilter> registrationBean 
	      = new FilterRegistrationBean<>();
	    registrationBean.setFilter(new RequestPostFilter());
	    registrationBean.addUrlPatterns(MAPPING_WILDCARD);
	    return registrationBean;    
	}   
    @Bean
	public FilterRegistrationBean<MyDigestAuthenticationFilter> digestAuthenticationFilter(){
	    FilterRegistrationBean<MyDigestAuthenticationFilter> registrationBean
	      = new FilterRegistrationBean<>();
	    registrationBean.setFilter(new MyDigestAuthenticationFilter());
	    registrationBean.addUrlPatterns(MAPPING_WILDCARD);
	    return registrationBean;    
	}   
    public static boolean isExcludedUrl(String uri) {
    	List excludedList = Arrays.asList(EXCLUDED_URL_PATTERNS.split(ServiceConstants.COMMA));
    	boolean excluded = false;
        if (!excludedList.stream().anyMatch(s -> s.equals(uri))) {
        	for (int i=0; i<excludedList.size(); i++) {
          		if (uri.startsWith(String.valueOf(excludedList.get(i)))) {
          			excluded = true;
          			break;
          		}        	}
        } else {
  			excluded = true;        	
        }
      	return excluded;
     }
    
}
