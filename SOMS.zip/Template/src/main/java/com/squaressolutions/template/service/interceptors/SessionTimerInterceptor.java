package com.squaressolutions.template.service.interceptors;

import org.springframework.web.servlet.HandlerInterceptor;

import com.squaressolutions.template.controller.GenericWebController;
import com.squaressolutions.template.service.ServiceConstants;
import com.squaressolutions.template.service.system.SystemSettingHelper;
import com.squaressolutions.template.service.util.HttpRequestHelper;
import com.squaressolutions.template.service.util.LoggerService;
import com.squaressolutions.template.service.util.StringService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class SessionTimerInterceptor implements HandlerInterceptor {

     private static final long MAX_INACTIVE_SESSION_TIME = 2*60*60 * 1000; //2 hours
     
     SystemSettingHelper systemSettingHelper = new SystemSettingHelper() ;

    @Override
    public boolean preHandle(final HttpServletRequest request, final HttpServletResponse response, final Object handler) throws Exception {
       long startTime = System.currentTimeMillis();
       HttpSession session = request.getSession();
       long expireTime = MAX_INACTIVE_SESSION_TIME;
       if (request.getSession() != null) {
    	   String username = HttpRequestHelper.getUserName(request);
    	   String LoginSessionExpireTime = systemSettingHelper.getSettingValueByNameToStr("loginSessionExpireTime");
    	   if (LoginSessionExpireTime != null && username != null && !LoginSessionExpireTime.isEmpty() && !username.isEmpty()) {
    		   Long userSessionExpireTime = Long.valueOf(StringService.extractString(LoginSessionExpireTime, username, ServiceConstants.COMMA).split(ServiceConstants.COLUMN)[1]);
    		   if (userSessionExpireTime >= 0) {
    			   expireTime = userSessionExpireTime;
    		   }
    	   }
    	   //app property file
    	   //loginService system config
    	   //in seconds
    	   if (System.currentTimeMillis() - session.getLastAccessedTime() > expireTime * 1000) {
				LoggerService.debug("Logging out, due to inactive session for user " + HttpRequestHelper.getUserName(request));
				session.invalidate();				
				response.sendRedirect(GenericWebController.MAPPING_LOGOUT);
			}
       }
       return true;
    }
}