package com.squaressolutions.template.service.dataSource;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Service;

import com.squaressolutions.template.service.ServiceBase;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

@Service()
public class HikariDataSourceService implements ServiceBase, AutoCloseable {
	private HikariDataSource dataSource;
	
	public HikariDataSourceService() {		
		super();
	}
	public HikariDataSourceService(String path) {
	    getPathHikariDataSourceService(path);			    
	}
	public HikariDataSourceService getPathHikariDataSourceService(String path) {
 
	    HikariConfig config = (new DataSourcePropertyService()).getPathHikariConfig(path);
	    if (config != null) {
	    	this.dataSource = new HikariDataSource(config);
	    	return this;
	    } 
    	return null;
	}
	public HikariDataSource getDataSource() {
		return this.dataSource;
	}
	private void disconnectDataSource() {
		try {
			if (dataSource != null && !dataSource.isClosed() && dataSource.getConnection().isClosed()) {
				dataSource.getConnection().close();
				dataSource.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public void close() throws Exception {
		disconnectDataSource();
		
	}
	

}
