package com.squaressolutions.template.security.auditing;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import com.squaressolutions.template.controller.BaseController;
import com.squaressolutions.template.controller.GenericWebController;
import com.squaressolutions.template.dataSource.model.system.security.AppAudit;
import com.squaressolutions.template.dataSource.model.system.security.LoginAudit;
import com.squaressolutions.template.security.LoginAttemptService;
import com.squaressolutions.template.security.aspectj.CommonPointcuts;
import com.squaressolutions.template.security.authentication.user.AppUser;
import com.squaressolutions.template.service.data.DataService;
import com.squaressolutions.template.service.dataSource.DataSourceService;
import com.squaressolutions.template.service.system.SystemSettingHelper;
import com.squaressolutions.template.service.util.FileService;
import com.squaressolutions.template.service.util.HttpRequestHelper;
import com.squaressolutions.template.service.util.LoggerService;
import com.squaressolutions.template.service.util.PropertyService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Service
@EnableScheduling
public class AuditService {
	protected static Properties loginProperties = PropertyService.loadProperty("security/auditingLogin.properties");
	protected static Properties appProperties = PropertyService.loadProperty("security/auditingApp.properties");
	@Autowired
	protected SystemSettingHelper systemSettingHelper;
	@Autowired
	protected  DataSourceService dataSourceService;
	@Autowired
	protected FileService fileService;

	protected String getDatabasePath(Properties properties) {
		return properties.getProperty("database");		
	}
	@Scheduled(cron = "0 0 23 30 * ?")
	private void archiveLoginAuditing() {
		archiveAuditing(loginProperties);
	}
	@Scheduled(cron = "0 0 23 30 * ?")
	private void archiveAppAuditing() {
		archiveAuditing(appProperties);
	}
	public void archiveAuditing(Properties properties) {
		String query = properties.getProperty("archiveQuery");		
		ArrayList dataList = dataSourceService.getDataList(getDatabasePath(loginProperties), query, DataService.FORMAT_NAME_MAP);
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat(properties.getProperty("fileFormat"));
		String path = formatter.format(date);
		path = properties.getProperty("archivePath")+ path + properties.getProperty("fileExtension");
		
		try {
			fileService.writeFile(path, dataList);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public Date getLastLogin() {
		//ToDo: to get date from audit record
		return new Date();
	}
	
}
