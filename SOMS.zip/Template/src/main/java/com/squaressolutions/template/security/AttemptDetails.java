package com.squaressolutions.template.security;

import java.time.Instant;

import org.springframework.stereotype.Component;

import com.squaressolutions.template.service.ServiceConstants;

import lombok.Data;

@Component
@Data
public class AttemptDetails {
	private String ip = ServiceConstants.EMPTY;
	private String attempter;
	private String remoteUserName;
	private String userAgent;
	private String host;
	private String sessionId;
	private String connectionId;
	private String getRequestURI;
	private String queryString;
	private String referer;
	private Instant attemptTime=Instant.now();
	private int attempted = 0;
	
	public String toString() {
		return ip + host + sessionId + connectionId + getRequestURI + queryString + attempter + ip + attemptTime;
	}
	
}
