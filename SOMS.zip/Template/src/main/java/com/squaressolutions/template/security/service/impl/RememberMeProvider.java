package com.squaressolutions.template.security.service.impl;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.RememberMeServices;
import org.springframework.security.web.authentication.rememberme.JdbcTokenRepositoryImpl;
import org.springframework.security.web.authentication.rememberme.PersistentTokenBasedRememberMeServices;
import org.springframework.security.web.authentication.rememberme.PersistentTokenRepository;
import org.springframework.security.web.authentication.rememberme.TokenBasedRememberMeServices;
import org.springframework.security.web.authentication.rememberme.TokenBasedRememberMeServices.RememberMeTokenAlgorithm;
import org.springframework.session.security.web.authentication.SpringSessionRememberMeServices;
import org.springframework.stereotype.Service;

import com.squaressolutions.template.security.authentication.user.MyUserDetailsService;
import com.squaressolutions.template.service.dataSource.DataSourceService;

@Service
public class RememberMeProvider {
	private final String KEY="TopBeSecret321";
	
	
	@Autowired
	private DataSourceService dataSourceService;
	MyUserDetailsService userDetailsService = new MyUserDetailsService();
	
    public RememberMeServices springSessionRememberMeServices(int validitySeconds) {
    	SpringSessionRememberMeServices rememberMeServices =
    			new SpringSessionRememberMeServices();
    	// optionally customize
    	rememberMeServices.setAlwaysRemember(false);
    	rememberMeServices.setValiditySeconds(validitySeconds);
    	return rememberMeServices;
    }
    public RememberMeServices tokenBasedRememberMeServices(UserDetailsService userDetailsService, int validitySeconds) {
    	RememberMeTokenAlgorithm encodingAlgorithm = RememberMeTokenAlgorithm.SHA256;
    	TokenBasedRememberMeServices rememberMeServices = new TokenBasedRememberMeServices(KEY, userDetailsService, encodingAlgorithm);
    	rememberMeServices.setMatchingAlgorithm(RememberMeTokenAlgorithm.MD5); 
    	rememberMeServices.setTokenValiditySeconds(validitySeconds);
    	return rememberMeServices;
    }
    public RememberMeServices persistentTokenBasedRememberMeServices(int validitySeconds) {
		PersistentTokenRepository tokenRepository = jdbcTokenRepository();
		MyPersistentTokenBasedRememberMeServices rememberMeServices = new MyPersistentTokenBasedRememberMeServices(KEY, userDetailsService, tokenRepository);
    	rememberMeServices.setTokenValiditySeconds(validitySeconds);
    	return rememberMeServices;
    }
    private PersistentTokenRepository jdbcTokenRepository() {
    	JdbcTokenRepositoryImpl jdbcTokenRepository = new JdbcTokenRepositoryImpl();
    	jdbcTokenRepository.setCreateTableOnStartup(true);
		DataSource dataSource = dataSource();
    	jdbcTokenRepository.setDataSource(dataSource);
    	return jdbcTokenRepository;
    }
    private DataSource dataSource() {
    	return dataSourceService.getDataSource(DataSourceService.H2_SYSTEM_DB_SCHEMA_PATH);
    }

}
