package com.squaressolutions.template.security.service.impl;

import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.squaressolutions.template.security.authentication.user.MyUserDetailsService;
import com.squaressolutions.template.security.authentications.DaoAuthenticationService;
import com.squaressolutions.template.service.util.LoggerService;

public class DaoAuthenticationServiceImpl implements DaoAuthenticationService {
	private MyUserDetailsService myDaoUserDetailsService;
	public DaoAuthenticationServiceImpl(String configPath) {
		super();
		myDaoUserDetailsService = new MyUserDetailsService(configPath);
	}
	
	public DaoAuthenticationProvider authenticationProvider(PasswordEncoder passwordEncoder) {
		//user details and authorities both exist, otherwise auth will fail.
		LoggerService.debug("##DaoAuthenticationProvider is called"+passwordEncoder);
		DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider(passwordEncoder);
		authProvider.setPasswordEncoder(passwordEncoder);
	    authProvider.setUserDetailsService(myDaoUserDetailsService);
	    return authProvider;
	    
	}
	public UserDetailsService getUserDetailsService() {
		return this.myDaoUserDetailsService;
	}
}
