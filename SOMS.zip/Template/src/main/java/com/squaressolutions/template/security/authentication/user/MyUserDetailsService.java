package com.squaressolutions.template.security.authentication.user;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.data.ldap.repository.LdapRepository;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.JdbcUserDetailsManager;

import com.squaressolutions.template.security.WebSecurityConfig;
import com.squaressolutions.template.security.aspectj.UserAccessAspect;
import com.squaressolutions.template.security.service.impl.LdapTemplateService;
import com.squaressolutions.template.service.dataSource.JdbcTemplateService;
import com.squaressolutions.template.service.util.LoggerService;
import com.squaressolutions.template.service.util.PropertyService;

public class MyUserDetailsService extends UserDetailsServiceImpl { 
	private String configPath = null;
	private	JdbcUserDetailsManager jdbcUserDetailsManager = new JdbcUserDetailsManager();
	private JdbcTemplateService dataSourceService = new JdbcTemplateService();
	
	public MyUserDetailsService(String configPath) {
		super();		
		if (!configPath.isEmpty()) {
			this.configPath = configPath;
		}	
	}

	public MyUserDetailsService() {
		// TODO Auto-generated constructor stub
	}

	public AppUser getUserDetails(String userName) {
        LoggerService.debug("##MyUserDetailsService called");
        UserDetails userDetails = null;
        AppUser appUser =  null;
        //this is not needed if loadUserByUsername doesn't crash.
        if (configPath == null) {
			Properties properties = PropertyService.loadProperty(WebSecurityConfig.DB_SECURITY_PROVIDER_PROPERTIES);
		    for(String k : properties.stringPropertyNames()) {
		    	String v = properties.getProperty(k);
		    	DataSource dataSource = dataSourceService.getDataSource(v);
		        jdbcUserDetailsManager.setDataSource(dataSource);
		        try {
					userDetails = jdbcUserDetailsManager.loadUserByUsername(userName);
				} catch (UsernameNotFoundException e) {
					LoggerService.debug(e.getMessage());
					//e.printStackTrace();
				}
		        if (userDetails != null) {
			        appUser = new AppUser(userDetails);
			        break;
		        }
			};
	        if (userDetails == null) {
		        appUser = SearchForLdapUser(userName);
		        
	        }
        } else {
            jdbcUserDetailsManager.setDataSource(dataSourceService.getDataSource(configPath));
			try {
				userDetails = jdbcUserDetailsManager.loadUserByUsername(userName);
				if (userDetails != null) {
				    appUser = new AppUser(userDetails);
				    appUser.setAuthenticationPath(configPath);
				}
			} catch (UsernameNotFoundException e) {
				// TODO Auto-generated catch block
		        appUser = SearchForLdapUser(userName);
		        if (appUser != null) {
		        	//ignore password comparing by DaoAuthenticationProvider
		        	appUser = null;
		        }
				//e.printStackTrace();
			}
        }
        return appUser;
	}
	private AppUser SearchForLdapUser(String userName) {
        AppUser appUser =  null;
    	LdapUser ldapUser;
    	Properties properties = PropertyService.loadProperty(WebSecurityConfig.LDAP_SECURITY_PROVIDER_PROPERTIES);
	    for(String k : properties.stringPropertyNames()) {
	    	String v = properties.getProperty(k);
    		LdapTemplateService ldapTemplateService = new LdapTemplateService(v);
    		ldapUser = ldapTemplateService.findBy("cn", userName);
	        if (ldapUser != null) {
		        appUser = new AppUser(ldapUser);
		        break;
	        }
	    };		
	    return appUser;
	}
	public void createAdmin(DataSource dataSource, PasswordEncoder passwordEncoder) {
        List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();

        jdbcUserDetailsManager.setDataSource(dataSource);
        authorities.add(new SimpleGrantedAuthority("ROLE_USER"));        
        UserDetails user = new User("admin", passwordEncoder.encode("pfdsfdsfsdfsffed12"), authorities);        
        jdbcUserDetailsManager.createUser(user);
	}
}