package com.squaressolutions.template.service.system;

import java.util.EnumSet;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.context.support.ConversionServiceFactoryBean;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.converter.Converter;
import org.springframework.format.FormatterRegistry;
import org.springframework.web.context.ServletContextAware;
import org.springframework.web.context.request.RequestContextListener;
import org.springframework.web.filter.RequestContextFilter;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

import com.squaressolutions.template.service.interceptors.SessionTimerInterceptor;
import com.squaressolutions.template.service.view.PageMessagerToStringConverter;
import com.squaressolutions.template.service.view.PageValidatorToStringConverter;
import com.squaressolutions.template.service.view.PageWorkflowToStringConverter;

import jakarta.servlet.ServletContext;
import jakarta.servlet.SessionTrackingMode;

@Profile("!setup")
@Configuration
@EnableWebMvc
@EnableCaching
@EnableAspectJAutoProxy(proxyTargetClass = true)
@ComponentScan({ "com.squaressolutions.template" })
public class WebConfig implements WebMvcConfigurer,  ApplicationContextAware, ServletContextAware  {
	private ServletContext servletContext;
	private ApplicationContext applicationContext;

	@Override
	public void addViewControllers(ViewControllerRegistry registry) {
		//registry.addViewController("/").setViewName("home");
		//registry.addViewController("/loginFail");
		//registry.addViewController("/loginOk");

		//registry.addViewController("/login").setViewName("login");
		//registry.addViewController("/index").setViewName("index");
	}
	@Bean
	@Primary
    public CacheManager cacheManager() {
        return new CaffeineCacheManager("primaryCache");
    }

	@Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler(
                "/webjars/**",
                "/img/**",
                "/css/**",
                "/js/**",
                "/resources/**")
                .addResourceLocations(
                        "classpath:/META-INF/resources/webjars/",
                        "classpath:/static/img/",
                        "classpath:/static/css/",
                        "classpath:/static/js/",
                        "/resources/");
    }
    
//    //@InitBinder
//	public void initBinder(WebDataBinder binder) {
//	    binder.registerCustomEditor(PageElementPartEditor.class, 
//	        new PageElementPartEditor());
//	}
    @Bean
    public ConversionService conversionService() {
        ConversionServiceFactoryBean conversionServiceFactoryBean = new ConversionServiceFactoryBean();
        Set<Converter<?, ?>> converters = new HashSet<>();
        //converters.add(new PageValidatorToStringConverter());
        conversionServiceFactoryBean.setConverters(converters);
        conversionServiceFactoryBean.afterPropertiesSet();
        return conversionServiceFactoryBean.getObject();
    }
//    @Bean
//    public static CustomEditorConfigurer customEditorConfigurer1() {
//       CustomEditorConfigurer configurer = new CustomEditorConfigurer();
//       configurer.setPropertyEditorRegistrars(new PropertyEditorRegistrar[] {
//   				(registry) -> registry.registerCustomEditor(PageElementPart.class, new PageElementPartEditor()) });
//   		return configurer;
//   	} 
//    
//        
    @Override
    public void addFormatters(FormatterRegistry registry) {
        registry.addConverter(new PageValidatorToStringConverter());
        registry.addConverter(new PageMessagerToStringConverter());
        registry.addConverter(new PageWorkflowToStringConverter());
    }

	/*
	 * @Bean public CookieLocaleResolver localeResolver() { CookieLocaleResolver
	 * cookieLocaleResolver = new CookieLocaleResolver();
	 * cookieLocaleResolver.setDefaultLocale(Locale.ENGLISH); return
	 * cookieLocaleResolver; }
	 */	
	@Bean
	public SessionLocaleResolver sessionlocaleResolver() {
		SessionLocaleResolver localeResolver = new SessionLocaleResolver();
		localeResolver.setDefaultLocale(Locale.ENGLISH);
		return localeResolver;
	}

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(new SessionTimerInterceptor()).excludePathPatterns("/img/**","/js/**","/css/**");
	}
    @Override
    public void setApplicationContext(ApplicationContext applicationContext) {
    	this.applicationContext = applicationContext;
    }
    @Override
	public void setServletContext(ServletContext servletContext) {
        this.servletContext = servletContext;
        //ToDo:this should be run somewhere
        servletContext.setSessionTrackingModes(EnumSet.of(SessionTrackingMode.COOKIE));
    }
    @Bean
    public RequestContextListener requestContextListener() {
        return new RequestContextListener();
    }
    @Bean
    public RequestContextFilter requestContextFilter() {
      RequestContextFilter requestContextFilter = new RequestContextFilter();
      requestContextFilter.setThreadContextInheritable(true);
      return requestContextFilter;
    }
  
//    @Bean
//    public DeviceResolverHandlerInterceptor deviceResolverHandlerInterceptor() { 
//        return new DeviceResolverHandlerInterceptor(); 
//    }
//
//    @Bean
//    public DeviceHandlerMethodArgumentResolver deviceHandlerMethodArgumentResolver() { 
//        return new DeviceHandlerMethodArgumentResolver(); 
//    }
//
//    @Override
//    public void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers) {
//        argumentResolvers.add(deviceHandlerMethodArgumentResolver()); 
//    }
//
//    private ITemplateResolver htmlTemplateResolver() {
//        SpringResourceTemplateResolver resolver = new SpringResourceTemplateResolver();
//        resolver.setApplicationContext(applicationContext);
//        resolver.setPrefix("/WEB-INF/views/");
//        resolver.setCacheable(false);
//        resolver.setTemplateMode(TemplateMode.HTML);
//        return resolver;
//    }
//
//    private ITemplateResolver javascriptTemplateResolver() {
//        SpringResourceTemplateResolver resolver = new SpringResourceTemplateResolver();
//        resolver.setApplicationContext(applicationContext);
//        resolver.setPrefix("/WEB-INF/js/");
//        resolver.setCacheable(false);
//        resolver.setTemplateMode(TemplateMode.JAVASCRIPT);
//        return resolver;
//    }
//
//    private ITemplateResolver plainTemplateResolver() {
//        SpringResourceTemplateResolver resolver = new SpringResourceTemplateResolver();
//        resolver.setApplicationContext(applicationContext);
//        resolver.setPrefix("/WEB-INF/txt/");
//        resolver.setCacheable(false);
//        resolver.setTemplateMode(TemplateMode.TEXT);
//        return resolver;
//    }
//
//    @Bean
//    @Description("Spring Message Resolver")
//    public ResourceBundleMessageSource messageSource() {
//        ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
//        messageSource.setBasename("messages");
//        return messageSource;
//    }
//
}