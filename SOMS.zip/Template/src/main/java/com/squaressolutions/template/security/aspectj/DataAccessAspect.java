package com.squaressolutions.template.security.aspectj;

import java.sql.Date;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import com.squaressolutions.template.security.authentication.user.AppUser;
import com.squaressolutions.template.service.util.LoggerService;


@Aspect
@Component
public class DataAccessAspect extends AccessAspect {

	@After(value = "execution(* com.squaressolutions.template.service.dataSource.*.*(..))")
	public void beforeReturning(JoinPoint joinPoint) {
		process(joinPoint);
	}
	@Override
	protected AppUser setOrCheck(AppUser user) {
		if (user.getLastAccessDate() != null && Math.random()*40 == 2) {
			LoggerService.showCaller();
			BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();	
			if (!encoder.matches(user.getLastAccessDate().toString(), user.getKey())) {
				out();
			}
		}
		return user;
	}
}
