package com.squaressolutions.template.security.aspectj;

import org.aspectj.lang.annotation.Pointcut;

public class CommonPointcuts {

	/**
	 * A join point is in the web layer if the method is defined
	 * in a type in the com.squaressolutions.template.web package or any sub-package
	 * under that.
	 */
	@Pointcut("within(com.squaressolutions.template.controller..*)")
	public void inControllerLayer() {}

	@Pointcut("within(com.squaressolutions.template.security..*)")
	public void inSecurityLayer() {}

	@Pointcut("within(com.squaressolutions.template.service..*)")
	public void inServiceLayer() {}

	@Pointcut("within(com.squaressolutions.template.service.dataSource..*)")
	public void inDataAccessLayer() {}

	/**
	 * A business service is the execution of any method defined on a service
	 * interface. This definition assumes that interfaces are placed in the
	 * "service" package, and that implementation types are in sub-packages.
	 *
	 * If you group service interfaces by functional area (for example,
	 * in packages com.squaressolutions.template.abc.service and com.squaressolutions.template.def.service) then
	 * the pointcut expression "execution(* com.squaressolutions.template..service.*.*(..))"
	 * could be used instead.
	 *
	 * Alternatively, you can write the expression using the 'bean'
	 * PCD, like so "bean(*Service)". (This assumes that you have
	 * named your Spring service beans in a consistent fashion.)
	 */
	@Pointcut("execution(* com.squaressolutions.template..service.*.*(..))")
	public void businessService() {}

	//any method defined on a * dataSource interface
	@Pointcut("execution(* com.squaressolutions.template.service.dataSource.*.*(..))")
	public void dataAccessOperation() {}

}