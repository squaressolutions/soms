package com.squaressolutions.template.service.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.stereotype.Service;

import com.squaressolutions.template.service.ServiceBase;

@Service
public class PropertyService implements ServiceBase {
	public PropertyPlaceholderConfigurer properties(String propertyPath) {
	    PropertyPlaceholderConfigurer ppc
	      = new PropertyPlaceholderConfigurer();
	    Resource[] resources = new ClassPathResource[]
	      { new ClassPathResource(propertyPath) };
	    ppc.setLocations( resources );
	    ppc.setIgnoreUnresolvablePlaceholders( true );
	    return ppc;
	}
	public static Properties loadProperty(String propertyPath) {
		Resource resource = new ClassPathResource(propertyPath);
		try {
			Properties props = PropertiesLoaderUtils.loadProperties(resource);
			return props;
		} catch (IOException e) {
			e.printStackTrace();
		}
//        try (InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(propertyPath);) {
//            Properties prop = new Properties();
//            // load a properties file
//            prop.load(inputStream);
//            return prop;
//
//        } catch (IOException ex) {
//            ex.printStackTrace();
//        } 
        return null;
	}
}
