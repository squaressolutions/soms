package com.squaressolutions.template.security.authorizations;

import jakarta.servlet.http.HttpSession;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.stereotype.Service;

import com.squaressolutions.template.security.authentication.user.AppUser;

@Service
public class AuthorisationService {
	@Autowired
	CanAccessConfig canAccessConfig;

	public boolean Authorised(AppUser user, String url) {
		//ToDo:
		return true;
	}
	private void reloadUserAuthority(HttpSession session) {
		 
     List<GrantedAuthority> authorityList = AuthorityUtils.createAuthorityList(new String[]{" Queryed from the database"});
	 
		SecurityContext securityContext = (SecurityContext) session.getAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY);
		Authentication authentication = securityContext.getAuthentication();
	//	SecurityUser principal = (SecurityUser) authentication.getPrincipal();
	//	principal.setAuthorities(authorityList);
	 
		 // Renew a new token because the permissions in Authentication are immutable.
	//	UsernamePasswordAuthenticationToken result = new UsernamePasswordAuthenticationToken(
	//			principal, authentication.getCredentials(),
	//			authorityList);
	//	result.setDetails(authentication.getDetails());
	//	securityContext.setAuthentication(result);
	}
}
