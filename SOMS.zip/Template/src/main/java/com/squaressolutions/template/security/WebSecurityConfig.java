package com.squaressolutions.template.security;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.annotation.Order;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.DelegatingPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.crypto.scrypt.SCryptPasswordEncoder;
import org.springframework.security.ldap.authentication.LdapAuthenticationProvider;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.LoginUrlAuthenticationEntryPoint;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.logout.HeaderWriterLogoutHandler;
import org.springframework.security.web.csrf.XorCsrfTokenRequestAttributeHandler;
import org.springframework.security.web.header.writers.ClearSiteDataHeaderWriter;
import org.springframework.security.web.header.writers.ClearSiteDataHeaderWriter.Directive;
import org.springframework.security.web.session.HttpSessionEventPublisher;
import org.springframework.session.Session;

import com.squaressolutions.template.controller.GenericWebController;
import com.squaressolutions.template.security.filters.RequestURLFilter;
import com.squaressolutions.template.security.service.impl.DaoAuthenticationServiceImpl;
import com.squaressolutions.template.security.service.impl.LdapAuthenticationServiceImpl;
import com.squaressolutions.template.security.service.impl.RememberMeProvider;
import com.squaressolutions.template.service.system.SystemSettingHelper;
import com.squaressolutions.template.service.util.PropertyService;

@Profile("!setup")
@Configuration
@EnableWebSecurity
public class WebSecurityConfig <S extends Session> {
	public static String DB_SECURITY_PROVIDER_PROPERTIES="security/dbAuthenticationProviders.properties";
	public static String LDAP_SECURITY_PROVIDER_PROPERTIES="security/ldapAuthenticationProviders.properties";
	@Autowired
	LoginService loginService;
	@Autowired
	LogoutService logoutService;
	@Autowired
	LoginAttemptService loginAttemptService;
	@Autowired
	RememberMeProvider rememberMeProvider;
	@Autowired
	SystemSettingHelper systemSettingHelper;
	
	
	@Order(1)
	@Bean
    public SecurityFilterChain filterChain(HttpSecurity httpSecurity) throws Exception {
		httpSecurity
	    	.authorizeHttpRequests((requests) -> requests
					.requestMatchers("/js/**","/css/**","/img/**","/login","/error","/myerror").permitAll()
				.anyRequest().authenticated()
			)
	    	.csrf((csrf) -> csrf
					.csrfTokenRequestHandler(new XorCsrfTokenRequestAttributeHandler()))
	    	// Example portMapper() configuration
//	    	.portMapper((portMapper) ->
//            portMapper
//                    .http(9090).mapsTo(9443)
//                    .http(80).mapsTo(443)
			.formLogin((form) -> form
				.loginPage(GenericWebController.MAPPING_LOGIN)
				//.defaultSuccessUrl(GenericWebController.MAPPING_HOME) // the second parameter is for enforcing this url always
	            .loginProcessingUrl(GenericWebController.MAPPING_SUBMIT)
	            .successHandler(loginService)             
				.failureHandler(loginAttemptService)
				//.successForwardUrl(GenericWebController.MAPPING_REDIRECT)				
				.permitAll()
			)
			.logout((logout) -> logout
			.logoutUrl("/logout")
			.invalidateHttpSession(true)
			.deleteCookies("JSESSIONID")
			.addLogoutHandler(new HeaderWriterLogoutHandler(new ClearSiteDataHeaderWriter(Directive.COOKIES)))
			
			.logoutSuccessHandler(logoutService)
			.permitAll());	
		
//		httpSecurity.exceptionHandling(exception -> exception
//				.accessDeniedHandler(new AccessDeniedHandlerImpl())
//                 .authenticationEntryPoint(loginUrlauthenticationEntryPoint())
//              //   .accessDeniedHandler(loginUrlauthenticationEntryPointWithWarning())
//        );
		
		
		httpSecurity
			.sessionManagement((sessionManagement) -> sessionManagement
			.invalidSessionUrl(GenericWebController.MAPPING_LOGIN)
			
			.maximumSessions(systemSettingHelper.getSettingValueByNameToInt("maximumSessions"))
			.maxSessionsPreventsLogin(true));

		httpSecurity.authenticationManager(authManager(httpSecurity));
		
		httpSecurity
		.rememberMe((rememberMe) -> rememberMe
		.rememberMeServices(rememberMeProvider.persistentTokenBasedRememberMeServices(3600*Integer.valueOf(systemSettingHelper.getSettingValueByNameToInt("rememberMeInHour"))))
		);
		
		httpSecurity.addFilterBefore(new RequestURLFilter(), UsernamePasswordAuthenticationFilter.class);

		return httpSecurity.build();
    }
    @Bean
    public AuthenticationEntryPoint loginUrlauthenticationEntryPoint(){
        return new LoginUrlAuthenticationEntryPoint(GenericWebController.MAPPING_LOGIN);
    }
    @Bean
    public AuthenticationEntryPoint loginUrlauthenticationEntryPointWithWarning(){
        return new LoginUrlAuthenticationEntryPoint(GenericWebController.MAPPING_LOGIN);
    }  
    @Bean
    public HttpSessionEventPublisher httpSessionEventPublisher() {
        return new HttpSessionEventPublisher();
    }
    public AuthenticationManager authManager(HttpSecurity http) throws Exception {
        AuthenticationManagerBuilder authenticationManagerBuilder = http.getSharedObject(AuthenticationManagerBuilder.class);
        authenticationManagerBuilder =loadAuthProviders(authenticationManagerBuilder);     
        return authenticationManagerBuilder.build();
    }
    private AuthenticationManagerBuilder loadAuthProviders(AuthenticationManagerBuilder authenticationManagerBuilder) {
		Properties properties = PropertyService.loadProperty(DB_SECURITY_PROVIDER_PROPERTIES);
	    for(String k : properties.stringPropertyNames()) {
	    	String v = properties.getProperty(k);
    		authenticationManagerBuilder.authenticationProvider(daoAuthenticationService(v));
		};
		properties = PropertyService.loadProperty(LDAP_SECURITY_PROVIDER_PROPERTIES);
	    for(String k : properties.stringPropertyNames()) {
	    	String v = properties.getProperty(k);
			authenticationManagerBuilder.authenticationProvider(ldapAuthenticationService(v));
	    };		
		return authenticationManagerBuilder;
    }
    private DaoAuthenticationProvider daoAuthenticationService(String configPath) {	
    	return new DaoAuthenticationServiceImpl(configPath).authenticationProvider((new MyPasswordEncoderService()).passwordEncoder());
    }
    private LdapAuthenticationProvider ldapAuthenticationService(String configPath) {	
    	return new LdapAuthenticationServiceImpl().authenticationProvider(configPath);
    }
//    @Bean
//    AuthenticationManager authenticationManager(BaseLdapPathContextSource contextSource) {
//    	LdapBindAuthenticationManagerFactory factory = new LdapBindAuthenticationManagerFactory(contextSource);
//    	factory.setUserSearchFilter("(uid={0})");
//    	factory.setUserSearchBase("ou=people");
//    	factory.setLdapAuthoritiesPopulator(authorities(contextSource));
//    	return factory.createAuthenticationManager();
//    }
}

