package com.squaressolutions.template.service.system;

import java.lang.reflect.InvocationTargetException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.squaressolutions.template.service.dataSource.DataSourceEntityService;
import com.squaressolutions.template.service.dataSource.JakartaPersistenceService;

@Configuration
public class DataSourceConfig {
	@Value("${app.datasource.entity.service}")
	private String dataSourceEntityService;

	
	@Bean
	DataSourceEntityService setDataSourceEntityService() {
		try {
			return (DataSourceEntityService) Class.forName(dataSourceEntityService).getDeclaredConstructor().newInstance();
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		//return new JakartaPersistenceService();
	}
}
