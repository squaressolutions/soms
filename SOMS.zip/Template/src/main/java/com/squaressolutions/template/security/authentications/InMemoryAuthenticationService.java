package com.squaressolutions.template.security.authentications;

import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

public interface InMemoryAuthenticationService {
	public DaoAuthenticationProvider authenticationProvider(PasswordEncoder passwordEncoder);
}
