package com.squaressolutions.template.service.setup;

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.jdbc.datasource.init.ScriptException;
import org.springframework.stereotype.Service;

import com.squaressolutions.template.service.ServiceBase;
import com.squaressolutions.template.service.ServiceConstants;
import com.squaressolutions.template.service.dataSource.HikariDataSourceService;
import com.squaressolutions.template.service.dataSource.JdbcTemplateService;
import com.squaressolutions.template.service.util.LoggerService;
import com.squaressolutions.template.service.util.ResourceFileService;



@Profile("setup")
public class DatabaseSchemaFileService  extends ResourceFileService implements ServiceBase{

	String myPath;
	DataSource dataSource;
	@Override
	public boolean process(String... args) {
		String path = args[0];
		String processFile = args[1];
		myPath = args[0];
		boolean processOk = false;
		//dataSource = (new HikariDataSourceService(path)).getDataSource();

		dataSource = (new JdbcTemplateService()).getDataSource(path);
		
		//get process order file
		String filePath = ResourceFileService.getFileInPath(path, processFile);
		LoggerService.debug(filePath);
		processOk = super.process(filePath);
    	return processOk;
	}
	@Override
	protected boolean processLines(BufferedReader br) throws IOException {
		String line;
		while ((line = br.readLine()) != null) {
			setDatsourceSchema(myPath + ServiceConstants.BACK_SLASH + line, dataSource); 
		}
		return true;
	}
	
    private void setDatsourceSchema(String schemaFile, DataSource dataSource) {
    	LoggerService.debug("Process DB SchemaFile " + schemaFile);
        Resource resource = new ClassPathResource(schemaFile);
        if (resource.exists()) {
	        ResourceDatabasePopulator databasePopulator = new ResourceDatabasePopulator(resource);
			databasePopulator.execute(dataSource);
        }
    }
}
