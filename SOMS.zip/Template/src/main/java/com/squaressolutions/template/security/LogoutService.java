package com.squaressolutions.template.security;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.security.web.authentication.logout.SimpleUrlLogoutSuccessHandler;
import org.springframework.stereotype.Service;

import com.squaressolutions.template.security.auditing.AuditHttpService;
import com.squaressolutions.template.service.ServiceBase;
import com.squaressolutions.template.service.util.LoggerService;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Service
public class LogoutService extends SimpleUrlLogoutSuccessHandler implements ServiceBase, LogoutSuccessHandler {
	@Autowired
	AuditHttpService auditHttpService;

    @Override
    public void onLogoutSuccess(
      HttpServletRequest request, 
      HttpServletResponse response, 
      Authentication authentication) 
      throws IOException, ServletException {     	
        auditHttpService.set(request, authentication);
	    LoggerService.debug("LogoutService is called");

	    super.onLogoutSuccess(request, response, authentication);
	    logout(request, response, authentication);
    }
    public static void logout(HttpServletRequest request, HttpServletResponse response, Authentication authentication) {
        SecurityContextLogoutHandler logoutHandler = new SecurityContextLogoutHandler();
        logoutHandler.logout(request, response, authentication);
        
	}
}