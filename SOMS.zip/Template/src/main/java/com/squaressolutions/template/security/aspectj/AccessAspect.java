package com.squaressolutions.template.security.aspectj;

import org.aspectj.lang.JoinPoint;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;

import com.squaressolutions.template.security.LoginService;
import com.squaressolutions.template.security.authentication.user.AppUser;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class AccessAspect {
	@Autowired
	protected HttpServletRequest request;
	@Autowired
	protected HttpServletResponse response;

	public void process(JoinPoint joinPoint) {
		Authentication authentication = LoginService.getAuthentication();
		if (authentication != null && !(authentication instanceof AnonymousAuthenticationToken) ) {
			if (authentication.getPrincipal() instanceof AppUser ) {
				AppUser user = (AppUser)authentication.getPrincipal();
				setOrCheck(user);
			} else {
				out();
			}
		}
	}
	protected void out() {
		//ToDo: more testing
		request.getSession().setMaxInactiveInterval(0);
//		try {
//			response.sendRedirect(GenericWebController.MAPPING_LOGOUT);
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
	}
	protected AppUser setOrCheck(AppUser user) {
		return user;};
}
