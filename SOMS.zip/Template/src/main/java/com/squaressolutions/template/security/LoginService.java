package com.squaressolutions.template.security;

import java.io.IOException;
import java.util.Date;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.security.web.savedrequest.HttpSessionRequestCache;
import org.springframework.security.web.savedrequest.RequestCache;
import org.springframework.security.web.savedrequest.SavedRequest;
import org.springframework.stereotype.Service;

import com.squaressolutions.template.controller.BaseController;
import com.squaressolutions.template.controller.GenericWebController;
import com.squaressolutions.template.dataSource.model.system.security.Users;
import com.squaressolutions.template.security.auditing.AuditHttpService;
import com.squaressolutions.template.security.authentication.user.AppUser;
import com.squaressolutions.template.security.authentication.user.UserService;
import com.squaressolutions.template.service.ServiceConstants;
import com.squaressolutions.template.service.business.OrganisationService;
import com.squaressolutions.template.service.business.model.PositionProfile;
import com.squaressolutions.template.service.system.SystemSettingHelper;
import com.squaressolutions.template.service.util.DateService;
import com.squaressolutions.template.service.util.HttpRequestHelper;
import com.squaressolutions.template.service.util.LoggerService;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@Service
public class LoginService extends SavedRequestAwareAuthenticationSuccessHandler {
	@Autowired
	PositionProfile positionProfile;
	@Autowired
	HttpRequestHelper httpRequestHelper;
	@Autowired
	LoginAttemptService loginAttemptService;	
	@Autowired
	AuditHttpService auditHttpService;
	@Autowired
	SystemSettingHelper systemSettingHelper;
	
	//@Autowired
	private RequestCache requestCache = new HttpSessionRequestCache();

	public void onAuthenticationSuccess(final HttpServletRequest request, final HttpServletResponse response, final Authentication authentication) throws IOException, ServletException {
        auditHttpService.set(request, authentication);
        LoggerService.debug("LoginService:onAuthenticationSuccess is called");
        String redirectUrl = GenericWebController.MAPPING_LOGIN;
		String sessionStatus = (String) request.getSession(false).getAttribute(LoginAttemptService.REQ_STATUS);		
		if (forceToLogin() || (sessionStatus != null && sessionStatus.equals(BaseController.LOGIN_RETURN_BLOCKED)) || request.isRequestedSessionIdFromURL()) {
			request.getSession(false).setAttribute(LoginAttemptService.REQ_STATUS, sessionStatus);	
			response.sendRedirect(redirectUrl);
			LogoutService.logout(request, response, authentication);
		} else {
			PositionProfile positionProfile = (new OrganisationService()).loadPositionProfile("");	
	    	redirectUrl = positionProfile.getHomePagePath();
	        SavedRequest savedRequest = this.requestCache.getRequest(request, response);
	        //if queryString is empty in savedRequest
			if (savedRequest != null) {
				redirectUrl = savedRequest.getRedirectUrl();
				if (redirectUrl.contains("/?") || redirectUrl.contains("logout?")) {				
					redirectUrl = GenericWebController.MAPPING_HOME;
				} else {
					//ToDo: if it is required
			    	LoggerService.debug(redirectUrl);				
				}
			} 
			request.getSession().setAttribute(LoginAttemptService.REQ_STATUS, ServiceConstants.EMPTY);
			HttpSessionRequestCache httpSessionRequestCache = new HttpSessionRequestCache();
			httpSessionRequestCache.removeRequest(request, response);
			request.getSession().setMaxInactiveInterval(systemSettingHelper.getSettingValueByNameToInt("maxInactiveInterval"));
			response.sendRedirect(redirectUrl);
			UserService.updateUser();
	        super.onAuthenticationSuccess(request, response, authentication);
		}     
    }
	public static Authentication getAuthentication() {
		SecurityContext context = SecurityContextHolder.getContext();
		Authentication authentication = context.getAuthentication();
		//String userName = authentication.getName();
		//Object principal = authentication.getPrincipal();
		//Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
		return authentication;
	}
	public static boolean isAppUser() {
		AppUser user = getAppUser();
		if (user != null) {
			String key = user.getKey();
			return (key != null && !key.isEmpty());
		}
		return false;
	}	
	public static AppUser getAppUser() {
		Authentication authentication = getAuthentication();
		if (authentication != null && !(authentication instanceof AnonymousAuthenticationToken) ) {
			AppUser user = (AppUser) authentication.getPrincipal();
			if (user instanceof AppUser ) {
				return user; 
			}
		}
		return null;
	}	
	public void setPrincipal(AppUser appUser) {
		Authentication authentication = getAuthentication();
	
	    //HttpSession session = req.getSession(true);
	    //session.setAttribute(SPRING_SECURITY_CONTEXT_KEY, sc);
	}
    public boolean compare(String one, String two) {
    	//ToDo: need to be tested
	    BCryptPasswordEncoder b = new BCryptPasswordEncoder();
	    return (b.matches(one, two));
	}
    public Object encriptPW(Object[] objects) {
    	if (objects[0].getClass().getName().equals(Users.class.getName())) {
	    	Users user = (Users) objects[0];
	    	String value = user.getPassword();   	
			if (!value.startsWith("{bcrypt}")) {
				PasswordEncoder passwordEncoder = (new MyPasswordEncoderService()).passwordEncoder();
				user.setPassword(passwordEncoder.encode(value));
				return user;
			}
    	}
    	return objects[0];    	
    }
	
	private String redirectUrl(Authentication authentication) {
        Set<String> roles = AuthorityUtils.authorityListToSet(authentication.getAuthorities());
        //authentication.getPrincipal().
        //LoggerService.debug("**redirect ***"+ positionProfile.getHomePagePath());
		return positionProfile.getHomePagePath();
	}
	private boolean forceToLogin() {
		//ToDo: auditHttpService.getLastLogin() to get last audit day
		Date lastLoginDate = auditHttpService.getLastLogin();
		int numOfDays = DateService.compareToToday(lastLoginDate);
		int setDays = systemSettingHelper.getSettingValueByNameToInt("forceLoginDaysBeforeToday");	
		return (numOfDays >= setDays);
	}
}
