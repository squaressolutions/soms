package com.squaressolutions.template.controller;

public interface ControllerAuthentication {
	default boolean open() {
		return false;		
	}
}
