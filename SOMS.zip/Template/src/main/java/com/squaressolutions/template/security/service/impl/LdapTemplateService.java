package com.squaressolutions.template.security.service.impl;

import java.util.List;
import java.util.stream.Stream;

import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.query.LdapQueryBuilder;

import com.squaressolutions.template.security.authentication.user.LdapUser;
import com.squaressolutions.template.service.util.LoggerService;

public class LdapTemplateService extends LdapService{
    private LdapTemplate ldapTemplate;  
    
    public LdapTemplateService(String configPath) {
		super();
		LoggerService.debug("##LdapTemplateService is called");	
		loadProperties(configPath);
		ldapTemplate = new LdapTemplate(getContextSource());
	}
    public final LdapUser findBy(String fieldName, String value) {
    	LdapQueryBuilder ldapQueryBuilder = LdapQueryBuilder.query().countLimit(200).timeLimit(200);
    	ldapQueryBuilder.where(fieldName).is(value); 		
		LdapUser ldapUser = null;
		try {
			ldapUser = ldapTemplate.findOne(ldapQueryBuilder, LdapUser.class);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			LoggerService.debug(e.getMessage());
		}
	    return ldapUser;
	}
    //ToDo: tests are needed for everything below
	public Stream<LdapUser> streamFindBy(String fieldName, String value) {
		return ldapTemplate.findForStream(LdapQueryBuilder.query().where(fieldName).is(value), LdapUser.class);
	}    

    public void authenticate(final String username, final String password) {
        getContextSource().getContext("cn=" + username + ",ou=users", password);
    }
    public LdapUser create(LdapUser ldapUser) {
        ldapTemplate.create(ldapUser);
        return ldapUser;
     }

	public void update(LdapUser ldapUser) {
	   ldapTemplate.update(ldapUser);
	}
	public void delete(LdapUser ldapUser) {
	   ldapTemplate.delete(ldapUser);
	}
	
	public List<LdapUser> findAll() {
	   return ldapTemplate.findAll(LdapUser.class);
	}

//    @Autowired
//    private Environment env;
//
//    @Autowired
//    private ContextSource contextSource;
//
//    @Autowired
//    private LdapTemplate ldapTemplate;
//
//    public void authenticate(final String username, final String password) {
//        contextSource.getContext("cn=" + username + ",ou=users," + env.getRequiredProperty("ldap.partitionSuffix"), password);
//    }
//
//    public List<String> search(final String username) {
//        return ldapTemplate.search(
//          "ou=users",
//          "cn=" + username,
//          (AttributesMapper<String>) attrs -> (String) attrs
//          .get("cn")
//          .get());
//    }
//
//    public void create(final String username, final String password) {
//        Name dn = LdapNameBuilder
//          .newInstance()
//          .add("ou", "users")
//          .add("cn", username)
//          .build();
//        DirContextAdapter context = new DirContextAdapter(dn);
//
//        context.setAttributeValues("objectclass", new String[] { "top", "person", "organizationalPerson", "inetOrgPerson" });
//        context.setAttributeValue("cn", username);
//        context.setAttributeValue("sn", username);
//        context.setAttributeValue("userPassword", digestSHA(password));
//
//        ldapTemplate.bind(context);
//    }
//
//    public void modify(final String username, final String password) {
//        Name dn = LdapNameBuilder
//          .newInstance()
//          .add("ou", "users")
//          .add("cn", username)
//          .build();
//        DirContextOperations context = ldapTemplate.lookupContext(dn);
//
//        context.setAttributeValues("objectclass", new String[] { "top", "person", "organizationalPerson", "inetOrgPerson" });
//        context.setAttributeValue("cn", username);
//        context.setAttributeValue("sn", username);
//        context.setAttributeValue("userPassword", digestSHA(password));
//
//        ldapTemplate.modifyAttributes(context);
//    }
//
//    private String digestSHA(final String password) {
//        String base64;
//        try {
//            MessageDigest digest = MessageDigest.getInstance("SHA");
//            digest.update(password.getBytes());
//            base64 = Base64
//              .getEncoder()
//              .encodeToString(digest.digest());
//        } catch (NoSuchAlgorithmException e) {
//            throw new RuntimeException(e);
//        }
//        return "{SHA}" + base64;
//    }
}
