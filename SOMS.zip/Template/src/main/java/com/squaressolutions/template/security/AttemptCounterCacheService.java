package com.squaressolutions.template.security;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.caffeine.CaffeineCache;
import org.springframework.stereotype.Service;
import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.context.annotation.Bean;

import com.github.benmanes.caffeine.cache.Cache;
import com.squaressolutions.template.service.util.HttpRequestHelper;
import com.squaressolutions.template.service.util.LoggerService;

import jakarta.servlet.http.HttpServletRequest;

@Service
public class AttemptCounterCacheService {
	
	
	private static final String CACHE_MANAGER = "cacheManagerAttempt";
	private static final String CACHE_NAME = "login_attempt";
	private static final String CACHE_KEY = "#p2";
	
	@Autowired
	HttpRequestHelper httpRequestHelper;

	@Bean
    private CacheManager cacheManagerAttempt() {
        return new CaffeineCacheManager(CACHE_NAME);
    }
    @Cacheable(cacheManager=AttemptCounterCacheService.CACHE_MANAGER, cacheNames=CACHE_NAME, key=CACHE_KEY)
    public AttemptDetails getAttemptDetails(AttemptDetails attemptDetails, HttpServletRequest request, String key) {
    	LoggerService.debug("get AttemptDetails is only called at the frist attempt for key, the rest should be from the cache"); 
    	return setAttemptDetails(request);
	}
    @CachePut(cacheManager=AttemptCounterCacheService.CACHE_MANAGER, cacheNames=CACHE_NAME, key=CACHE_KEY)
    public AttemptDetails resetAttemptDetails(AttemptDetails attemptDetails, HttpServletRequest request, String key) {
    	LoggerService.debug("put AttemptDetails is only called and restart"); 
    	return setAttemptDetails(request);
    }
    @CacheEvict(cacheManager=AttemptCounterCacheService.CACHE_MANAGER, cacheNames=CACHE_NAME, key=CACHE_KEY)
    public void removeAttemptDetails(String key) {
    	LoggerService.debug("remove AttemptDetails is only called and restart"); 
    }
    @CacheEvict(cacheManager=AttemptCounterCacheService.CACHE_MANAGER, cacheNames=CACHE_NAME, allEntries = true)
    public void resetAllAttemptDetails() {
    	LoggerService.debug("reset AttemptDetails is only called and reset"); 
    }
    private AttemptDetails setAttemptDetails(HttpServletRequest request) {
    	AttemptDetails attemptDetails = new AttemptDetails();
       	attemptDetails.setAttempter(httpRequestHelper.getUserName(request));
       	attemptDetails.setUserAgent(httpRequestHelper.getUserAgent(request));
       	attemptDetails.setIp(httpRequestHelper.getClientIP(request));
    	attemptDetails.setHost(httpRequestHelper.getRemoteHost(request));
    	attemptDetails.setSessionId(httpRequestHelper.getRequestedSessionId(request));
    	attemptDetails.setGetRequestURI(httpRequestHelper.getRequestURI(request));
    	attemptDetails.setQueryString(httpRequestHelper.getQueryString(request));
    	attemptDetails.setReferer(httpRequestHelper.getReferer(request));

 		attemptDetails.setAttemptTime(Instant.now());
		attemptDetails.setAttempted(0);
		return attemptDetails; 	
    }
}