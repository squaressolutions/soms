package com.squaressolutions.template.service.util;

import java.sql.*;
import org.h2.tools.Csv;
public class H2CvsService {
    public static void get(String[] args) throws Exception {
//        ResultSet rs = Csv.getInstance().read("data/test.csv", null, null);
//        ResultSetMetaData meta = rs.getMetaData();
//        while (rs.next()) {
//            for (int i = 0; i < meta.getColumnCount(); i++) {
//               // System.out.println(
//              //      meta.getColumnLabel(i + 1) + ": " +
//               //     rs.getString(i + 1));
//            }
//            //System.out.println();
//        }
//        rs.close();
    }
}