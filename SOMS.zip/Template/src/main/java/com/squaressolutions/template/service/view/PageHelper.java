package com.squaressolutions.template.service.view;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import com.squaressolutions.common.view.model.Page;
import com.squaressolutions.common.view.model.PageCommand;
import com.squaressolutions.common.view.model.PageComponent;
import com.squaressolutions.common.view.model.PageContainer;
import com.squaressolutions.template.controller.BaseController;
import com.squaressolutions.template.service.ServiceBase;
import com.squaressolutions.template.service.ServiceConstants;
import com.squaressolutions.template.service.util.LoggerService;

import org.apache.catalina.Container;
import org.springframework.beans.BeanUtils;


public class PageHelper implements ServiceBase{
	
	public static PageContainer getContainer(Page page, String name) {
		PageContainer thisContainer = null;
		return findContainer(page.getContainers(), name, thisContainer);
	}
	public static PageContainer findContainer(List containers, String name, PageContainer thisContainer) {	
		for (int i=0; i<containers.size(); i++) {
			if (((PageContainer) containers.get(i)).getName().equals(name)) {
				thisContainer = ((PageContainer) containers.get(i));
				break;
			} else {
				if (thisContainer == null) {
					thisContainer = findContainer(((PageContainer) containers.get(i)).getSubContainers(), name, thisContainer);
				} else {
					break;
				}
			}						
		}
		return thisContainer;
	}
	public static List replaceContainer(List containers, String name, PageContainer thisContainer) {	
		for (int i=0; i<containers.size(); i++) {
			if (((PageContainer) containers.get(i)).getName().equals(thisContainer.getName())) {
				PageCommand command = (PageCommand) ((PageContainer) containers.get(i)).getWorkflow().getCommands().get(0);
				
				for (int j=0; j<thisContainer.getComponents().size();j++) {
					((PageContainer) containers.get(i)).getComponents().get(j).setDataSource(thisContainer.getComponents().get(j).getDataSource());	
					((PageContainer) containers.get(i)).getComponents().get(j).setMessager(thisContainer.getComponents().get(j).getMessager());	
				}
				break;
			} else {
				replaceContainer(((PageContainer) containers.get(i)).getSubContainers(), name, thisContainer);
			}						
		}
		return containers;
	}
	
	public static void merge(Object obj, Object update){
	    if(!obj.getClass().isAssignableFrom(update.getClass())){
	        return;
	    }

	    Method[] methods = obj.getClass().getMethods();

	    for(Method fromMethod: methods){
	        if(fromMethod.getDeclaringClass().equals(obj.getClass())
	                && fromMethod.getName().startsWith("get")){

	            String fromName = fromMethod.getName();
	            String toName = fromName.replace("get", "set");

	            try {
	                Method toMetod = obj.getClass().getMethod(toName, fromMethod.getReturnType());
	                Object value = fromMethod.invoke(update, (Object[])null);
	                if(value != null){
	                    toMetod.invoke(obj, value);
	                }
	            } catch (Exception e) {
	                e.printStackTrace();
	            } 
	        }
	    }
	}
	public static String getComponentValueByType(PageContainer container, String type, PageComponent theComponent) {	
		return getComponentValue(container, type, theComponent, 0);
	}
	public static String getComponentValueByName(PageContainer container, String name, PageComponent theComponent) {	
		return getComponentValue(container, name, theComponent, 1);
	}
	public static String getComponentValueByType(List containers, String type, PageComponent theComponent) {	
		return getComponentValue(containers, type, theComponent, 0);
	}
	public static String getComponentValueByName(List containers, String name, PageComponent theComponent) {	
		return getComponentValue(containers, name, theComponent, 1);
	}
	public static PageComponent findComponentByType(PageContainer container, String type, PageComponent theComponent) {	
		return findComponent(container, type, theComponent, 0);
	}
	public static PageComponent findComponentByName(PageContainer container, String name, PageComponent theComponent) {	
		return findComponent(container, name, theComponent, 1);
	}
	public static PageComponent findComponentByType(List containers, String type, PageComponent theComponent) {	
		return findComponent(containers, type, theComponent, 0);
	}
	public static PageComponent findComponentByName(List containers, String name, PageComponent theComponent) {	
		return findComponent(containers, name, theComponent, 1);
	}
	private static String getComponentValue(PageContainer container, String match, PageComponent theComponent, int lookFor) {	
		PageComponent component = findComponent(container, match, theComponent, lookFor);
//		if (component != null && !component.getDataSource().getData().get(BaseController.FORM_FIELD).toString().isEmpty()) {	
		if (component != null) {	
			return component.getDataSource().getData().get(BaseController.FORM_FIELD).toString();
		}
		return ServiceConstants.EMPTY;
	}
	public static List setComponentValue(List components, String match, String value) {	
		for (int i=0; i<components.size(); i++) {
			PageComponent component = (PageComponent) components.get(i);
			if (component.getName() !=null && component.getName().toLowerCase().equals(match.toLowerCase())) {
				component.getDataSource().getData().set(BaseController.FORM_FIELD, value);
			}
		}
		return components;
	}
	private static String getComponentValue(List containers, String match, PageComponent theComponent, int lookFor) {	
		PageComponent component = findComponent(containers, match, theComponent, lookFor);
		if (component != null && !component.getDataSource().getData().get(BaseController.FORM_FIELD).toString().isEmpty()) {			
			return component.getDataSource().getData().get(BaseController.FORM_FIELD).toString();
		}
		return ServiceConstants.EMPTY;
	}
	private static PageComponent findComponent(List containers, String match, PageComponent theComponent, int lookFor) {	
		for (int i=0; i<containers.size(); i++) {
			PageContainer container = (PageContainer) containers.get(i);
			theComponent = findComponent(container, match, theComponent, lookFor);
			if (theComponent == null && container.getSubContainers() != null) {
				theComponent = findComponent(container.getSubContainers(), match, theComponent, lookFor);
			} else {
				return theComponent;
			}
		}
		return theComponent;
	}
	private static PageComponent findComponent(PageContainer container, String match, PageComponent theComponent, int lookFor) {	
		for (int i=0; i<container.getComponents().size(); i++) {
			PageComponent component = (PageComponent) container.getComponents().get(i);
			switch (lookFor) {
				case 0:{
					if (component.getFormats().get(0).toString().toLowerCase().equals(match.toLowerCase())) {
						theComponent = component;
						return theComponent;
					}											
				}
				case 1:{
					if (component.getName() != null && component.getName().toLowerCase().equals(match.toLowerCase())) {
						theComponent = component;
						return theComponent;
					}											
				}
			}			
		}
		return theComponent;
	}
}
