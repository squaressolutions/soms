package com.squaressolutions.template.service.business;

public class BriefingBusinessService {

}
