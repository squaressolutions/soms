package com.squaressolutions.template.service.dataSource;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Service;

import com.squaressolutions.template.security.JasyptAdvancedService;
import com.squaressolutions.template.service.ServiceBase;
import com.squaressolutions.template.service.util.LoggerService;

public class JdbcTemplateService implements ServiceBase, DataSourceEntityService, AutoCloseable{
	@Autowired
	JdbcTemplate jdbcTemplate;
	DriverManagerDataSource dataSource;

	public Object get(String configPath, Class clazz, long id) {
		getDataSource(configPath);
        String sql = "SELECT * FROM " + clazz.getName() + " WHERE ID = ?";

        return jdbcTemplate.queryForObject(
			sql, 
			new Object[]{id}, 
			new int[]{0}, 
			new BeanPropertyRowMapper(clazz));
	}	
	
	public DriverManagerDataSource getDataSource(String configPath) {
        dataSource = new DriverManagerDataSource();
        
        Properties properties = DataSourcePropertyService.loadProperties(configPath);  
        dataSource.setConnectionProperties(properties);
        dataSource.setDriverClassName(properties.getProperty(DataSourcePropertyService.DRIVER_CLASS_NAME));
        dataSource.setUrl(properties.getProperty(DataSourcePropertyService.URL));
        dataSource.setUsername(properties.getProperty(DataSourcePropertyService.USER_NAME));
        dataSource.setPassword(JasyptAdvancedService.decrypt(properties.getProperty(DataSourcePropertyService.PASSWORD)));

        return dataSource;
    }

	@Override
	public void close() throws Exception {
		if (dataSource != null && dataSource.getConnection() != null) {
			dataSource.getConnection().close();
		}
		
	}

	@Override
	public void merge(String configPath, Object sql) {
		getDataSource(configPath);
		jdbcTemplate.execute(sql.toString());
		
	}

	@Override
	public long persist(String configPath, Object sql) {
		getDataSource(configPath);
		jdbcTemplate.execute(sql.toString());
		return 0;
	}
}

