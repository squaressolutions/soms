package com.squaressolutions.template.service.view.validation.genernal;

import java.text.Collator;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.validation.beanvalidation.SpringValidatorAdapter;

import com.squaressolutions.template.service.ServiceBase;
import com.squaressolutions.template.service.ServiceConstants;
import com.squaressolutions.template.service.util.LoggerService;
import com.squaressolutions.template.service.view.validation.BaseValidator;

public class StringValidator implements BaseValidator {
	
	public static boolean minimum(Object[] paras) throws Exception {
		paras[0] = GREATER_EQUAL;
		return (compareLength(paras));
	}
	public static boolean maximum(Object[] paras) throws Exception {
		paras[0] = LESS_EQUAL;
		return (compareLength(paras));
	}
	public static boolean compareLength(Object[] parasIn) throws Exception {
		String[] paras = (String[]) parasIn;
		if (paras.length == 3) {
			return NumberValidator.compare(new String[] {paras[0], new String().valueOf(paras[1].length()), paras[2]});
		} else {
			return false;
		}
	}
	public static boolean compare(String[] paras) throws Exception {
		String checker = paras[0];
		//Get the Collator for US English and set its strength to PRIMARY
		Collator usCollator = Collator.getInstance(Locale.US);
		usCollator.setStrength(Collator.PRIMARY);
		int i = usCollator.compare(paras[1], paras[2]); 		
		LoggerService.debug(checker);
		
		if (checker.startsWith(GREATER_EQUAL) || checker.startsWith(EQUAL_GREATER)) {
			return (i >= 0);
		} else if (checker.startsWith(LESS_EQUAL) || checker.startsWith(EQUAL_LESS)) {
			return (i <= 0);
		} else if (checker.startsWith(LESS)) {
			return (i < 0);
		} else if (checker.startsWith(GREATER)) {
			return (i > 0);
		} else if (checker.startsWith(ServiceConstants.EXCLAMATION)) {
			return !(i == 0);
		} else {
			return i == 0;
		}
	}
	public static boolean compareIgnoreCase(String[] paras) throws Exception {
		if (paras[0].startsWith(ServiceConstants.EXCLAMATION)) {
			return !paras[1].equalsIgnoreCase(paras[2]);			
		}
		return paras[1].equalsIgnoreCase(paras[2]);
	}
	@Override
	public boolean supports(Class<?> clazz) {
		return String.class.equals(clazz);
	}
	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
		
	}
}