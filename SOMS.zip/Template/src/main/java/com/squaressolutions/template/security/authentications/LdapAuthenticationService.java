package com.squaressolutions.template.security.authentications;

import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.ldap.authentication.LdapAuthenticationProvider;
import org.springframework.stereotype.Service;

public interface LdapAuthenticationService {
	public LdapAuthenticationProvider authenticationProvider(PasswordEncoder passwordEncoder);
}
