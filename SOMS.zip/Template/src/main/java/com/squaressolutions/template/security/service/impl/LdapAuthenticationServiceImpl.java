package com.squaressolutions.template.security.service.impl;

import java.util.Collection;

import org.springframework.ldap.core.ContextSource;
import org.springframework.ldap.core.DirContextOperations;
import org.springframework.ldap.core.support.BaseLdapPathContextSource;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.ldap.authentication.BindAuthenticator;
import org.springframework.security.ldap.authentication.LdapAuthenticationProvider;
import org.springframework.security.ldap.authentication.ad.ActiveDirectoryLdapAuthenticationProvider;
import org.springframework.security.ldap.userdetails.DefaultLdapAuthoritiesPopulator;
import org.springframework.security.ldap.userdetails.LdapAuthoritiesPopulator;
import org.springframework.security.ldap.userdetails.LdapUserDetailsMapper;
import org.springframework.security.ldap.userdetails.UserDetailsContextMapper;

import com.squaressolutions.template.security.authentication.user.AppUser;
import com.squaressolutions.template.service.ServiceConstants;
import com.squaressolutions.template.service.util.LoggerService;

	public class LdapAuthenticationServiceImpl extends LdapService{
		public LdapAuthenticationProvider authenticationProvider(String configPath) {
			LoggerService.debug("##authenticationProvider is called");	
			loadProperties(configPath);
			LdapAuthenticationProvider authenticationProvider = new LdapAuthenticationProvider(
					getAuthenticator(), ldapAuthoritiesPopulator(getContextSource()));
			authenticationProvider.setUserDetailsContextMapper(userDetailsContextMapper());
			return authenticationProvider;
		}
		
		private BindAuthenticator getAuthenticator() {
			LoggerService.debug("##getAuthenticator is called");
	        BindAuthenticator bindAuthenticator = new BindAuthenticator((BaseLdapPathContextSource) getContextSource());
	        String[] userDnPatterns = properties.getProperty("userDnPatterns").split(ServiceConstants.AMPERSEND);		      
	        bindAuthenticator.setUserDnPatterns(userDnPatterns);	        
	        bindAuthenticator.afterPropertiesSet();
	        return bindAuthenticator;
		}
	    private LdapAuthoritiesPopulator ldapAuthoritiesPopulator(ContextSource contextSource) {
			LoggerService.debug("##ldapAuthoritiesPopulator is called");
	        DefaultLdapAuthoritiesPopulator authorities = new DefaultLdapAuthoritiesPopulator
	           (contextSource, properties.getProperty("groupSearchBase"));
	        authorities.setGroupSearchFilter(properties.getProperty("groupSearchFilter"));
	        return authorities;
	    }		
		public ActiveDirectoryLdapAuthenticationProvider activeDirAuthenticationProvider(String configPath) {
			loadProperties(configPath);
			String domain = properties.getProperty("domain");
			String url = properties.getProperty("url");
			//return new ActiveDirectoryLdapAuthenticationProvider("example.com", "ldap://company.example.com/");
			return new ActiveDirectoryLdapAuthenticationProvider(domain, url);
		}
	    public UserDetailsContextMapper userDetailsContextMapper() {
	        return new LdapUserDetailsMapper() {
	            @Override
	            public UserDetails mapUserFromContext(DirContextOperations ctx, String username, Collection<? extends GrantedAuthority> authorities) {
	                UserDetails details = super.mapUserFromContext(ctx, username, authorities);
	                return new AppUser(details);
	            }
	        };
	    }
	}
//		    @Bean
//		    AuthenticationManager authenticationManager(BaseLdapPathContextSource contextSource, 
//		        LdapAuthoritiesPopulator authorities) {
//		        LdapBindAuthenticationManagerFactory factory = new LdapBindAuthenticationManagerFactory
//		           (contextSource);
//		        factory.setUserSearchBase("ou=people");
//		        factory.setUserSearchFilter("(uid={0})");
//		        return factory.createAuthenticationManager();
//		    }

//		    AuthenticatedLdapEntryContextCallback contextCallback = new AuthenticatedLdapEntryContextCallback() {
//		    	  public void executeWithContext(DirContext ctx, LdapEntryIdentification ldapEntryIdentification) {
//		    	    try {
//		    	      ctx.lookup(ldapEntryIdentification.getRelativeDn());
//		    	    }
//		    	    catch (NamingException e) {
//		    	      throw new RuntimeException("Failed to lookup " + ldapEntryIdentification.getRelativeDn(), e);
//		    	    }
//		    	  }
//
//				@Override
//				public void executeWithContext(DirContext ctx, LdapEntryIdentification ldapEntryIdentification) {
//					// TODO Auto-generated method stub
//					
//				}
//		    	};
