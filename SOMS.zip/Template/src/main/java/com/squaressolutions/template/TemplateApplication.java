/*
 * Copyright 2020-2024 the original author or authors.
 *
 * Licensed under the Non-Profit Open Software License version 3.0 (the "NPOSL-3.0");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://opensource.org/licenses/NPOSL-3.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.squaressolutions.template;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;

@SpringBootApplication
@EnableAutoConfiguration(exclude = {
		DataSourceAutoConfiguration.class,
})
public class TemplateApplication implements ApplicationRunner {
	private static final String SYSTEM_TEMPLATE_RESOLVER_PREFIX = "/WEB-INF/templates/";
	public static void main(String[] args) {
		SpringApplication.run(TemplateApplication.class, args);
 	}
    @Override
    public void run(ApplicationArguments args) throws Exception {

    	//        for (String name : args.getOptionNames()){
//        	System.out.println(name + "=" + args.getOptionValues(name));
//        }
//
//        boolean containsOption = args.containsOption("database.setup");
//        System.out.println("system: " + containsOption);
     // 	System.out.println(username + "=================" + cityname);    		
    }
    
	@Bean
	public ClassLoaderTemplateResolver systemTemplateResolver() {         
	    return getTemplateResolver(SYSTEM_TEMPLATE_RESOLVER_PREFIX);
	}
	private ClassLoaderTemplateResolver getTemplateResolver(String prefix) {
	    ClassLoaderTemplateResolver templateResolver = new ClassLoaderTemplateResolver();
	    templateResolver.setPrefix(prefix);
	    templateResolver.setSuffix(".html");
	    templateResolver.setTemplateMode(TemplateMode.HTML);
	    templateResolver.setCharacterEncoding("UTF-8");
	    templateResolver.setOrder(1);
	    templateResolver.setCheckExistence(true);	
	    return templateResolver;
	}
	
	
//	@Component
//	class MyTest{
//
//		@Value("${userdemo.name}")
//		private String username;
//
//		@Value("${usercity.name}")
//		private String cityname;
//
//		public void testPrint(){
//			System.out.println("##############################");
//			System.out.println("Username is -------->" +username);
//			System.out.println("Cityname is -------->" +cityname);
//			System.out.println("##############################");
//		}
//	}	
}

