package com.squaressolutions.template.security.filters;

import java.io.IOException;

import org.springframework.web.filter.OncePerRequestFilter;

import com.squaressolutions.template.controller.BaseController;
import com.squaressolutions.template.controller.GenericWebController;
import com.squaressolutions.template.security.LoginAttemptService;
import com.squaressolutions.template.security.LoginService;
import com.squaressolutions.template.security.authorizations.AuthorisationService;
import com.squaressolutions.template.service.ServiceConstants;
import com.squaressolutions.template.service.util.HttpRequestHelper;
import com.squaressolutions.template.service.util.LoggerService;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class RequestURLFilter extends OncePerRequestFilter {

	@Override
    public void doFilterInternal(
    		HttpServletRequest request, 
    		HttpServletResponse response, 
    		FilterChain chain) throws IOException, ServletException {
    	String reqUrl = HttpRequestHelper.getRequestFullUrl(request);
    	
    	if (!allowed(request) && (isInvalidLoginForm(request)		
    		|| hasNoConfigPath(request)	
    		|| isInvalidIP(request)
    		|| !authorised(request)
    		)) {
	    	LoggerService.debug("FILTERED OUT " + reqUrl);
	    	if (isNotEmptyUri(request)) {
				response.setStatus(HttpServletResponse.SC_FORBIDDEN);
				request.getSession().setAttribute(LoginAttemptService.REQ_STATUS, GenericWebController.LOGIN_RETURN_INVALID);
	    	}
	    	response.sendRedirect(GenericWebController.MAPPING_LOGIN);
			return;
    	} else if (isBlocked(request)) {
	    	LoggerService.debug("BLOCKED " + reqUrl);
			response.setStatus(HttpServletResponse.SC_FORBIDDEN);
			request.getSession().setAttribute(LoginAttemptService.REQ_STATUS, GenericWebController.LOGIN_RETURN_BLOCKED);
	    	response.sendRedirect(GenericWebController.MAPPING_LOGIN);
	    	return;
	    } else {
			response.setStatus(HttpServletResponse.SC_ACCEPTED);
	    }
        chain.doFilter(request, response);	    	
    }
	private boolean isNotEmptyUri(HttpServletRequest request) {
		return !(HttpRequestHelper.getRequestURI(request) == null ||
		HttpRequestHelper.getRequestURI(request).equals(ServiceConstants.EMPTY) ||
		HttpRequestHelper.getRequestURI(request).equals(ServiceConstants.BACK_SLASH));
	}
	private boolean allowed(HttpServletRequest request) {
		String url = HttpRequestHelper.getRequestFullUrl(request);
		boolean allow = url.contains(".js");
		allow = allow || url.contains(".css");
		
		return allow;
	}
	private boolean isLoginSubmitPost(HttpServletRequest request) {
		return request.getRequestURI().equals(GenericWebController.MAPPING_SUBMIT);
	}
	private boolean isEmptyUserName(HttpServletRequest request) {
		return (HttpRequestHelper.getUserName(request) == null ||
	    		HttpRequestHelper.getUserName(request).isBlank());
	}
	private boolean isEmptyUserPassword(HttpServletRequest request) {
		return (HttpRequestHelper.getPassword(request) == null ||
	    		HttpRequestHelper.getPassword(request).isBlank());		
	}
	private boolean isInvalidLoginForm(HttpServletRequest request) {
		return isLoginSubmitPost(request) && 
				(isEmptyUserName(request) || isEmptyUserPassword(request));
		
	}
	private boolean hasNoConfigPath(HttpServletRequest request) {
		if (!isLoginSubmitPost(request)) {
			return request.getQueryString() == null || !request.getQueryString().contains("configPath");
		}
		return false;
	}
	private boolean isInvalidIP(HttpServletRequest request) {
		String ip = HttpRequestHelper.getClientIP(request);
		//ToDo: check ip
		return ip.startsWith("10");
		
	}
	private boolean authorised(HttpServletRequest request) {
		return (new AuthorisationService()).Authorised(LoginService.getAppUser(), HttpRequestHelper.getFullURL(request));
	}
	private boolean isBlocked(HttpServletRequest request) {
		String sessionStatus = (String) request.getSession().getAttribute(LoginAttemptService.REQ_STATUS);		
		return (sessionStatus != null && sessionStatus.equals(BaseController.LOGIN_RETURN_BLOCKED));
	}
    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) throws ServletException 
    {
        return FilterManagerService.isExcludedUrl(request.getRequestURI());
    }
}