package com.squaressolutions.template.security.authentication.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.squaressolutions.template.security.LoginService;
import com.squaressolutions.template.service.business.BusinessService;

@Service
public class UserService {
	@Autowired
	BusinessService businessService;
	
	public static void updateUser() {
		AppUser appUser = LoginService.getAppUser();
		//ToDo:
		//businessService
	}
	
}
