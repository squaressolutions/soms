package com.squaressolutions.template.security.filters;

import java.io.IOException;

import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.filter.OncePerRequestFilter;

import com.squaressolutions.template.controller.GenericWebController;
import com.squaressolutions.template.security.LoginAttemptService;
import com.squaressolutions.template.security.LoginService;
import com.squaressolutions.template.security.authentication.user.AppUser;
import com.squaressolutions.template.service.ServiceConstants;
import com.squaressolutions.template.service.util.HttpRequestHelper;
import com.squaressolutions.template.service.util.LoggerService;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class RequestPostFilter extends OncePerRequestFilter {

	@Override
    public void doFilterInternal(
    		HttpServletRequest request, 
    		HttpServletResponse response, 
    		FilterChain chain) throws IOException, ServletException {
    	String reqUrl= HttpRequestHelper.getRequestFullUrl(request);
    	LoggerService.showCaller();
    	if (!LoginService.isAppUser()) {		
	    	LoggerService.debug("***** Bad User " + reqUrl);
			response.setStatus(HttpServletResponse.SC_FORBIDDEN);
	    	response.sendRedirect(GenericWebController.MAPPING_LOGIN);
			return;
	    } else {
			response.setStatus(HttpServletResponse.SC_ACCEPTED);
	    }
        chain.doFilter(request, response);	    	
    }
    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) throws ServletException 
    {
        return FilterManagerService.isExcludedUrl(request.getRequestURI());
        
    }
}