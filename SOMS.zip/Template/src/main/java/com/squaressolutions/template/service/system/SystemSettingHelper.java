package com.squaressolutions.template.service.system;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import javax.sql.DataSource;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.MappingSqlQuery;
import org.springframework.stereotype.Component;

import com.squaressolutions.template.dataSource.model.setting.Setting;
import com.squaressolutions.template.service.dataSource.DataSourceService;
import com.squaressolutions.template.service.dataSource.JdbcTemplateService;

@Component
public class SystemSettingHelper {
	private static final String GET_VALUE_BY_NAME_SQL = "select * from setting where name = ?";
	
	private JdbcTemplateService dataSourceService = new JdbcTemplateService();
	private SettingMappingSqlQuery settingMappingSqlQuery;

	public SystemSettingHelper() {
		DataSource dataSource = dataSourceService.getDataSource(DataSourceService.H2_SYSTEM_DB_SCHEMA_PATH);
		settingMappingSqlQuery = (new SettingMappingSqlQuery(dataSource, GET_VALUE_BY_NAME_SQL, "name"));
	}
	public Setting getSettingByName(String name) {
		return (Setting) (settingMappingSqlQuery.findObject(name));				
	}
	public String getSettingValueByNameToStr(String name) {
		return getSettingByName(name).getSettingValue();				
	}
	public Integer getSettingValueByNameToInt(String name) {
		return Integer.valueOf(getSettingByName(name).getSettingValue());				
	}
	public long getSettingValueByNameToLong(String name) {
		return Long.valueOf(getSettingByName(name).getSettingValue());				
	}
	public float getSettingValueByNameToFloat(String name) {
		return Float.valueOf(getSettingByName(name).getSettingValue());				
	}

	class SettingMappingSqlQuery  extends MappingSqlQuery<Setting>{
		public SettingMappingSqlQuery(DataSource dataSource, String sql, String keyName) {
			super(dataSource, sql);
			declareParameter(new SqlParameter(keyName, Types.CHAR));
			compile();
		}
		@Override
		protected Setting mapRow(ResultSet rs, int rowNumber) throws SQLException {
			Setting Setting = new Setting();
			Setting.setId(rs.getLong("id"));
			Setting.setName(rs.getString("name"));
			Setting.setDescription(rs.getString("description"));
			Setting.setSettingValue(rs.getString("setting_value"));
			Setting.setStartDate(rs.getDate("start_date"));
			Setting.setEndDate(rs.getDate("end_date"));
			Setting.setStatusCode(rs.getString("status_code"));
			return Setting;
		}
	}	
}
