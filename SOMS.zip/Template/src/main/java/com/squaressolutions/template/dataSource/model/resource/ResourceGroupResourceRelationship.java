package com.squaressolutions.template.dataSource.model.resource;

import jakarta.persistence.Entity;
import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import org.hibernate.annotations.GenericGenerator;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;
import java.util.Date;

import org.springframework.stereotype.Component;
import lombok.Data;

@Component
@Entity(name="res_grp_res_relationship")
@Data
public class ResourceGroupResourceRelationship {
	@Id
	@GeneratedValue(generator = "increment")
	@GenericGenerator(name="increment", strategy = "increment")
	@Column(name = "id")
	private Long id;
	@Column(name = "resource_group_id")
	private Long resourceGroupId;
	@Column(name = "resource_id")
	private Long resourceId;
	@Column(name = "relationship_group_id")
	private Long relationshipGroupId;
	@Column(name = "start_date")
	private Date startDate;
	@Column(name = "end_date")
	private Date endDate;
	@Size(min=1, max = 1)
	@Column(name = "status_code")
	private String statusCode;

}