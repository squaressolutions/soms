package com.squaressolutions.template.security.service.impl;

import org.springframework.context.annotation.Profile;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.stereotype.Service;

import com.squaressolutions.template.security.authentications.InMemoryAuthenticationService;
import com.squaressolutions.template.service.util.LoggerService;

@Profile("prod")
@Service
public class InMemoryAuthenticationServiceImpl implements InMemoryAuthenticationService {
	@Override
	public DaoAuthenticationProvider authenticationProvider(PasswordEncoder passwordEncoder) {
	    DaoAuthenticationProvider daoAuthenticationProvider = new DaoAuthenticationProvider();
	    daoAuthenticationProvider.setUserDetailsService(inMemoryUserDetails(passwordEncoder));
	    daoAuthenticationProvider.setPasswordEncoder(passwordEncoder);
	    return daoAuthenticationProvider;
    }
	
    private InMemoryUserDetailsManager inMemoryUserDetails(PasswordEncoder passwordEncoder) {
        LoggerService.debug("##Prod InMemoryUserDetailsManager created");

    	return new InMemoryUserDetailsManager();
    }
}
