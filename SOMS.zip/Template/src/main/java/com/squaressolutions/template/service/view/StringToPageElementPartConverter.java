package com.squaressolutions.template.service.view;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationPropertiesBinding;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.squaressolutions.common.view.model.BaseElement;
import com.squaressolutions.common.view.model.PageValidator;
import com.squaressolutions.template.service.ServiceConstants;

@Component
@ConfigurationPropertiesBinding
public class StringToPageElementPartConverter  implements Converter<String, BaseElement> {
	 
	@Override
	public BaseElement convert(String source) {
		System.out.println("***************converter called****");
		BaseElement part = new BaseElement("");
		part.setText(source);
		return part;
	}

}
