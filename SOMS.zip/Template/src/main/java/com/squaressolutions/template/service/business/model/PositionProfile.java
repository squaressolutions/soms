package com.squaressolutions.template.service.business.model;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import lombok.Data;

@Configurable
@Data
@Component
public class PositionProfile {
	private long positionId;
	private String homePagePath;
	private String orgHierarchyPath;
	private List<?> authenticationServices;
	private List<?> authorizationServices;
}
