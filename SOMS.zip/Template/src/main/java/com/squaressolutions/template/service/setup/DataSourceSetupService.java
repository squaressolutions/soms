package com.squaressolutions.template.service.setup;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import com.squaressolutions.template.service.ServiceBase;
import com.squaressolutions.template.service.ServiceConstants;
import com.squaressolutions.template.service.util.LoggerService;

//run as "run configuration" option with the profile "setup"
@Profile("setup")
@Service
public class DataSourceSetupService implements ServiceBase, CommandLineRunner {

	private static final String PROCESS_FILE = "process-order?.txt";
	private static final String TABLE_SCHEMA_SQL = "table-schema.sql";
	
	@Value("${database-schema.path}")
	private String schemaPath;	

	
	Properties propertie = new Properties();
	DatabaseSchemaFileService databaseSchemaFileService = new DatabaseSchemaFileService();	
	CreateFormService javaSchemaFileService = new CreateFormService();	
	
    @Override
    public void run(String... args) throws Exception {	 
    	if (schemaPath == null) {
    		schemaPath = args[0];
    	}
    	processFileInOrder(schemaPath);
    	LoggerService.info("Database setup has run.");
    	System.exit(0);  	
    }
    private void processFileInOrder(String schemaPath) {
    	LoggerService.debug(schemaPath);
    	//schemaPath = "dataSources/h2-schema/";
    	for (int i=0; i<3; i++) {
    		setUpDataSources(schemaPath, String.valueOf(i));
    	}
    	setupJavaDomain(schemaPath);
    	ConfigMenuFileService.setupConfigFiles(schemaPath);
    }
    private boolean setUpDataSources(String path, String orderCounter) {
    	boolean fileMatched = false;
		databaseSchemaFileService.process(path, PROCESS_FILE.replace(ServiceConstants.QUESTION_MARK, orderCounter));	    			

    	try {
			File folder = new ClassPathResource(path).getFile();
	    	for (int i=0; i<folder.listFiles().length;i++) {
	    		if (folder.listFiles()[i].isDirectory()) {
	    			String folderPath = path + ServiceConstants.BACK_SLASH + folder.listFiles()[i].getName();
	    			//LoggerService.debug("Process " + folderPath + " for database");

	    			databaseSchemaFileService.process(folderPath, PROCESS_FILE.replace(ServiceConstants.QUESTION_MARK, orderCounter));
	    			setUpDataSources(folderPath, orderCounter);
	    		}
	    	}				
		} catch (IOException e) {
			e.printStackTrace();
		}
    	return fileMatched;
    }
    private void setupJavaDomain(String path) {
    	try {
			File folder = new ClassPathResource(path).getFile();
			String domainSchema;
	    	for (int i=0; i<folder.listFiles().length;i++) {
	    		if (folder.listFiles()[i].isDirectory()) {
	    			domainSchema = path + ServiceConstants.BACK_SLASH + folder.listFiles()[i].getName() + ServiceConstants.BACK_SLASH + TABLE_SCHEMA_SQL;
	    			//LoggerService.debug("Process " + domainSchema + " for Java");
    				javaSchemaFileService.process(domainSchema);
    				setupJavaDomain(path + ServiceConstants.BACK_SLASH + folder.listFiles()[i].getName());
	    		} else if (folder.listFiles()[i].getName().equals(TABLE_SCHEMA_SQL)) {
	    			domainSchema = path + ServiceConstants.BACK_SLASH + folder.listFiles()[i].getName();
	    			//LoggerService.debug("Process " + domainSchema + " for Java");
    				javaSchemaFileService.process(domainSchema);	    			
	    		}
	    	}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
    	}
    }	
}
