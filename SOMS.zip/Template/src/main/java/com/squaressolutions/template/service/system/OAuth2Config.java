package com.squaressolutions.template.service.system;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Properties;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.security.config.oauth2.client.CommonOAuth2Provider;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.registration.InMemoryClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.AuthorizationRequestRepository;
import org.springframework.security.oauth2.client.web.HttpSessionOAuth2AuthorizationRequestRepository;
import org.springframework.security.oauth2.client.registration.ClientRegistration.Builder;
import org.springframework.security.oauth2.core.AuthorizationGrantType;
import org.springframework.security.oauth2.core.ClientAuthenticationMethod;
import org.springframework.security.oauth2.core.endpoint.OAuth2AuthorizationRequest;
import org.springframework.security.oauth2.core.oidc.IdTokenClaimNames;
import org.springframework.stereotype.Component;

import com.squaressolutions.template.service.ServiceConstants;
import com.squaressolutions.template.service.util.PropertyService;

@Component
public class OAuth2Config {
	public AuthorizationRequestRepository<OAuth2AuthorizationRequest> authorizationRequestRepository() {	 
	    return new HttpSessionOAuth2AuthorizationRequestRepository();
	}
	public ClientRegistrationRepository clientRegistrationRepository() {
		HashMap<String, HashMap<String, String>> clientKeys = new HashMap<String, HashMap<String, String>>();
		List<ClientRegistration> registrations = new ArrayList();
		Properties properties = PropertyService.loadProperty("security/oauth2.properties");
	    for(String k : properties.stringPropertyNames()) {
	    	String v = properties.getProperty(k);
		    String sk = k.toString();
		    String[] keyElements = k.toString().split(ServiceConstants.FORWARD_SLASH+ServiceConstants.DOT);
		    String client = keyElements[keyElements.length-2];
		    String attrName = keyElements[keyElements.length-1];
		    
		    if (clientKeys.size() > 0 && clientKeys.get(client)!= null) {
		    	clientKeys.get(client).put(attrName, v);
		    } else {
		    	HashMap<String, String> attribute = new HashMap<String, String>();
		    	attribute.put(attrName, v);
		    	clientKeys.put(client, attribute);
		    }
		    
		};
        for (Entry<String, HashMap<String, String>> client : clientKeys.entrySet()) {
            HashMap<String, String> attributeSet = client.getValue();
            ClientRegistration registration = builtClientRegistration(client.getKey(),
            		attributeSet.get("registration-id"),
            		attributeSet.get("client-id"),
            		attributeSet.get("client-secret"));
	    	registrations.add(registration);
            
        }
		return new InMemoryClientRegistrationRepository(registrations);
	}
	private ClientRegistration builtClientRegistration(String client, String registrationId, String clientId, String clientSecret) {
		for (CommonOAuth2Provider provider : CommonOAuth2Provider.values()) {
			if (provider.name().equals(client.toUpperCase())) {
				return (provider
				.getBuilder(registrationId)
				.clientId(clientId)
				.clientSecret(clientSecret).build());	
			}
		}
		return null;
	}
}