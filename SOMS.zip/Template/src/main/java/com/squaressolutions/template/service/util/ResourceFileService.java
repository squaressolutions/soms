package com.squaressolutions.template.service.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import com.squaressolutions.common.view.model.Page;
import com.squaressolutions.template.service.ServiceBase;
import com.squaressolutions.template.service.ServiceConstants;


@Service
public class ResourceFileService implements ServiceBase {
	
	public static Resource getResource(String configPath) {
		ResourceLoader resourceLoader = new DefaultResourceLoader();
		Resource resource = resourceLoader.getResource(configPath);
		return resource;
	}
	protected File getFileFromResources(String filePath) {
	    ClassLoader classLoader = getClass().getClassLoader();
	    URL resource = classLoader.getResource(filePath);
	    if (resource ==  null) {
	        return new File(ServiceConstants.EMPTY);
	    } else {
	        return new File(resource.getFile());
	    }
	}
	public boolean process(String... args) {
		return process(args[0]);
	}
	public boolean process(String filePath) {
		File file = getFileFromResources(filePath);
		if (file.exists()) {	
			LoggerService.debug("Process " + file + " for Java");
			try (FileReader reader = new FileReader(file);
				BufferedReader br = new BufferedReader(reader)) {
				return processLines(br);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}
	public static boolean isResourceFile(String path) {
		ClassPathResource classPathResource = new ClassPathResource(path);
		return classPathResource.exists();
	}
	public static boolean isFile(String path) {
		File file = new File(path);
		return file.isFile();
	}	
	public static String getFileInPath(String path, String aFile) {
		int i = StringService.count(path, ServiceConstants.BACK_SLASH.toCharArray()[0]);
		String theFile = path + ServiceConstants.BACK_SLASH + aFile;
		for (; i>0; i--) {
			if (isResourceFile(theFile)) {
				break;
			} else {
				path = path + "../";
				theFile = path + aFile;
			}
		}
		return new File(theFile).toPath().normalize().toString().replace(ServiceConstants.FORWARD_SLASH, ServiceConstants.BACK_SLASH);
	}
	private void tempFile() {
		 try {
			Path tempFile = Files.createTempFile(null, null);

			  // Writes a string to the above temporary file
			  Files.write(tempFile, "temp.txt".getBytes(StandardCharsets.UTF_8));
			  logger.debug(tempFile.getParent() + "  " + tempFile.getFileName() );
				//Files.deleteIfExists();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
		}	
	}
   public String resourceFile2String(String filePath) {
    	String contents = "";
        System.out.println(filePath);
		try {
			InputStream inputStream = getClass().getClassLoader().getResourceAsStream(filePath);	
			contents =new String(inputStream.readAllBytes(), StandardCharsets.UTF_8);
	        System.out.println(contents.toString());
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    return contents.toString();
    }
    private Page newPage(String pageXml) {
    	 Page page = new Page();
    	JAXBContext jaxbContext;
    	try
    	{
    	  jaxbContext = JAXBContext.newInstance(Page.class);        
    	 
    	  Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
    	 
    	  page = (Page) jaxbUnmarshaller.unmarshal(new StringReader(pageXml));
    	   
    	  System.out.println(page);
    	}
    	catch (JAXBException e) 
    	{
    	  e.printStackTrace();
    	}
    	return page;	 
    }
	protected void writeFile(String filePath, String text) throws IOException 
	{  
		File file = new File(filePath);
		file.getParentFile().mkdirs();
	    BufferedWriter writer = new BufferedWriter(new FileWriter(filePath));
	    writer.write(text);
	    writer.close();
	}
	protected boolean processLines(BufferedReader br) throws IOException {
		return true;	
	}
}
