package com.squaressolutions.template.dataSource.model.location;

import jakarta.persistence.Entity;
import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import org.hibernate.annotations.GenericGenerator;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;
import java.util.Date;

import org.springframework.stereotype.Component;
import lombok.Data;

@Component
@Entity(name="continent_name")
@Data
public class ContinentName {
	@Id
	@GeneratedValue(generator = "increment")
	@GenericGenerator(name="increment", strategy = "increment")
	@Column(name = "id")
	private Long id;
	@Size(min=1, max = 10)
	@NotNull
	@Column(name = "name")
	private String name;
	@Size(min=1, max = 3)
	@NotNull
	@Column(name = "short_name")
	private String shortName;

}