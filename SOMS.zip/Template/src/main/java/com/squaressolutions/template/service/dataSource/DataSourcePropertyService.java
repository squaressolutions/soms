package com.squaressolutions.template.service.dataSource;

import java.io.IOException;
import java.util.Properties;

import org.jasypt.encryption.StringEncryptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;

import com.squaressolutions.template.security.JasyptAdvancedService;
//import com.squaressolutions.template.repo.dataSource.JpaDriverManager;
import com.squaressolutions.template.service.ServiceBase;
import com.squaressolutions.template.service.ServiceConstants;
import com.squaressolutions.template.service.util.LoggerService;
import com.squaressolutions.template.service.util.ResourceFileService;
import com.zaxxer.hikari.HikariConfig;

//@PropertySource("classpath:config.properties")

@Service
public class DataSourcePropertyService implements ServiceBase {

	private static String HIKARI_CONFIG_FILE = "/dataSources/hikari.properties";
	
	public static final String CONFIG_PROPERTIES = "config.properties";
	public static final String URL = "url";
	public static final String DRIVER_CLASS_NAME = "driverClassName";
	public static final String USER_NAME = "username";
	public static final String PASSWORD = "password";
	
	private HikariConfig getHikariConfig(String dataSourceConfigPath) {
		HikariConfig config = new HikariConfig(HIKARI_CONFIG_FILE);
	    Properties properties = loadProperties(dataSourceConfigPath + CONFIG_PROPERTIES);
	    config.setJdbcUrl(properties.getProperty(URL));
	    config.setDriverClassName(properties.getProperty(DRIVER_CLASS_NAME));
	    config.setUsername(properties.getProperty(USER_NAME));
        config.setPassword(JasyptAdvancedService.decrypt(properties.getProperty(PASSWORD)));
	    return config;
	}
	public HikariConfig getPathHikariConfig(String path) {
		String dataSourceConfigPath = path + CONFIG_PROPERTIES;
		if (ResourceFileService.isResourceFile(dataSourceConfigPath)) {
			return getHikariConfig(dataSourceConfigPath);
		} 
		return null;
	}
	public static Properties loadProperties(String path) {
		Properties properties = new Properties();
		try {
			properties.load(Thread.currentThread().getContextClassLoader().getResourceAsStream(dBConfigPropertyFile(path)));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return properties;
	}
	private static String dBConfigPropertyFile(String path) {
		return ResourceFileService.getFileInPath(path, CONFIG_PROPERTIES);
	}
	public Properties getHibernateProperties(String path) {
		Properties properties = loadProperties(path);
		return properties;
	}
	public Properties getJakartaPersistenceUnitProperties(String path) {
		Properties properties = loadProperties(path);
		return propertiesToJakartaPersistenceUnitProperties(properties);
	}
	public Properties propertiesToJakartaPersistenceUnitProperties(Properties properties) {
		Properties jakartaPersistenceUnitProperties = new Properties();
		jakartaPersistenceUnitProperties.setProperty("jakarta.persistence.jdbc.url", (String) properties.get(URL));
		jakartaPersistenceUnitProperties.setProperty("jakarta.persistence.jdbc.driver", (String) properties.get(DRIVER_CLASS_NAME));
		jakartaPersistenceUnitProperties.setProperty("jakarta.persistence.jdbc.user", (String) properties.get(USER_NAME));
		jakartaPersistenceUnitProperties.setProperty("jakarta.persistence.jdbc.password", (String) properties.get(PASSWORD)); 	
	   	return jakartaPersistenceUnitProperties;
	}
	public static DataSourceProperties getDataSourceProperties(String path) {
		Properties properties = loadProperties(path);
		return (propertiesToDataSourceProperties(properties));
	}
	public static DataSourceProperties propertiesToDataSourceProperties(Properties properties) {
		DataSourceProperties dataSourceProperties = new DataSourceProperties();
		dataSourceProperties.setUrl(properties.getProperty(URL));
		dataSourceProperties.setDriverClassName(properties.getProperty(DRIVER_CLASS_NAME));
		dataSourceProperties.setUsername(properties.getProperty(USER_NAME));
		dataSourceProperties.setPassword(JasyptAdvancedService.decrypt(properties.getProperty(PASSWORD)));
		return dataSourceProperties;
	}

}
