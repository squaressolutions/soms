package com.squaressolutions.template.security.authentications;

import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.ldap.core.ContextSource;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.ldap.DefaultSpringSecurityContextSource;
import org.springframework.security.ldap.server.UnboundIdContainer;
import org.springframework.stereotype.Service;

import com.squaressolutions.template.service.util.LoggerService;

//@Service
public class AuthenticationManagerResolverService {
	//@Bean
//  public AuthenticationManagerResolver<HttpServletRequest> resolver(HttpSecurity httpSecurity) {
//     	LoggerService.debug("****resolver**##########################**********");
//             return request -> {
//      	LoggerService.debug(request.getUserPrincipal()+"****resolver**##########################**********");
//      	request.getAttribute("IdentityService");
//      	AppUser user = (AppUser) request.getUserPrincipal();
//         	LoggerService.debug("****resolver**##########################**********"+request.getPathInfo());
//      	System.out.println("*******resolver**************"+request.getPathInfo());
//      	
//      	LoggerService.debug(request.getPathInfo()+"******##########################**********");
//      	
//          if (request.getPathInfo().startsWith("/employee")) {
//              return authenticationManager(httpSecurity);
//          }
//          return null;
//      };
//  }
  

}
