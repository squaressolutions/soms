package com.squaressolutions.template.service.dataSource;

import java.lang.reflect.Field;
import java.net.URL;

import javax.sql.DataSource;

import org.hibernate.jpa.HibernatePersistenceProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.stereotype.Service;

import com.squaressolutions.template.service.ServiceBase;
import com.squaressolutions.template.service.ServiceConstants;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;

//@Service
public class JakartaPersistenceService implements ServiceBase, DataSourceEntityService, AutoCloseable 
{
	@Lazy
	@Autowired
	HikariConnectionPoolService hikariConnectionPoolService;

	private EntityManagerFactory entityManagerFactory;
	private EntityManager entityManager;
	private LocalContainerEntityManagerFactoryBean entityManagerFactoryBean;
		
	public JakartaPersistenceService() {
		super();
	}
	public Object get(String configPath, Class clazz, long id) {
		entityManager = createEntityManager(configPath);
		return entityManager.find(clazz, id);
	}	
	public long persist(String configPath, Object object) {
		entityManager = createEntityManager(configPath);
		entityManager.getTransaction().begin();
		entityManager.persist(object);
		entityManager.getTransaction().commit();
		long id = ServiceConstants.INVALID;
		try {
			Field field = object.getClass().getDeclaredField("id");
		    field.setAccessible(true);
		    id = (long) field.get(object);
		} catch (NoSuchFieldException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
				e.printStackTrace();
		} 
		closeEntityManager(entityManager);
		return id;
	}
	public void merge(String configPath, Object object) {
		entityManager = createEntityManager(configPath);
		entityManager.getTransaction().begin();
		entityManager.merge(object);
		entityManager.getTransaction().commit();
		closeEntityManager(entityManager);
    }
	private void closeEntityManager(EntityManager entityManager) {
		if (entityManager != null) {
			entityManager.clear();
			entityManager.close();		
		}
	}
   	private void createEntityManager() {
   		//This requires /META-INF/persistence.xml
		//entityManagerFactory = Persistence.createEntityManagerFactory("Template");
	    //entityManager = entityManagerFactory.createEntityManager();
   	}
   	@Override
	public void close() throws Exception {
   		logger.debug("Close Jakarta persistence session");
		closeEntityManager(entityManager);
		if (entityManagerFactory != null) {
			entityManagerFactory.close();		
		}
	}

   	private LocalContainerEntityManagerFactoryBean loadLocalContainerEntityManagerFactoryBean() {
	    LocalContainerEntityManagerFactoryBean entityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();
	    entityManagerFactoryBean.setPersistenceProvider(new HibernatePersistenceProvider());

	    return entityManagerFactoryBean;
   	}
   	private EntityManager createEntityManager(String configPath) {
	    LocalContainerEntityManagerFactoryBean entityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();
	    entityManagerFactoryBean.setPersistenceProviderClass(org.hibernate.jpa.HibernatePersistenceProvider.class);
		//URL rootUrl = entityManagerFactoryBean.getPersistenceUnitInfo().getPersistenceUnitRootUrl();
	    //entityManagerFactoryBean.setPersistenceUnitRootLocation(rootUrl.toExternalForm());
	    entityManagerFactoryBean.setPackagesToScan(HibernateService.MODEL_PATH); 
		DataSource dataSource = hikariConnectionPoolService.getPoolService(configPath).getDataSource();
	    entityManagerFactoryBean.setDataSource(dataSource);
	    //entityManagerFactoryBean.setJpaProperties((new DataSourcePropertyService()).getJakartaPersistenceUnitProperties(configPath));
		entityManagerFactoryBean.afterPropertiesSet();
		
	    EntityManagerFactory entityManagerFactory = entityManagerFactoryBean.getObject();
	    return entityManagerFactory.createEntityManager();
   	}	    
}

