package com.squaressolutions.template.security;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.caffeine.CaffeineCache;
import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;

import com.github.benmanes.caffeine.cache.Cache;
import com.squaressolutions.template.controller.BaseController;
import com.squaressolutions.template.controller.GenericWebController;
import com.squaressolutions.template.security.auditing.AuditHttpService;
import com.squaressolutions.template.service.system.SystemSettingHelper;
import com.squaressolutions.template.service.util.EmailService;
import com.squaressolutions.template.service.util.HttpRequestHelper;
import com.squaressolutions.template.service.util.LoggerService;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Service
public class LoginAttemptService extends SimpleUrlAuthenticationFailureHandler {
	private static final String PREV_SESSION_ID = "prevSessionId";
	public static final String REQ_STATUS = "req_status";
	public static final String USER_NAME = "username";

	@Autowired
	AttemptCounterCacheService attemptCounterService;
	@Autowired
	HttpRequestHelper httpRequestHelper;
	@Autowired
	SystemSettingHelper systemSettingHelper;
	@Autowired
	AuditHttpService auditHttpService;
	@Autowired
	EmailService emailService;


	
    @Override
	public void onAuthenticationFailure(
		HttpServletRequest request,
		HttpServletResponse response,
		AuthenticationException exception) 
		throws IOException, ServletException {
    	
		String ip = httpRequestHelper.getClientIP(request);
		AttemptDetails attemptDetails = setAttemptCounter(request, ip);
		
		String sessionId = request.getRequestedSessionId();
		attemptDetails = setAttemptCounter(request, sessionId);		
		HttpSession session = request.getSession();
		session.setAttribute(PREV_SESSION_ID, sessionId)	;	

		String userName = request.getParameter(USER_NAME);
		attemptDetails = setAttemptCounter(request, userName);
		
		if (isRequestBlocked(request)) {
			request.getSession().setAttribute(REQ_STATUS, BaseController.LOGIN_RETURN_BLOCKED);
			notification(request);
        } else {
			request.getSession().setAttribute(REQ_STATUS, BaseController.LOGIN_RETURN_FAILED);
        }
		super.setDefaultFailureUrl(GenericWebController.MAPPING_LOGIN);        	

    	
		//LoggerService.debug(exception.getMessage());
        
		response.setStatus(HttpStatus.UNAUTHORIZED.value());
		
        auditHttpService.set(request, null);
        LoggerService.debug("LoginAttemptService is called");

        super.onAuthenticationFailure(request, response, exception);
	}
    private boolean isRequestBlocked(HttpServletRequest request) {
		String sessionStatus = (String) request.getSession().getAttribute(LoginAttemptService.REQ_STATUS);		
		if (sessionStatus != null && sessionStatus.equals(BaseController.LOGIN_RETURN_BLOCKED)) {
			return true;
		}
		int allowAttempts = systemSettingHelper.getSettingValueByNameToInt("allowLoginAttempts");
		String key = httpRequestHelper.getClientIP(request);
		AttemptDetails attemptDetails = getAttemptDetails(request, key);
		boolean isBlocked = attemptDetails.getAttempted() >= allowAttempts;
		HttpSession session = request.getSession();
		key =(String) session.getAttribute(PREV_SESSION_ID)	;	
		if (key != null) {
			attemptDetails = getAttemptDetails(request, key);
			isBlocked = isBlocked || attemptDetails.getAttempted() >= allowAttempts;			
		}

		key = request.getParameter(USER_NAME);		
		attemptDetails = getAttemptDetails(request, key);
		isBlocked = isBlocked || attemptDetails.getAttempted() >= allowAttempts;			
		
		key = request.getRequestedSessionId();		
		attemptDetails = getAttemptDetails(request, key);
		isBlocked = isBlocked || attemptDetails.getAttempted() >= allowAttempts;

		return isBlocked;
    }
    public int getAttempted(HttpServletRequest request) {
		String key = httpRequestHelper.getClientIP(request);
		AttemptDetails attemptDetails = getAttemptDetails(request, key);
		int i = attemptDetails.getAttempted();
		
		key = request.getRequestedSessionId();
		attemptDetails = getAttemptDetails(request, key);	
		return i;
    }
    public AttemptDetails getAttemptDetails(HttpServletRequest request, String key) {
 		return attemptCounterService.getAttemptDetails(new AttemptDetails(), request, key);
     }
    private AttemptDetails setAttemptCounter(HttpServletRequest request, String key) {
		AttemptDetails attemptDetails = new AttemptDetails();
		attemptDetails = attemptCounterService.getAttemptDetails(attemptDetails, request, key);
    	attemptDetails.setAttempted(attemptDetails.getAttempted()+1);    
    	return attemptDetails;
    }
    private void notification(HttpServletRequest request) {
    	//get user' email address
    	String to =  "";
        emailService.sendSimpleTemplateMessage(to);

    }
}










