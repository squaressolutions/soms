package com.squaressolutions.template.security.auditing;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import com.squaressolutions.template.controller.BaseController;
import com.squaressolutions.template.controller.GenericWebController;
import com.squaressolutions.template.dataSource.model.system.security.AppAudit;
import com.squaressolutions.template.dataSource.model.system.security.LoginAudit;
import com.squaressolutions.template.security.LoginAttemptService;
import com.squaressolutions.template.security.authentication.user.AppUser;
import com.squaressolutions.template.service.data.DataService;
import com.squaressolutions.template.service.dataSource.DataSourceService;
import com.squaressolutions.template.service.system.SystemSettingHelper;
import com.squaressolutions.template.service.util.FileService;
import com.squaressolutions.template.service.util.HttpRequestHelper;
import com.squaressolutions.template.service.util.LoggerService;
import com.squaressolutions.template.service.util.PropertyService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Service
@EnableScheduling
public class AuditHttpService {
	private static Properties loginProperties = PropertyService.loadProperty("security/auditingLogin.properties");
	private static Properties appProperties = PropertyService.loadProperty("security/auditingApp.properties");
	@Autowired
	SystemSettingHelper systemSettingHelper;
	@Autowired
	private  DataSourceService dataSourceService;
	@Autowired
	FileService fileService;

	public void set(HttpServletRequest request, Authentication authentication) {
		if (request.getRequestURI().equals(GenericWebController.MAPPING_LOGIN) ||
		    request.getRequestURI().equals(GenericWebController.MAPPING_SUBMIT) ||
		    request.getRequestURI().equals(GenericWebController.MAPPING_LOGOUT)) {
			new Runnable() {
			    public void run() {
			    	try {
						save(request, authentication);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			    }
			}.run();
		}
	}
	private  void save(HttpServletRequest request, Authentication authentication) {
		LoginAudit audit = new LoginAudit();
		//When Where Who How
		audit.setAuditTime(new Date());
		audit.setBrowser(HttpRequestHelper.getClientBrowser(request));
		audit.setIp(HttpRequestHelper.getClientIP(request));
		audit.setUri(HttpRequestHelper.getRequestURI(request));
		audit.setOs(HttpRequestHelper.getClientOS(request));
		audit.setUserAgent(HttpRequestHelper.getUserAgent(request));
		audit.setUsername(HttpRequestHelper.getUserName(request));
		String action = "Login";
		if (authentication == null) {
			action = "Attempt";
			if (systemSettingHelper.getSettingValueByNameToStr("attemptLogins").contains(audit.getUsername())) {
				audit.setPassword(HttpRequestHelper.getPassword(request));				
			}
		} else if (audit.getUsername() == null) {
			
			audit.setUsername(authentication.getName());
			action = "Logout";
		} else {
			String sessionStatus = (String) request.getSession().getAttribute(LoginAttemptService.REQ_STATUS);		
			if (sessionStatus != null && sessionStatus.equals(BaseController.LOGIN_RETURN_BLOCKED)) {
				action = "Blocked";				
			}
		}
		audit.setAction(action);
		dataSourceService.persist(getDatabasePath(loginProperties), audit);
	}
	private String getDatabasePath(Properties properties) {
		return properties.getProperty("database");		
	}
	@Scheduled(cron = "0 0 23 30 * ?")
	private void archiveLoginAuditing() {
		archiveAuditing(loginProperties);
	}
	@Scheduled(cron = "0 0 23 30 * ?")
	private void archiveAppAuditing() {
		archiveAuditing(appProperties);
	}
	public void archiveAuditing(Properties properties) {
		String query = properties.getProperty("archiveQuery");		
		ArrayList dataList = dataSourceService.getDataList(getDatabasePath(loginProperties), query, DataService.FORMAT_NAME_MAP);
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat(properties.getProperty("fileFormat"));
		String path = formatter.format(date);
		path = properties.getProperty("archivePath")+ path + properties.getProperty("fileExtension");
		
		try {
			fileService.writeFile(path, dataList);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public Date getLastLogin() {
		//ToDo: to get date from audit record
		return new Date();
	}
	
}
