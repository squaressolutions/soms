package com.squaressolutions.template.security.authentication.user;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.function.Function;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.squaressolutions.template.dataSource.model.access.Identity;
import com.squaressolutions.template.dataSource.model.access.Permission;
import com.squaressolutions.template.service.ServiceConstants;

import lombok.Data;

@Data
public class AppUser extends User implements UserDetails {

	private static final long serialVersionUID = -1121604966697753298L;
	
	@Autowired
	private List<Identity> identitis;
	@Autowired
	private List<Permission> permissions;
	private long postionId = ServiceConstants.INVALID;
	private String AuthenticationPath;
	private String key;
	private Date lastAccessDate;
	
	private AppUser(String username, String password, Collection<? extends GrantedAuthority> authorities) {
		super(username, password, authorities);
		setKey();
	}
	public AppUser(UserDetails userDetails) {
		this(userDetails.getUsername(), userDetails.getPassword(), userDetails.getAuthorities());
		setKey();
	}  
	public AppUser(LdapUser ldapUser) {
		this(ldapUser.getCommonName(), "*********", ldapUser.getAuthorities());
		setKey();
	}  
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getName()).append(" [");
		sb.append(getKey());
		sb.append("Permissions=").append(this.permissions).append("]");
		return super.toString()+sb.toString();
	}
	public void setKey() {
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();				
		setLastAccessDate(new Date());
		setKey(encoder.encode(getLastAccessDate().toString()));
	}
}
