package com.squaressolutions.template.service.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.apache.commons.validator.GenericValidator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.squaressolutions.template.service.ServiceBase;
import com.squaressolutions.template.service.ServiceConstants;

@Service
public class DateService implements ServiceBase{
	static final String YYYY = "yyyy";
	static final String YY = "yy";
	static final String MM = "mm";
	static final String DD = "dd";

	private static String dataSourceDateFormat;
	private static String dateFormat;

	@Value("${app.date.format}")
    private void setStaticDateFormat(String dateFormat){
        DateService.dateFormat = dateFormat;
    }
	@Value("${app.data.source.date.format}")
    private void setStaticDataSourceDateFormat(String dateFormat){
        DateService.dataSourceDateFormat = dateFormat;
    }
	public static String getGlobalFormat() {
		return dateFormat;
	}
	public static String getTodayDate() {
		return LocalDate.now().toString();
	}
	public static Date format(String dateStr) {
		ZoneId defaultZoneId = ZoneId.systemDefault();
        LocalDate localDate = LocalDate.parse(dateStr);
	    //local date + atStartOfDay() + default time zone + toInstant() = Date
	    return Date.from(localDate.atStartOfDay(defaultZoneId).toInstant());	        
	}	
	public static String formatToDataSourceDate(String dateStr, String formatter) throws Exception {
		return format(dateStr, formatter, dataSourceDateFormat);
	}
	public static LocalDate formatToLocalDate(String dateStr, String formatter) throws Exception {
		//eg. dd/mm/yyyy
	    //get date component according to its format
		formatter = formatter.toLowerCase();
		if (dateStr.contains(ServiceConstants.DASH) && formatter.contains(ServiceConstants.DASH) 
				|| dateStr.contains(ServiceConstants.BACK_SLASH) && formatter.contains(ServiceConstants.BACK_SLASH)) {
			int yyyy=getNumInStr(dateStr, formatter, YYYY); 
			if (yyyy<0) {
				yyyy=getNumInStr(dateStr, formatter, YY);
			}
			int mm=getNumInStr(dateStr, formatter, MM);
			int dd=getNumInStr(dateStr, formatter, DD);
			return LocalDate.of(yyyy, mm, dd);
		}
		
		return LocalDate.parse(dateStr);
	}
	public static String formatToFormatStr(String localDateStr, String formatter) {
		LocalDate localDate = LocalDate.parse(localDateStr);
		String dateStr = replace(formatter.toLowerCase(), YYYY, localDate.getYear());
		dateStr = replace(dateStr, YY, localDate.getYear());
		dateStr = replace(dateStr, MM, localDate.getMonthValue());
		dateStr = replace(dateStr, DD, localDate.getDayOfMonth());
		return dateStr;
	}
	public static String formatToLocalDateStr(String dateStr, String formatter) throws Exception {
		if (formatter.isEmpty()) {
			formatter = getGlobalFormat();
		}
		return formatToLocalDate(dateStr, formatter).toString();
	}
	public static int compareToToday(Date theDate) {
		  return new Date().compareTo(theDate);
	}
	public static boolean beforeToday(Date theDate) {
		  return new Date().before(theDate);
	}
	public static boolean afterToToday(Date theDate) {
		  return new Date().after(theDate);
	}
	public static boolean asToday(Date theDate) {
		  return new Date().equals(theDate);
	}
	private static String format(String dateStr, String fromFormatter, String toFormatter) throws Exception {
		fromFormatter = fromFormatter.toLowerCase();
		toFormatter = toFormatter.toLowerCase();
		if (dateStr.contains(ServiceConstants.DASH) && fromFormatter.contains(ServiceConstants.DASH) 
			|| dateStr.contains(ServiceConstants.BACK_SLASH) && fromFormatter.contains(ServiceConstants.BACK_SLASH)) {
			
			String yyyy=getStr(dateStr, fromFormatter, YYYY); 
			if (yyyy.isEmpty()) {
				yyyy=getStr(dateStr, fromFormatter, YY);
			}
			String mm=getStr(dateStr, fromFormatter, MM);
			String dd=getStr(dateStr, fromFormatter, DD);
			dateStr = toFormatter.replace(YYYY, yyyy);
			dateStr = dateStr.replace(MM, mm);		
			dateStr = dateStr.replace(DD, dd);
		}
		return dateStr;
	}
	private static String getStr(String dateStr, String formatter, String lookFor) throws Exception {
		int i=formatter.indexOf(lookFor);		
		return dateStr.substring(i,i+lookFor.length());		
	}
	private static int getNumInStr(String dateStr, String formatter, String lookFor) throws Exception {
		return Integer.valueOf(getStr(dateStr, formatter, lookFor));		
	}
	private static String replace(String str, String pattern, int value) {
		String valueStr = "0"+String.valueOf(value);
		int i = valueStr.length();
		valueStr =  valueStr.substring(i-pattern.length(),i);
		if (str.contains(pattern)) {
			return str.replaceAll(pattern, valueStr);
		} else {
			return str;
		}
	}
	public static String getCurrentDayOfMonth() {
		return String.valueOf(LocalDate.now().getDayOfMonth());
		
	}
	public static String getCurrentMonth() {
		return String.valueOf(LocalDate.now().getMonthValue());
		
	}
	public static String getCurrentMonthName() {
		return String.valueOf(LocalDate.now().getMonth());
		
	}
	public static String getCurrentYear() {
		return String.valueOf(LocalDate.now().getYear());
		
	}
}
