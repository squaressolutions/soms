package com.squaressolutions.template.service.util;

import java.util.ArrayList;
import java.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.squaressolutions.template.service.ServiceBase;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class LoggerService {
	private final static Logger logger = LoggerFactory.getLogger(ServiceBase.class);
	private final static  StackWalker stackWalker = StackWalker
            .getInstance(StackWalker.Option.RETAIN_CLASS_REFERENCE);
	private static ArrayList filterList = new ArrayList();
	public static void info(String msg) {
		logger.info(msg);
	}
	public static void info(String msg, long data) {
		logger.info(msg, data);
	}
	public static void warn(String msg) {
		logger.warn(msg);
	}
	public static void trace(String msg) {
		if (passFilter(getCaller())) {
			logger.debug(getCaller());
			logger.trace(msg);
		}
	}
	public static void debug(String msg) {
		if (passFilter(getCaller())) {
			logger.debug(getCaller());
			logger.debug(msg);
		}
	}
	public static void error(String msg) {
		logger.debug(getCaller());
		logger.error(msg);
	}
	public static void showCaller() {
		logger.trace(getCaller());
		logger.debug(getCaller());
	}
	public void addFilter(String filter) {
		filterList.add(filter);
	}
	public void removeFilter(String filter) {
		filterList.remove(filter);
	}
	public void clearFilter() {
		filterList.clear();
	}
	private static String getCaller() {
        StackWalker.StackFrame frame = stackWalker.walk(stream1 -> stream1.skip(2).findFirst().orElse(null));
        if (frame == null) {
            return "caller: null";
        }
        return String.format("caller: %s#%s, %s",
                frame.getClassName(),
                frame.getMethodName(),
                frame.getLineNumber()
        );
    }
	private static boolean passFilter(String line) {		
		return filterList.isEmpty() || filterList.stream().anyMatch(item -> line.contains(item.toString()));
	}
}
