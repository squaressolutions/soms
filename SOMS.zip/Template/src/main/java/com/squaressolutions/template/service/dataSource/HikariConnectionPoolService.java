package com.squaressolutions.template.service.dataSource;

import java.io.File;
import java.io.IOException;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.web.context.support.GenericWebApplicationContext;

import com.squaressolutions.template.service.ServiceBase;
import com.squaressolutions.template.service.ServiceConstants;
import com.squaressolutions.template.service.util.LoggerService;

@Profile("dev || prod || ''")
@Configuration
@Service
public class HikariConnectionPoolService implements ServiceBase, AutoCloseable {
	public final String schemaPath = "dataSources/h2-schema/";	
	private GenericWebApplicationContext context;

	
    public HikariConnectionPoolService() {
		super();
		context = new GenericWebApplicationContext();
    	context.refresh();
		setUpPoolServices(schemaPath);
	}

	public void setUpPoolServices(String path) {
    	try {
			File folder = new ClassPathResource(path).getFile();
			String prevFolderPath = ServiceConstants.EMPTY, folderPath;
	    	for (int i=0; i<folder.listFiles().length;i++) {
	    		if (folder.listFiles()[i].isDirectory()) {	   
	    			folderPath = path + folder.listFiles()[i].getName() + ServiceConstants.BACK_SLASH;
	    			if (!folderPath.equals(prevFolderPath)) {
		    			addPoolService(folderPath);
		    			prevFolderPath = folderPath;
		    			try {
		    				setUpPoolServices(folderPath);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
	    			}
	    		}
	    	}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    public void addPoolService(String path) {
	    AutowireCapableBeanFactory factory = context.getAutowireCapableBeanFactory();
	    BeanDefinitionRegistry registry = (BeanDefinitionRegistry) factory;
	    HikariDataSourceService hikariDataSourceService = new HikariDataSourceService().getPathHikariDataSourceService(path);
	    if (hikariDataSourceService != null) {
	    	context.registerBean(path, HikariDataSourceService.class, () -> hikariDataSourceService);
	    	LoggerService.debug(hikariDataSourceService.getDataSource().getCatalog());
	    }
    }
    public HikariDataSourceService getPoolService(String path) {
        try {
			return (HikariDataSourceService) context.getBean(path);
		} catch (BeansException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return null;
    }

	@Override
	public void close() throws Exception {
		context.close();
	}
}
