package com.squaressolutions.template.service.dataSource;

import javax.sql.DataSource;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Lazy;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.squaressolutions.template.service.ServiceBase;
import com.squaressolutions.template.service.util.ClassService;


@EnableTransactionManagement
public class HibernateService implements ServiceBase, DataSourceEntityService
{
	private static String HIBERNATE_CONFIG_FILE = "dataSources/hibernate.cfg.xml";
	public static String MODEL_PATH = "com.squaressolutions.template.dataSource.model";

	@Lazy
	@Autowired
	HikariConnectionPoolService hikariConnectionPoolService;

	Configuration configuration;

	
	public HibernateService() {
		super();
		config();
	}
	public Object get(String configPath, Class clazz, long id) {
		SessionFactory sessionFactory = getSessionFactory(configPath);
		Session session = getCurrentSession(sessionFactory);
		Object object = session.get(clazz.getName(), id);
		closeSession(session);
		sessionFactory.close();
		return object;
	}
	public long persist(String configPath, Object object) {	  
		SessionFactory sessionFactory = getSessionFactory(configPath);
		Session session = getCurrentSession(sessionFactory);
		session.beginTransaction();
		session.persist(object);		
		long id = (long) session.getIdentifier(object);
		session.getTransaction().commit();
		closeSession(session);
		sessionFactory.close();
		return id;	
	}
	public void merge(String configPath, Object object) {
		SessionFactory sessionFactory = getSessionFactory(configPath);
		Session session = getCurrentSession(sessionFactory);
		session.beginTransaction();
		session.merge (object);
		session.getTransaction().commit();
		closeSession(session);
		sessionFactory.close();
	}
	private SessionFactory getSessionFactory(String configPath) {
		DataSource dataSource = hikariConnectionPoolService.getPoolService(configPath).getDataSource();
		//create the SessionFactory from configuration
		return configuration
		    .buildSessionFactory(
		        new StandardServiceRegistryBuilder()
		            .applySettings(configuration.getProperties())
		            //here you apply the custom dataSource
		            .applySetting(Environment.DATASOURCE, dataSource)
		            .build());
	}
	private void config() {
		configuration = new Configuration();
		configuration = scanPackage(configuration, MODEL_PATH);
		configuration.configure(HIBERNATE_CONFIG_FILE);		
	}
	private Configuration scanPackage(Configuration configuration, String packagePath) {
		try {
			Object[] beans = ClassService.allConfigurationClassesInPackage(packagePath);
			for (Object bean : beans) {
				configuration.addAnnotatedClass(Class.forName(((BeanDefinition) bean).getBeanClassName()));
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return configuration;
	}
	private Session getCurrentSession(SessionFactory sessionFactory) {
		if (!sessionFactory.isOpen() || sessionFactory.isClosed()) {
			sessionFactory.openSession();
		}
		Session session;
		try {
		    session = sessionFactory.getCurrentSession();
		} catch (HibernateException e) {
		    session = sessionFactory.openSession();
		}
		return session;
	}
//	public long generateId(Object object, Session session2) {
//		SessionImplementor hibernateSession=((SessionImplementor)getCurrentSession(sessionFactory));
//		IdentifierGenerator generator = hibernateSession.getEntityPersister(null, object).getIdentifierGenerator();
//		Serializable id = (Serializable) generator.generate(hibernateSession, object);
//		return (long) id;
//	}
//	private LocalSessionFactoryBean getLocalSessionFactoryBean() {
//		LocalSessionFactoryBean localSessionFactoryBean = new LocalSessionFactoryBean();
//		localSessionFactoryBean.setPackagesToScan(new String[] { MODEL_PATH });
//		return localSessionFactoryBean;
//	}	
//
//	private SessionFactory getSessionFactory(String configPath) {
//		SessionFactory sessionFactory = null;
//		StandardServiceRegistry registry = null;
//		try {
//			StandardServiceRegistryBuilder registryBuilder = configRegistryBuilder(HIBERNATE_CONFIG_FILE);			
//			Properties properties = (new DataSourcePropertyService()).getHibernateProperties(configPath);
//			registryBuilder.applySettings(properties);
//
//			//dataSourcePropertyService dataSourcePropertyService = new dataSourcePropertyService();		
//			//registryBuilder.applySetting(Environment.DATASOURCE, dataSourcePropertyService.getDataSource(configPath));
//			
//			registry = registryBuilder.build();
//
//			MetadataSources metaSources = new MetadataSources(registry);
//			metaSources.addDirectory(new File(MODEL_PATH));			
//			
//			metaSources = addAnnotationClasses(metaSources);	
//			
//			Metadata metaData = metaSources.getMetadataBuilder()
//				    .applyImplicitNamingStrategy(ImplicitNamingStrategyJpaCompliantImpl.INSTANCE)
//				    .build();
//
//			SessionFactoryBuilder sessionFactoryBuilder = metaData.getSessionFactoryBuilder();
//
//			//	sessionFactoryBuilder.applyInterceptor(new CustomSessionFactoryInterceptor());
//
//			// Add a custom observer
//			//	sessionFactoryBuilder.addSessionFactoryObservers(new CustomSessionFactoryObserver());
//		
//			// Apply a CDI BeanManager (for JPA event listeners)
//			//	sessionFactoryBuilder.applyBeanManager(getBeanManager());
//			
//			return sessionFactoryBuilder.build();
//		
//		}
//		catch (Exception e) {
//			// The registry would be destroyed by the SessionFactory, but we had trouble building the SessionFactory
//			// so destroy it manually.
//			StandardServiceRegistryBuilder.destroy( registry );
//			e.printStackTrace();
//		}
//		return sessionFactory;
//	}
//	private StandardServiceRegistryBuilder configRegistryBuilder(String configFile) {
//		try {
//			return new StandardServiceRegistryBuilder().configure(configFile);
//		} catch (Exception e) {
//			logger.debug(configFile + " is not in good format");
//			e.printStackTrace();
//		}
//		return null;
//	}	
//	private MetadataSources addAnnotationClasses(MetadataSources metaSources) {
//	    String[] beanNames = appContext.getBeanNamesForType(Object.class);    	
//	    for (String bean : beanNames) 
//	    {
//	    	if (appContext.getBean(bean).getClass().getName().contains("model")) {
//	        for (Annotation ann : appContext.getBean(bean).getClass().getAnnotations() ) {
//	        	if (ann.annotationType().getName().toLowerCase().endsWith("entity")) {
//	        		metaSources.addAnnotatedClass(appContext.getBean(bean).getClass());
//	        	}
//	        }
//	        
//	    	}
//	    }		
//		return metaSources;
//	}	
 	private void closeSession(Session session) {
		if (session.isConnected()) {
	   		session.clear();
	   		session.close();		
		}
	}
}
