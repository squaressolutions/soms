package com.squaressolutions.template.service.util;

import java.io.InputStream;
import java.util.Map;

import org.yaml.snakeyaml.Yaml;

public class YamlService {
	public Map<String, Object> file2Map(String fileLocation) {
		Yaml yaml = new Yaml();
		InputStream inputStream = this.getClass().getClassLoader()
				.getResourceAsStream(fileLocation);
		Map<String, Object> map = null; //= yaml.load(inputStream);
		return map;
	}

}
