package com.squaressolutions.template.service.util;

public class TextFileService extends ResourceFileService{

}
