package com.squaressolutions.template.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.squaressolutions.common.view.model.PageContainer;
import com.squaressolutions.template.security.authentication.user.AppUser;
import com.squaressolutions.template.service.util.ClassService;
import com.squaressolutions.template.service.util.LoggerService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Controller
public class GenericWebController extends BaseController implements ControllerAuthentication, ControllerAuthorization {
	private static final long serialVersionUID = -5280930164586982467L;
	private static final String UI_Config_Path = "/config/ui/business/templates/";
	public static final String MAPPING_DEFAULT = "/";
	public static final String MAPPING_LOGIN = "/login";
	public static final String MAPPING_LOGOUT = "/logout";
	public static final String MAPPING_INDEX = "/index";
	public static final String MAPPING_HOME = "/home";
	public static final String MAPPING_ERROR = "/error";
	public static final String MAPPING_SUBMIT = "/whoareyou";

//	@PreAuthorize("#n == authentication.name")
//	Contact findContactByName(@Param("n") String name);
	@GetMapping(value={MAPPING_DEFAULT})
	public String handleRequest(@RequestParam(name="id", required=false) String id, @RequestParam(name="pid", required=false) String pid, @RequestParam("configPath") String configPath, Model model) {
		if (open() && allow()) {
		}
		return super.handleRequest(id,pid,configPath, model);			
	}
//  @GetMapping("/")
//  public String greeting(Device device) {
//		
//      String deviceType = "browser";
//      String platform = "browser";
//      String viewName = "index";
//		
//      if (device.isNormal()) {
//          deviceType = "browser";
//      } else if (device.isMobile()) {
//          deviceType = "mobile";
//          viewName = "mobile/index";
//      } else if (device.isTablet()) {
//          deviceType = "tablet";
//          viewName = "tablet/index";
//      }
//      
//      platform = device.getDevicePlatform().name();
//      
//      if (platform.equalsIgnoreCase("UNKNOWN")) {
//          platform = "browser";
//      }
//   	
//      return viewName;
//  }
//	@GetMapping("/user")
//  public Map<String, Object> user(@AuthenticationPrincipal OAuth2User principal) {
//      return Collections.singletonMap("name", principal.getAttribute("name"));
//  }
	@GetMapping(value = "/favicon.ico", produces = MediaType.IMAGE_JPEG_VALUE)
	public @ResponseBody byte[]  handleFaviconIco() {
		return super.getFavicon();
	}	
	@GetMapping(value={"",MAPPING_LOGIN})
	public String handleLoginRequest(@AuthenticationPrincipal AppUser user, Model model,HttpServletRequest request, HttpServletResponse response) {
		return super.handleLoginRequest(UI_Config_Path + "login.xml", model, request, response);		
	}
    @GetMapping(MAPPING_LOGOUT)
	public String handleLogoutRequest(Model model) {
		return super.handleRequest(UI_Config_Path + "logout.xml", model);
	}
    @PostMapping(MAPPING_LOGOUT)
	@ResponseBody
    public String handleLogoutPostRequest(@ModelAttribute(CONTAINER) PageContainer container,  BindingResult result, Model model) {
		return super.handleSubmit(container, result, model);
    }
    @GetMapping(MAPPING_HOME)
	public String handleHomeRequest(Model model) {
		return super.handleRequest(UI_Config_Path + "home.xml", model);
	}
    @GetMapping(MAPPING_ERROR)
	public String handleErrorRequest(Model model) {
		return super.handleRequest(UI_Config_Path + "error.xml", model);
	}
	@GetMapping("/internal")
	public String handleInternalRequest(@RequestParam(name="id", required=false) String id, @RequestParam(name="pid", required=false) String pid, @RequestParam("configPath") String configPath, @RequestParam("containerName") String containerName, Model model) {
    	return super.handleRequest(id, pid, configPath, model);
//    	return super.handleInternalRequest(id, pid, configPath, containerName, model);
	}
	@GetMapping("/modal")
	public String handleModalRequest(@RequestParam(name="id", required=false) String id, @RequestParam(name="pid", required=false) String pid, @RequestParam("configPath") String configPath, @RequestParam("containerName") String containerName, Model model) {
    	return super.handleModalRequest(id, pid, configPath, containerName, model);
	}
	@PostMapping("/url")
	@ResponseBody
    public String handleUrlSubmit(@ModelAttribute(CONTAINER) PageContainer container,  BindingResult result, Model model) {
		return super.handleSubmit(container, result, model);
    }
	@PostMapping("/list")
	@ResponseBody
    public String handleListSubmit(@ModelAttribute(CONTAINER) PageContainer container, BindingResult result, Model model) {
		return super.handleListSubmit(container, result, model);
    }
	@GetMapping("/data")
	@ResponseBody
	public String handleDataRequest(@RequestParam(name="id", required=false) String id, @RequestParam(name="pid", required=false) String pid,  @RequestParam(name="comIndex", required=false) String comIndex, @RequestParam(name="containerName", required=false) String containerName, @RequestParam("configPath") String configPath, Model model) {
    	return super.handleDataRequest(id,pid,comIndex, containerName, configPath, model);
	}	
	@PostMapping("/registration")
	@ResponseStatus(code = HttpStatus.CREATED)
	public void register(@ModelAttribute(CONTAINER) PageContainer container, BindingResult result, Model model) {
		//to be implemented
	}	
	private String control(String classMethod[], Object para[] ) {
		LoggerService.debug("Control called");
        try {
			return (String) ClassService.callClassMethod(classMethod, para);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return ERROR_REDIRECT_PAGE;
	}
	
}
