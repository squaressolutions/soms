package com.squaressolutions.template.security.authentication.user;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.squaressolutions.template.service.util.LoggerService;

public abstract class UserDetailsServiceImpl implements UserDetailsService { 
	@Override
    public UserDetails loadUserByUsername(String userName) {
        LoggerService.debug("##UserDetailsServiceImpl called "+ userName);
    	UserDetails userDetails = getUserDetails(userName);
        if (userDetails == null) {
        	throw new UsernameNotFoundException(userName);
        }
        return userDetails;
    }    
    abstract UserDetails getUserDetails(String userName);
}