package com.squaressolutions.template.security.authorizations;

import java.io.Serializable;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import com.squaressolutions.template.service.ServiceBase;

@Service
public class CanAccessConfig implements ServiceBase {
	//ToDo:
	public CanAccessConfig() {
	}
	public boolean preauth(String configPath) {
		System.out.println("*can**&&&&&&&&&&&&&&**********"+ configPath);
		return false;
	}
	public boolean preauth(String value1,String value2) {
		System.out.println("*preauth***********"+ value1+"======"+value2);
		return false;
	}
	public boolean postauth(String value, String v) {
		System.out.println(v+"*postauth************"+ value);
		return false;
	}
	 public boolean hasPermission(Authentication authentication, Object targetDomainObject, Object permission) {
System.out.println("*******hasPermission1***********");
return true;

	 }


	 public boolean hasPermission(Authentication authentication,

	   Serializable targetId, String targetType, Object permission) {
		 System.out.println("*********hasPermission2********");
		 return true;


	 }
}
