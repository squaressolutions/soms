package com.squaressolutions.template.service.util;

import java.io.File;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

@Service
public class EmailService {
	
	private final String HOST = "host";
	private final String USER_NAME = "username";
	private final String PW = "password";
	private final String FROM = "from";
	private final String PROTOCOL = "protocol";
	private final String PORT = "port";
	private final String AUTH = "smtp.auth";
	private final String STARTTLS_ENABLE = "smtp.starttls.enable";
	private final String STARTTLS_REQUIRED = "smtp.starttls.required";
	private final String SUBJECT = "subject";
	private final String TEXT = "text";
	private final String DEBUG = "debug";
	
	public void sendSimpleTemplateMessage(String to) {
		PropertyService propertyService = new PropertyService();
		Properties prop = PropertyService.loadProperty("email/gmail.properties");
		JavaMailSender emailSender = getJavaMailSender(prop);
		Properties template = PropertyService.loadProperty("email/template.properties");
		String text = template.getProperty(TEXT);
		SimpleMailMessage message = new SimpleMailMessage();
		message.setFrom(prop.getProperty(FROM));
		message.setTo(to); 
		message.setSubject(template.getProperty(SUBJECT)); 
		message.setText(text);
		emailSender.send(message);		
	}
	public void sendSimpleMessage(String to, String subject, String text) {
		PropertyService propertyService = new PropertyService();
		Properties prop = PropertyService.loadProperty("email/gmail.properties");
		JavaMailSender emailSender = getJavaMailSender(prop);
		SimpleMailMessage message = new SimpleMailMessage();
		message.setFrom(prop.getProperty(FROM));
		message.setTo(to); 
		message.setSubject(subject); 
		message.setText(text);
		emailSender.send(message);
	}
	public void sendMessageWithAttachment(String to, String subject, String text, String pathToAttachment) throws MessagingException {
		Properties prop = PropertyService.loadProperty("email/gmail.properties");
		JavaMailSender emailSender = getJavaMailSender(prop);
	    MimeMessage message = emailSender.createMimeMessage();	     
	    MimeMessageHelper helper = new MimeMessageHelper(message, true);
	    
	    helper.setFrom(prop.getProperty(FROM));
	    helper.setTo(to);
	    helper.setSubject(subject);
	    helper.setText(text);
	        
	    FileSystemResource file 
	      = new FileSystemResource(new File(pathToAttachment));
	    helper.addAttachment(file.getFilename(), file);
	
	    emailSender.send(message);
	}
	private JavaMailSender getJavaMailSender(Properties prop) {
	    JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
	    
	    mailSender.setHost(prop.getProperty(HOST));
	    mailSender.setPort(Integer.valueOf(prop.getProperty(PORT)));
	    
	    mailSender.setUsername(prop.getProperty(USER_NAME));
	    mailSender.setPassword(prop.getProperty(PW));
	    
	    Properties props = mailSender.getJavaMailProperties();
	    props.put("mail.transport.protocol", prop.getProperty(PROTOCOL));
	    props.put("mail.smtp.auth", prop.getProperty(AUTH));	    
	    props.put("mail.smtp.starttls.enable", prop.getProperty(STARTTLS_ENABLE));
	    props.put("mail.smtp.starttls.required", prop.getProperty(STARTTLS_REQUIRED));
	    //props.put("mail.debug", "true");	    
	    return mailSender;
	}
}