package com.squaressolutions.template.service.view;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.squaressolutions.common.view.model.PageValidator;
import com.squaressolutions.template.service.ServiceConstants;

@Service
public class PageValidatorToStringConverter  implements Converter<PageValidator, String> {
	 
	@Override
	public String convert(PageValidator source) {
		ObjectMapper converter = new ObjectMapper();
		try {
			return (converter.writeValueAsString(source));
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return ServiceConstants.EMPTY;
	}

}
