package com.squaressolutions.template.service.dataSource;

import org.springframework.stereotype.Service;

@Service
public interface DataSourceEntityService {
	public void merge(String configPath, Object object);
	public long persist(String configPath, Object object);
	public Object get(String configPath, Class clazz, long id);
}
