package com.squaressolutions.template.dataSource.model.system.security;

import jakarta.persistence.Entity;
import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import org.hibernate.annotations.GenericGenerator;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;
import java.util.Date;

import org.springframework.stereotype.Component;
import lombok.Data;

@Component
@Entity(name="users")
@Data
public class Users {
	@Id
	@GeneratedValue(generator = "increment")
	@GenericGenerator(name="increment", strategy = "increment")
	@Column(name = "id")
	private Long id;
	@NotNull
	@Size(min=1, max = 50)
	@Column(name = "username")
	private String username;
	@NotNull
	@Size(min=1, max = 500)
	@Column(name = "password")
	private String password;
	@Column(name = "start_date")
	private Date startDate;
	@Column(name = "end_date")
	private Date endDate;
	@Size(min=1, max = 1)
	@Column(name = "status_code")
	private String statusCode;
	@Size(min=1, max = 50)
	@Column(name = "last_login_ip")
	private String lastLoginIp;
	@Column(name = "last_login_date")
	private Date lastLoginDate;
	@Column(name = "last_logout_date")
	private Date lastLogoutDate;
	@Column(name = "enabled")
	private boolean enabled;

}