package com.squaressolutions.template.dataSource.model.organisation;

import jakarta.persistence.Entity;
import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import org.hibernate.annotations.GenericGenerator;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;
import java.util.Date;

import org.springframework.stereotype.Component;
import lombok.Data;

@Component
@Entity(name="org_res_attribute")
@Data
public class OrgResAttribute {
	@Id
	@GeneratedValue(generator = "increment")
	@GenericGenerator(name="increment", strategy = "increment")
	@Column(name = "id")
	private Long id;
	@NotNull
	@Size(min=1, max = 50)
	@Column(name = "name")
	private String name;
	@Size(min=1, max = 255)
	@Column(name = "description")
	private String description;
	@Column(name = "start_date")
	private Date startDate;
	@Column(name = "end_date")
	private Date endDate;
	@Size(min=1, max = 1)
	@Column(name = "status_code")
	private String statusCode;

}