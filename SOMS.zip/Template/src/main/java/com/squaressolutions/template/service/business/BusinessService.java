package com.squaressolutions.template.service.business;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindingResult;

import com.squaressolutions.common.view.model.PageComponent;
import com.squaressolutions.common.view.model.PageContainer;
import com.squaressolutions.common.view.model.PageDataSource;
import com.squaressolutions.template.security.LoginService;
import com.squaressolutions.template.service.ServiceBase;
import com.squaressolutions.template.service.ServiceConstants;
import com.squaressolutions.template.service.dataSource.DataSourceService;
import com.squaressolutions.template.service.view.validation.genernal.ContainerValidator;
import com.squaressolutions.template.service.view.validation.genernal.SpringValidator;

@Service
public class BusinessService implements ServiceBase {
	private static final int FORM_FIELD = 1;

	@Autowired
	private SpringValidator springValidator;
	@Autowired
	private ContainerValidator ContainerValidator;

	@Autowired
	DataSourceService dataSourceService;
	
	public BusinessService() {
		StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
		//for (int i=0; i<stackTraceElements.length; i++) {
			StackTraceElement stackTraceElement = stackTraceElements[1];
			System.out.println(stackTraceElement.getClassLoaderName());
			System.out.println(stackTraceElement.getClassName());
			System.out.println(stackTraceElement.getMethodName());
			 stackTraceElement = stackTraceElements[2];
			System.out.println(stackTraceElement.getClassLoaderName());
			System.out.println(stackTraceElement.getClassName());
			System.out.println(stackTraceElement.getMethodName());
			
		//}
	}
	public PageContainer processContainer(PageContainer container, BindingResult result) {
		return container;
	}
	private PageComponent processComponent(PageComponent component, BindingResult result) {
		return component;
	}
	public BindingResult processLogin(PageContainer container, BindingResult result) {
		return result;
	}
	public long getModelId(Object object) {
		return dataSourceService.getDataId(object);
	}
	public Object setModelId(Object object, long id) {
		return dataSourceService.setDataId(object, id);
	}
	public long persist(String dataSourcePath, Object object) {
		return dataSourceService.persist(dataSourcePath, object);
	}
	public void merge(String dataSourcePath, Object object) {
		dataSourceService.merge(dataSourcePath, object);
	}
	public String getValue(String sqlPara) {
		String sqlPrefix = ServiceConstants.SQL_PREFIX;
		if (sqlPara != null && sqlPara.startsWith(sqlPrefix)) {
			sqlPara = sqlPara.replace(sqlPrefix, ServiceConstants.EMPTY);
			return (String.valueOf(dataSourceService.getValue(sqlPara, 0)));
		}
		return sqlPara;
	}
	public ArrayList<String[]> getData(PageDataSource dataSource, int dataQueryIndex) {
		return dataSourceService.getDataList(dataSource, dataQueryIndex);
	}
	public BindingResult validateContainer(PageContainer container, BindingResult result, int dataIndex) {
		return ContainerValidator.validateContainer(container, result, dataIndex, this);
	}
	public BindingResult validateComponents(PageContainer container, BindingResult result, int dataIndex) {
		return ContainerValidator.validateComponents(container, result, dataIndex, this);
	}
	public void validate(Object object, BindingResult result) {
		springValidator.validate(object, result);
		
	}
	public String getUserLogin() {
		return LoginService.getAuthentication().getName();
	}
}
