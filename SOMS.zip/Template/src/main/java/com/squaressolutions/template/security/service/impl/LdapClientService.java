package com.squaressolutions.template.security.service.impl;

import java.util.List;
import java.util.jar.Attributes;

import org.springframework.ldap.core.LdapClient;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.ldap.query.LdapQueryBuilder;

public class LdapClientService {
	private LdapClient ldapClient;
	
	
	public LdapClientService(String configPath) {
		super();
	}


//	public List<String> getAll(String searchFor) {		
//		return ldapClient.search()
//		.query(query("").where("objectclass").is("person"))
//		.toList((Attributes attrs) -> (String) attrs.get("cn").get());
//	}
//    private LdapQuery query(String lastName) {
//    	return (LdapQueryBuilder.query()
//            .base("dc=261consulting,dc=com")
//            .attributes("cn", "sn")
//            .where("objectclass").is("person")
//            .and("sn").is(lastName);
//    }
}
