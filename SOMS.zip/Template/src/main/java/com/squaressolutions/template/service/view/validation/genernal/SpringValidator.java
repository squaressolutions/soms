package com.squaressolutions.template.service.view.validation.genernal;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.beanvalidation.SpringValidatorAdapter;

import com.squaressolutions.template.service.view.validation.BaseValidator;

@Component
public class SpringValidator implements BaseValidator {
	private final SpringValidatorAdapter validator;

	public SpringValidator(SpringValidatorAdapter validator) {
		 super();
		 this.validator = validator;
		}

	@Override
	public boolean supports(Class givenClass) {
		return validator.supports(givenClass);
	}

	@Override
	public void validate(Object target, Errors errors) {
		if (target != null) {
			validator.validate(target, errors);					
		} else {
			logger.debug("Error: Validation failed as the passed in object is null");
		}
	}
}