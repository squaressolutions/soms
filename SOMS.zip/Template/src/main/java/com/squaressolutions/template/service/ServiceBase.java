package com.squaressolutions.template.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.squaressolutions.template.service.util.LoggerService;

public interface ServiceBase {
	static final LoggerService logger = new LoggerService();
	public default boolean preProcess() {
		return true;
	};
	public default Object process(Object object) {
		return object;
	};
	public default Object postProcess(String elements) {
		return elements;
	}
}
