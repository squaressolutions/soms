package com.squaressolutions.template.service.setup;

import java.io.BufferedReader;
import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Service;

import com.squaressolutions.template.service.ServiceBase;
import com.squaressolutions.template.service.ServiceConstants;
import com.squaressolutions.template.service.util.LoggerService;
import com.squaressolutions.template.service.util.ResourceFileService;


@Profile("setup")
public class ConfigMenuFileService {
	
	public static final String CONFIG_SOURCE_PATH = "/src/main/resources/business/";
	public static final String TEMPLATE = "tree_template.xml";
	
	public static void setupConfigFiles(String schemaPath) {
		try {
			String appPath = new FileSystemResource("").getFile().getAbsolutePath();
			Files.createDirectories(Paths.get(appPath + CONFIG_SOURCE_PATH));
			processConfigFolders(appPath,"", schemaPath);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	protected static void processConfigFolders(String appPath, String prevFolder, String path) throws IOException {
		//Path businessPath = Paths.get(CONFIG_SOURCE_PATH);
		//String content = Files.readString(path);		
		//javaPath = javaPath.replace(ServiceConstants.BACK_SLASH, fileSeparator);
		//super.writeFile(javaPath, text);			
	   	try {
				File folder = new ClassPathResource(path).getFile();
 		    	for (int i=0; i<folder.listFiles().length;i++) {
		    		if (folder.listFiles()[i].isDirectory()) { 		
		    			String folderPath = appPath + CONFIG_SOURCE_PATH + prevFolder + folder.listFiles()[i].getName();
		    			//LoggerService.debug(folderPath);
		    			Files.createDirectories(Paths.get(folderPath));
		    			processConfigFiles(folderPath, path);
		    			processConfigFolders(appPath, prevFolder + folder.listFiles()[i].getName() + ServiceConstants.BACK_SLASH, path + ServiceConstants.BACK_SLASH + folder.listFiles()[i].getName());
		    		}
		    	}				
			} catch (IOException e) {
				e.printStackTrace();
			}

	}
	protected static void processConfigFiles(String folderPath, String path) throws IOException {
	   	try {
				File folder = new ClassPathResource(path).getFile();
 		    	for (int i=0; i<folder.listFiles().length;i++) {
 				    if (folder.listFiles()[i].isFile() && folder.listFiles()[i].getName().contains("table-schema.sql")) {		    			
		    			LoggerService.debug(folderPath + ServiceConstants.BACK_SLASH + folder.listFiles()[i].getName());
		    		}
		    	}				
			} catch (IOException e) {
				e.printStackTrace();
			}
	}
}
