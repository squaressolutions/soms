package com.squaressolutions.template.security.aspectj;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import com.squaressolutions.template.security.auditing.AuditHttpService;
import com.squaressolutions.template.service.util.LoggerService;

import jakarta.servlet.http.HttpServletRequest;

@Profile("!prod")
@Aspect
@Component
public class DebugAspect extends CommonPointcuts{
   // @Pointcut("execution(* com.squaressolutions.template.service.dataSource.DataSourceService.*(..))")
    //@Pointcut("within(com.squaressolutions.template.service.dataSource.DataSourceService.*)")
    public void methodOnlyPointcut() { }

    //@Before("methodOnlyPointcut()")
	public Object showMethod(JoinPoint joinPoint) throws Exception {
    	LoggerService.debug("**********Show method on in path**********");
		   Object[] args = joinPoint.getArgs();
        LoggerService.debug("Signature: "+joinPoint.getStaticPart().getSignature());
        if(args.length>0){
        	System.out.print("Arguments passed: " );
			for (int i = 0; i < args.length; i++) {
				System.out.print("arg "+(i+1)+": "+args[i]+"\\n");
			}
        }
        Object result;
		try {
			//result = joinPoint.proceed(args);
			//System.out.println("Returning " + result);
			//return result.toString();   
		} catch (Throwable e) {
			e.printStackTrace();
		}
        //throw new Exception("Error: Invalid Database access");
		return null;
    }

    
//	@Target(ElementType.METHOD)
//	@Retention(RetentionPolicy.RUNTIME)
//	public @interface CheckHere {}
//
//    @Around("@annotation(com.squaressolutions.template.security.aspectj.DebugAspect.CheckHere)")
//    public Object checkHere(ProceedingJoinPoint joinPoint) throws Throwable {
//        long start = System.currentTimeMillis();
//
//        Object proceed = joinPoint.proceed();
//
//        long executionTime = System.currentTimeMillis() - start;
//
//        System.out.println(joinPoint.getSignature() + " executed in " + executionTime + "ms");
//        return proceed;
//    }   
//    
	
	
//	@AfterReturning(value = "execution(* com.squaressolutions.template.controller.*.*(..))", returning = "result")
	
//	@Around("execution(* handleRequest(..))")
//	//@Around("execution(* doSomething(..))")
//	public void afterReturning(JoinPoint joinPoint, Object result) {
//		System.out.println("com.squaressolutions.template.controller**********"+ joinPoint+ result);
//	}
//	
//	@After(value = "execution(* com.squaressolutions.template.*.*(..))")
//	public void after(JoinPoint joinPoint) {
//		System.out.println("after execution of {}"+ joinPoint);
//	}
//	@Pointcut(value = "execution(* com.squaressolutions.template.*.*(..))") 
//	public void pointcut(JoinPoint joinPoint, Object result) {
//		System.out.println("@Pointcut returned with value {}"+ joinPoint+ result);
//	}
//    @Around("onAuthenticationSuccess()")
//    public void aroundAuthenticationSuccess(ProceedingJoinPoint joinPoint) throws Throwable {
//    	Object[] args = joinPoint.getArgs();
//    	HttpServletRequest request = (HttpServletRequest) args[0];
//    	HttpServletResponse response = (HttpServletResponse) args[1];
//    	Authentication authentication = (Authentication) args[2];
//    	Object retVal = joinPoint.proceed();
//	}

	
}