package com.squaressolutions.template.service.system;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import com.squaressolutions.template.service.ServiceBase;

@Configuration
@PropertySource("classpath:application.properties")
@Service
public class ApplicationPropertyService implements ServiceBase{
	 @Configuration
	 @PropertySource("classpath:application-setup.properties")
	 public class ApplicationConfigSetup { }

	 @Configuration
	 @PropertySource("classpath:application-dev.properties")
	 public class ApplicationConfigDev { }

	 @Configuration
	 @PropertySource("classpath:application-prod.properties")
	 public class ApplicationConfigProd { }
	 
	 
	 private void setApplicationProperty() {
		 AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
		 ctx.register(ApplicationConfigDev.class);
		 ctx.register(ApplicationConfigProd.class);
		 ctx.refresh();
	 }
	 
}