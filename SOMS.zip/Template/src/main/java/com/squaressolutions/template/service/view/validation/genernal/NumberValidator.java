package com.squaressolutions.template.service.view.validation.genernal;

import org.springframework.validation.Errors;

import com.squaressolutions.template.service.ServiceConstants;
import com.squaressolutions.template.service.view.validation.BaseValidator;

public class NumberValidator implements BaseValidator {
	public static boolean minimum(Object[] parasIn)  throws Exception {
		Double[] paras = (Double[]) parasIn;
		return (compare(GREATER_EQUAL, paras[1], paras[2]));
	}
	public static boolean maximum(Object[] parasIn)  throws Exception {
		Double[] paras = (Double[]) parasIn;
		return (compare(LESS_EQUAL, paras[1], paras[2]));
	}
	public static boolean compare(Object[] parasIn) throws Exception {
		String[] paras = (String[]) parasIn;
		return compare(paras[0], Double.valueOf(paras[1]), Double.valueOf(paras[2]));
	}
	private static boolean compare(String checker, Double value, Double checkedValue)  throws Exception {
		if (checker.startsWith(GREATER_EQUAL) || checker.startsWith(EQUAL_GREATER)) {
			return (value >= checkedValue);
		} else if (checker.startsWith(LESS_EQUAL) || checker.startsWith(EQUAL_LESS)) {
			return (value <= checkedValue);
		} else if (checker.startsWith(LESS)) {
			return (value < checkedValue);
		} else if (checker.startsWith(GREATER)) {
			return (value > checkedValue);
		} else if (checker.startsWith(ServiceConstants.EXCLAMATION)) {
			return !(value == checkedValue);
		} else {
			return value.equals(checkedValue);
		}
	}
	@Override
	public boolean supports(Class<?> clazz) {
		return Long.class.equals(clazz) || Integer.class.equals(clazz) || Float.class.equals(clazz) || Double.class.equals(clazz);
	}
	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
		
	}
}