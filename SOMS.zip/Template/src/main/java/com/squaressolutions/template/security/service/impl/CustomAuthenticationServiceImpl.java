package com.squaressolutions.template.security.service.impl;

import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.stereotype.Component;

import com.squaressolutions.template.security.authentications.CustomAuthenticationService;
import com.squaressolutions.template.service.util.LoggerService;

@Component
public class CustomAuthenticationServiceImpl implements CustomAuthenticationService {

	@Override
	public DaoAuthenticationProvider authenticationProvider(PasswordEncoder passwordEncoder) {
	    DaoAuthenticationProvider daoAuthenticationProvider = new DaoAuthenticationProvider();
	    daoAuthenticationProvider.setUserDetailsService(inMemoryUserDetails(passwordEncoder));
	    daoAuthenticationProvider.setPasswordEncoder(passwordEncoder);
	    return daoAuthenticationProvider;
    }
	
    private InMemoryUserDetailsManager inMemoryUserDetails(PasswordEncoder passwordEncoder) {
        LoggerService.debug("##Custom InMemoryUserDetailsManager created");
    	return new InMemoryUserDetailsManager();
    }
	public UserDetailsService getUserDetailsService(PasswordEncoder passwordEncoder) {
		return this.inMemoryUserDetails(passwordEncoder);
	}
}

