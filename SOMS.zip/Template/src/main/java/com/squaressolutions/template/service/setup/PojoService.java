package com.squaressolutions.template.service.setup;

import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.squaressolutions.template.service.ServiceBase;
import com.squaressolutions.template.service.ServiceConstants;
import com.squaressolutions.template.service.util.PropertyService;

@Profile("setup")
public class PojoService implements ServiceBase {
	private static final String ENTITY_MAP_FILE = "dataSources/h2-schema/entity.map";
	private static final String BODY = "body";
	private static final String ELEMENT = "element";
	private static final String INGORES = "ignores";
	private static final String CREATE = "create";
	private static final String TABLE = "table";
	private static final char FORMAT_PREFIX = '&';
	private static final char ANNOTATION_PREFIX = '@';
	private static final String TAG_TYPE = "<type>";
	private static final String TAG_NAME = "<name>";
	private static final String TAG_TABLE = "<table>";
	private static final String TAG_COLUMN = "<table_column>";
	private static final String TAG_ELEMENT = "<elements>";
	private static final String TAG_ENTITY = "<entity>";
	private static final String RANGE_REPLACEMENT = "?";
	
	
	@Autowired
	private PropertyService propertyService;
	private Properties entityMap;
	private String tableName;
	int flag = 0;
	private String lineConvertor(String line) {
		//check whether line starts with '(', otherwise it won't work
		if (StringUtils.hasLength(line) && line.charAt(0) == ServiceConstants.LEFT_BRACKET.charAt(0)) {
			flag = 1;
		} else if (StringUtils.hasLength(line) && line.charAt(0) == ServiceConstants.RIGHT_BRACKET.charAt(0)) {
			flag = 0;
		}
		
		String[] ignores = entityMap.getProperty(INGORES).split(ServiceConstants.COMMA);
		for (int i=0; i<ignores.length; i++ ) {
			if (line.trim().startsWith(ignores[i])) {
				line = ServiceConstants.EMPTY;
			}
		}		
		String out = ServiceConstants.EMPTY;	
		String[] elements = line.trim().split(ServiceConstants.SPACE1);
		if (flag == 1 && elements.length >= 2) {
			out = entityMap.getProperty(ELEMENT);
			out = out.replace(TAG_TYPE, elements[1]);
			out = out.replace(TAG_COLUMN, elements[0]);
			out = out.replace(TAG_NAME, convertUnderscoreCharToUpper(elements[0]));
		}
		return out;
	}
	private String convertUnderscoreCharToUpper(String text) {
		int i = text.indexOf(ServiceConstants.UNDERSCORE);
		while (i>0) {
			String toReplace = text.substring(i,i+2);
			String replaced = text.substring(i+1,i+2).toUpperCase();		
			text = text.replace(toReplace, replaced);
			i = text.indexOf(ServiceConstants.UNDERSCORE);
		}
		return text;
	}
//	private String loopForEntityMap(String text, Method method) {
//		Object[] keys = entityMap.stringPropertyNames().toArray();
//		for (int i=0;i<keys.length-2;i++) {
//			String value = entityMap.getProperty((String) keys[i]);
//			text = method.invoke(obj, text, (String) keys[i], value);
//		}
//		return text;
//	}
//	private String replaceValue(String text, String key, String value) {
//		return text.replace((String) key, value);
//	}
	private String setAnnotation(String line) {
		String annotation = ServiceConstants.EMPTY;
		Set<Object> keys = entityMap.keySet();
        for (Object key : keys) {
        	if ( key.toString().charAt(0) == ANNOTATION_PREFIX) {
        		if (!line.toLowerCase().trim().contains("id ") && line.contains(key.toString().substring(1))) {
    	            String value = entityMap.getProperty((String) key);
    	            if (value.contains(RANGE_REPLACEMENT)) {
    	            	value = value.replace(RANGE_REPLACEMENT, getBracketsValue(line));
    	            }
    	            annotation += value;
        		}
        	}
        }
		return annotation;
	}
	private String getBracketsValue(String text) {
		return text.substring(text.indexOf(ServiceConstants.LEFT_BRACKET)+1,text.indexOf(ServiceConstants.RIGHT_BRACKET));
	}
	private String format(String line) {
		Set<Object>keySet=entityMap.keySet();
		TreeSet<Object>sortedSet=(TreeSet<Object>) new TreeSet<Object>(keySet).descendingSet();
		Iterator<Object>iterator=sortedSet.iterator();
		while(iterator.hasNext()) {
		    Object key = iterator.next();
        	if ( key.toString().charAt(0) == FORMAT_PREFIX) {
	            String value = entityMap.getProperty((String) key);
	            if (key.toString().contains(RANGE_REPLACEMENT) && line.contains(ServiceConstants.LEFT_BRACKET) && line.contains(ServiceConstants.RIGHT_BRACKET)) {
	            	key = key.toString().replace(getBracketsValue(key.toString()), getBracketsValue(line));
	            }
	            if (key.toString().contains(ServiceConstants.FORWARD_SLASH)) {
	            	line = line.replaceAll((String) key.toString().substring(1), value);
	            } else {
		            line = line.replace((String) key.toString().substring(1), value);	            	
	            }
	            //System.out.println(key.toString().substring(1) + "***"+ value + "-----" +line);
        	}
        }
		return line;
	}
	private void getTableName(String line) {
		String[] elements = line.trim().split(ServiceConstants.SPACE1);
		if (elements.length == 3 && elements[0].toLowerCase().equals(CREATE) && elements[1].toLowerCase().equals(TABLE)){
			tableName = elements[2];
		}
	}
	@Override
	public boolean preProcess() {
		entityMap = propertyService.loadProperty(ENTITY_MAP_FILE);
		return entityMap != null && entityMap.size() > 0;
	}

	@Override
	public Object process(Object line) {
		getTableName((String) line);
		String annotation = setAnnotation((String) line);
		line = format((String) line);
		line = annotation + lineConvertor((String) line);
		return line;
	}

	@Override
	public Object postProcess(String elements) {
		String classText = entityMap.getProperty(BODY);
		classText = classText.replace(TAG_TABLE, tableName);
		classText = classText.replace(TAG_ELEMENT, elements);
		return classText;
	}
	protected String setEntity(String filePath, String out) {
		String entity = filePath.substring(filePath.lastIndexOf(ServiceConstants.BACK_SLASH) + 1);
		entity = entity.substring(0, entity.indexOf(ServiceConstants.DOT));
		return (out.replace(TAG_ENTITY, entity));
	}
}
