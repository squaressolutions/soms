package com.squaressolutions.template.security.authentication.user;

import java.util.ArrayList;
import java.util.List;

import javax.naming.Name;

import org.springframework.ldap.odm.annotations.Attribute;
import org.springframework.ldap.odm.annotations.DnAttribute;
import org.springframework.ldap.odm.annotations.Entry;
import org.springframework.ldap.odm.annotations.Id;
import org.springframework.ldap.odm.annotations.Transient;

import lombok.Data;

@Data
@Entry(objectClasses = {"person"})
public class LdapUser  {
	   @Id
	   private Name dn;

	   @Attribute(name="cn")
	   @DnAttribute(value="cn", index=1)
	   private String commonName;

	   @Attribute(name="sn")
	   private String surName;
	   
	   @Attribute(name="givenName")
	   private String givenName;

	   // No @Attribute annotation means this will be bound to the LDAP attribute
	   // with the same value
	   private String description;

	   @DnAttribute(value="ou", index=0)
	   @Transient
	   private String company;

	   @Attribute(name="userPassword")
	   private String secret;
	   
	   @Attribute(name="uid")
	   private String uid;

	   @Transient
	   List authorities = new ArrayList();
}