package com.squaressolutions.template.security.service.impl;

import java.util.Collections;

import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;

import com.squaressolutions.template.service.util.LoggerService;

public class CustomAuthenticationProvider implements AuthenticationProvider {
    @Override
    public Authentication authenticate(Authentication auth) 
      throws AuthenticationException {
        String userName = auth.getName();
        String password = auth.getCredentials().toString();
        LoggerService.debug("##CustomAuthenticationProvider called "+ userName);
        if (userName.contains("") && !password.isEmpty()) {
            return new UsernamePasswordAuthenticationToken
              (userName, password, Collections.emptyList());
        } else {
            throw new 
              BadCredentialsException("External system authentication failed");
            
        }
    }

    @Override
    public boolean supports(Class<?> auth) {
        return auth.equals(UsernamePasswordAuthenticationToken.class);
    }
}