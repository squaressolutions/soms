package com.squaressolutions.template.service.business;

import org.springframework.beans.factory.annotation.Autowired;

import com.squaressolutions.template.security.auditing.AuditBusinessService;

public class BehaviourBusinessService {
	@Autowired
	AuditBusinessService auditBusinessService;

}
