package com.squaressolutions.template.dataSource.model.people;

import jakarta.persistence.Entity;
import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import org.hibernate.annotations.GenericGenerator;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;
import java.util.Date;

import org.springframework.stereotype.Component;
import lombok.Data;

@Component
@Entity(name="place_of_birth")
@Data
public class PlaceOfBirth {
	@Id
	@GeneratedValue(generator = "increment")
	@GenericGenerator(name="increment", strategy = "increment")
	@Column(name = "id")
	private Long id;
	@Column(name = "country_id")
	private Long countryId;
	@Column(name = "state_id")
	private Long stateId;
	@Column(name = "region_id")
	private Long regionId;

}