package com.squaressolutions.template.security.auditing;

import java.util.Date;
import java.util.Properties;

import org.springframework.stereotype.Service;

import com.squaressolutions.template.dataSource.model.system.security.AppAudit;
import com.squaressolutions.template.service.dataSource.DataSourceService;
import com.squaressolutions.template.service.util.HttpRequestHelper;
import com.squaressolutions.template.service.util.PropertyService;

import jakarta.servlet.http.HttpServletRequest;


@Service
public class AuditBusinessService {
	private static Properties appProperties = PropertyService.loadProperty("security/auditingApp.properties");
	private  DataSourceService dataSourceService;
	

	public void set(HttpServletRequest request) {
		if (request.getUserPrincipal() != null) {
	    	// testing only save(request);
			new Runnable() {
	            public void run() {
	            	try {
						save(request);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	            }
			}.run();
		}
	}
	public  void save(HttpServletRequest request) {

		AppAudit audit = new AppAudit();
		//When Where Who How
		audit.setAuditTime(new Date());
		dataSourceService.persist(getDatabasePath(appProperties), audit);

	}
	private String getDatabasePath(Properties properties) {
		return properties.getProperty("database");		
	}
}
