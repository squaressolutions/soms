package com.squaressolutions.template.service.dataSource;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.context.annotation.Lazy;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.squaressolutions.common.view.model.PageDataSource;
import com.squaressolutions.template.security.LoginService;
import com.squaressolutions.template.service.ServiceConstants;
import com.squaressolutions.template.service.data.DataService;
import com.squaressolutions.template.service.util.LoggerService;

@Service
public class DataSourceService{
	public static final String H2_SYSTEM_DB_SCHEMA_PATH = "dataSources/h2-schema/system/"; 	
	@Lazy
	@Autowired
	HikariConnectionPoolService hikariConnectionPoolService;

	@Autowired
	DataSourceEntityService dataSourceEntityService;
	
//	@PreAuthorize("@canAccessConfig.postauth(#path, #pid)")
	public ArrayList<String[]> getDataList(PageDataSource pageDataSource, int dataQueryIndex) {
		ArrayList dataList = new ArrayList<>();
		if (pageDataSource.getQueries() != null && pageDataSource.getQueries().size() > dataQueryIndex) {
			//always get first element of the result list
			String query = (String) pageDataSource.getQueries().get(dataQueryIndex);
			if (StringUtils.hasLength(query) && !query.contains(ServiceConstants.QUESTION_MARK)) {				
				//dataList = (ArrayList) hibernateService.getDataList(query);
				//Hibernate cannot produce a list
				dataList = getDataList(pageDataSource.getDataSourceConfigPath(), query, pageDataSource.getFormat());
		    	if (dataList.size()==1) {
					dataList.add(ServiceConstants.EMPTY);					
				}
			} else {
				dataList.add(ServiceConstants.EMPTY);
			}
		} else {
			dataList.add(ServiceConstants.EMPTY);
		}
		return dataList;		
	}	
    public long persist(String dataSourcePath, Object object) {
    	if (!object.getClass().getTypeName().equals(Object.class.getName()) ) {   
    		return dataSourceEntityService.persist(dataSourcePath, object);
    	}
    	return ServiceConstants.INVALID;
    }    
    public void merge(String dataSourcePath, Object object) {
    	if (!object.getClass().getTypeName().equals(Object.class.getName()) ) {    		
    		dataSourceEntityService.merge(dataSourcePath, object);
    	}
    }  
	public long getDataId(Object object) {
		return DataService.getEntityId(object);
	}
	public Object setDataId(Object object, long id) {
		return DataService.setEntityId(object, id);
	}	
	public ArrayList<?> getDataList(String dataSourceConfigPath, String query, String resultFormat) {
		DataSource dataSource = getPooledDataSource(dataSourceConfigPath);
		//Just in case if it is needed
//		if (dataSource == null) {
//			dataSource = getDataSource(dataSourceConfigPath);
//		}
		ArrayList<?> dataList = new ArrayList<>();
		Connection con = null;
	    PreparedStatement pstmt;
	    
	    try {
	        con = dataSource.getConnection();
	        pstmt = con.prepareStatement(query);
	        ResultSet rs = pstmt.executeQuery();
	        dataList = (ArrayList<?>) DataService.class.getDeclaredMethod(resultFormat, ResultSet.class).invoke(new DataService(),rs);
	        pstmt.closeOnCompletion();
	        con.close();
	    } catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			LoggerService.debug("*** The resultFormat could be not wrong in the DataSource config:" + resultFormat);
			e.printStackTrace();
		} finally {
	        if (con != null)
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
	    }
		return dataList;
	}
	public Object getValue(String sqlPara, int index) {
		String[] sqlParaSet = sqlPara.split(ServiceConstants.COLUMN);
		ArrayList dataList = getDataMap(sqlParaSet[0], sqlParaSet[1]);
		if (index < dataList.size()) {
			Map<String, Object> data = (Map<String, Object>) dataList.get(index);
			return data.values().toArray()[index];
		}
		return ServiceConstants.EMPTY;
	}
	private ArrayList<?> getDataMap(String dataSourceConfigPath, String query) {
		ArrayList<?> dataList = new ArrayList<String[]>();
		if (StringUtils.hasLength(query) && !query.contains(ServiceConstants.QUESTION_MARK)) {
			dataList = getDataList(dataSourceConfigPath, query, DataService.FORMAT_NAME_MAP);
		} else {
			LoggerService.debug(" **** Query is not set " + query);
		}
		return dataList;
	}
	private DataSource getPooledDataSource(String path) {
		if (checkAccess()) {
			return hikariConnectionPoolService.getPoolService(path).getDataSource();
		}
		return null;
	}
	
	public DataSource getDataSource(String path) {
		DataSourceProperties dataSourceProperties = DataSourcePropertyService.getDataSourceProperties(path);
		DataSource dataSource = dataSourceProperties.initializeDataSourceBuilder().build();
		return dataSource;
	}
	private boolean checkAccess() {
		Authentication authentication = LoginService.getAuthentication();		
		if (authentication == null || (authentication instanceof AnonymousAuthenticationToken)) {
			return false;
		}	
		return true;
	}
}
