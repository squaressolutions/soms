package com.squaressolutions.template.dataSource.model.system.security;

import jakarta.persistence.Entity;
import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import org.hibernate.annotations.GenericGenerator;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;
import java.util.Date;

import org.springframework.stereotype.Component;
import lombok.Data;

@Component
@Entity(name="identitis")
@Data
public class Identitis {
	@Id
	@GeneratedValue(generator = "increment")
	@GenericGenerator(name="increment", strategy = "increment")
	@NotNull
	@Size(min=1, max = 50)
	@Column(name = "username")
	private String username;
	@NotNull
	@Size(min=1, max = 50)
	@Column(name = "identity")
	private String identity;
	@NotNull
	@Size(min=1, max = 50)
	@Column(name = "platform")
	private String platform;
	@NotNull
	@Size(min=1, max = 255)
	@Column(name = "organisation")
	private String organisation;

}