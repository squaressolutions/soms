package com.squaressolutions.template.security.service.impl;

import java.util.Properties;

import org.springframework.ldap.core.ContextSource;
import org.springframework.ldap.core.support.BaseLdapPathContextSource;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.ldap.authentication.BindAuthenticator;
import org.springframework.security.ldap.authentication.LdapAuthenticationProvider;
import org.springframework.security.ldap.authentication.ad.ActiveDirectoryLdapAuthenticationProvider;
import org.springframework.security.ldap.userdetails.DefaultLdapAuthoritiesPopulator;
import org.springframework.security.ldap.userdetails.LdapAuthoritiesPopulator;

import com.squaressolutions.template.security.authentications.LdapAuthenticationService;
import com.squaressolutions.template.service.ServiceConstants;
import com.squaressolutions.template.service.util.LoggerService;
import com.squaressolutions.template.service.util.PropertyService;

	public class LdapService{
		protected Properties properties;
		protected void loadProperties(String configPath) {
			properties = PropertyService.loadProperty(configPath);
		}
		protected LdapContextSource getContextSource() {
			LdapContextSource contextSource = new LdapContextSource();
			contextSource.setUrl(properties.getProperty("url"));
			contextSource.setBase(properties.getProperty("base"));
			contextSource.afterPropertiesSet();
			return contextSource;
		}
	}	
