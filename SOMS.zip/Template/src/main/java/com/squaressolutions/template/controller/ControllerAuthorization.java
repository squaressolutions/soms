package com.squaressolutions.template.controller;

public interface ControllerAuthorization {
	default boolean allow() {
		return false;		
	}
}
