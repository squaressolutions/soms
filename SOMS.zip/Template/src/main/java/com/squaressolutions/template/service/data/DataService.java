package com.squaressolutions.template.service.data;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.sql.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.stereotype.Service;

import com.squaressolutions.template.service.ServiceBase;
import com.squaressolutions.template.service.ServiceConstants;
import com.squaressolutions.template.service.util.LoggerService;



@Service
public class DataService implements ServiceBase{
	public static final String FORMAT_LIST = "formatList";
	public static final String FORMAT_NAME_MAP = "formatNameMap";
	public static final String GET_ID = "getId";
	public static final String SET_ID = "setId";
	public static final String GET_COL_LABEL = "getColumnLabel";
	public static final String GET_COL_NAME = "getColumnName";
	
	
	public static long getEntityId(Object object) {
		return (long) getEntityElement(object, GET_ID);
	}
	public static Object setEntityId(Object object, long id) {
	   Method method;
		try {
			method = object.getClass().getMethod(SET_ID, Long.class);
	        return method.invoke(object, id);	
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return object;
	}	
	public static Object getEntityElement(Object object, String methodStr) {
		return invoke(object, methodStr);
	}
	public static Object invoke(Object object, String methodStr) {	
		try {
			Method method = object.getClass().getMethod(methodStr);
			Object value = method.invoke(object);
			if (value == null) {
				return ServiceConstants.INVALID;
			}
			return value;
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ServiceConstants.INVALID;
	}
	public ArrayList<String[]> formatList(ResultSet rs) throws SQLException {
		ResultSetMetaData rsmd = rs.getMetaData(); 
		int columnCount = rsmd.getColumnCount();	
		String[] columns = new String[columnCount];
		ArrayList<String[]> dataList= new ArrayList<>(); 	
		while (rs.next()) {
		   int i = 0;
		   columns= new String[columnCount]; 
		   while(i < columnCount) {
			   columns[i++] = rs.getString(i);
			   String value = columns[i-1];
	           	if (columns[i-1].getClass().getTypeName().equals(Date.class.getName())) {
	 			   value = "\"" + columns[i-1] + "\"";
	           		
	           	}
	           	else if (columns[i-1].getClass().getTypeName().equals(String.class.getName())) {
		 			   value = "\"" + columns[i-1] + "\"";        		
	           	}
			   columns[i-1] = value;
		   }
		   dataList.add(columns);
		}
		return dataList;
	}
	public ArrayList<?> formatJson(ResultSet resultSet) throws Exception {
		ArrayList<String> dataList= new ArrayList<String>(); 
		JSONArray jsonArray = new JSONArray();
        while (resultSet.next()) {
            int totalCols = resultSet.getMetaData().getColumnCount();
            JSONObject obj = new JSONObject();
            for (int i = 0; i < totalCols; i++) {
            	if (resultSet.getMetaData().getColumnClassName(i+1).equals(Date.class.getName())) {
	            	//force label to lower case because sql label is forced to be upper case
            		//json date needs to be a string
            		//logger.debug(resultSet.getMetaData().getColumnLabel(i + 1));
            		if (resultSet.getObject(i + 1) != null) {
            			Object value = formatJSonData(resultSet.getObject(i + 1));
    	                obj.put(resultSet.getMetaData().getColumnLabel(i + 1)
    	                        .toLowerCase(), value);            		
            		} else {
    	                obj.put(resultSet.getMetaData().getColumnLabel(i + 1)
    	                        .toLowerCase(), ServiceConstants.EMPTY);            		
            		}
            	} else {
	            	//force label to lower case because sql label is forced to be upper case
        			Object value = formatJSonData(resultSet.getObject(i + 1));
	                obj.put(resultSet.getMetaData().getColumnLabel(i + 1)
	                        .toLowerCase(), value);
            	}
            }
            jsonArray.add(obj);
        }
        dataList.add(jsonArray.toJSONString());
        return dataList;
    }
	public ArrayList<?> formatLabelMap(ResultSet rs) throws SQLException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
		return formatMap(rs, GET_COL_LABEL);
	}
	public ArrayList<?> formatNameMap(ResultSet rs) throws SQLException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
		return formatMap(rs, GET_COL_NAME);
	}
	private ArrayList<?> formatMap(ResultSet rs, String getColumnHeader) throws SQLException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
		ArrayList<Map> dataList= new ArrayList<Map>(); 
	    ResultSetMetaData md = rs.getMetaData();
	    int columns = md.getColumnCount();
	    while (rs.next()){
	        Map<String, Object> map = new HashMap<String, Object>(columns);
	        for(int i = 1; i <= columns; ++i){
	        	Method m = ResultSetMetaData.class.getDeclaredMethod(getColumnHeader, int.class);
	        	String name = (String) ResultSetMetaData.class.getDeclaredMethod(getColumnHeader, int.class).invoke(md,i);		
	            map.put(name, rs.getObject(i));
	        }
	        dataList.add(map);
	    }
	    return dataList;
	}
	private Object formatJSonData(Object value) {
		//if (value!=null) LoggerService.debug(value +"*************************"+ value.getClass().getTypeName());

		if (value != null && (value.getClass().getTypeName().equals(java.sql.Timestamp.class.getTypeName()) ||
				value.getClass().getTypeName().equals(java.sql.Date.class.getTypeName()))) {
			return value.toString();
		}
		return value;
	}
}
