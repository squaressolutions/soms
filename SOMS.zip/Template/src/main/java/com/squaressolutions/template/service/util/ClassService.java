package com.squaressolutions.template.service.util;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.type.filter.AnnotationTypeFilter;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.context.support.StandardServletEnvironment;

import com.squaressolutions.template.service.ServiceBase;

@Service
public class ClassService  implements ServiceBase {
	public static Object[] allConfigurationClassesInPackage(String packageName) throws ClassNotFoundException {
		final ClassPathScanningCandidateComponentProvider provider = new ClassPathScanningCandidateComponentProvider(
				true, new StandardServletEnvironment());
		
		provider.addIncludeFilter(new AnnotationTypeFilter((Class<? extends Annotation>) Configuration.class));
		return provider.findCandidateComponents(packageName).toArray();
	}
	public static Class<?>[] findAllConfigurationClassesInPackage(String packageName, String className) throws ClassNotFoundException {
		final List<Class<?>> result = new LinkedList<Class<?>>();
		for (Object beanDefinition : allConfigurationClassesInPackage(packageName)) {
			String beanName = ((BeanDefinition) beanDefinition).getBeanClassName();
			if (beanName.toLowerCase().endsWith(className.toLowerCase()) || !StringUtils.hasLength(className)) {
				result.add(Class.forName(beanName));					
			}
		}
		return result.toArray(new Class<?>[result.size()]);
	}
	public static Object callClassMethod(String[] classMethod, Object[] paraObjects) throws Exception {
		Class<?> theClass;
		theClass = Class.forName(classMethod[0]);
		Object classObj = theClass.getDeclaredConstructor().newInstance();
        Method method = classObj.getClass().getMethod(classMethod[1], Object[].class);
        return method.invoke(classObj, new Object [] {paraObjects});		
	}
}
